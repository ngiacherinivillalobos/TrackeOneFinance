import { Request, Response } from 'express';
import { getDatabase } from '../database/connection';

// Função helper para criar uma transação individual
const createSingleTransaction = async (db: any, params: {
  description: string;
  amount: number;
  dbType: string;
  category_id: number;
  subcategory_id: number;
  currentPaymentStatusId: number;
  bank_account_id: number;
  card_id: number;
  contact_id: number;
  formattedDate: string;
  cost_center_id: number;
}) => {
  const query = `
    INSERT INTO transactions (
      description, amount, type, category_id, subcategory_id,
      payment_status_id, bank_account_id, card_id, contact_id, 
      transaction_date, cost_center_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  return new Promise<any>((resolve, reject) => {
    db.run(query, [
      params.description, params.amount, params.dbType, params.category_id, params.subcategory_id,
      params.currentPaymentStatusId, params.bank_account_id, params.card_id, params.contact_id, 
      params.formattedDate, params.cost_center_id
    ], function(this: any, err: any) {
      if (err) {
        console.error('Database error:', err);
        reject(err);
      } else {
        console.log('Transaction created with ID:', this.lastID);
        resolve({ lastID: this.lastID });
      }
    });
  });
};

const list = async (req: Request, res: Response) => {
  console.log('===== TRANSACTION CONTROLLER - LIST =====');
  console.log('Query params:', req.query);
  
  try {
    const db = getDatabase();
    
    // Construir filtros dinamicamente
    let whereConditions: string[] = [];
    let queryParams: any[] = [];
    
    // Filtro por data - aceita tanto start_date/end_date quanto month
    if (req.query.start_date) {
      whereConditions.push('t.transaction_date >= ?');
      queryParams.push(req.query.start_date);
    }
    
    if (req.query.end_date) {
      whereConditions.push('t.transaction_date <= ?');
      queryParams.push(req.query.end_date);
    }
    
    // Filtro por mês (formato YYYY-MM) - compatibilidade com página Transactions
    if (req.query.month && !req.query.start_date && !req.query.end_date) {
      const monthStr = req.query.month as string;
      const [year, month] = monthStr.split('-');
      const startDate = `${year}-${month}-01`;
      const endDate = `${year}-${month.padStart(2, '0')}-${new Date(parseInt(year), parseInt(month), 0).getDate()}`;
      whereConditions.push('t.transaction_date >= ? AND t.transaction_date <= ?');
      queryParams.push(startDate, endDate);
    }
    
    // Filtro por tipo de transação
    if (req.query.transaction_type) {
      const typeMap: any = {
        'Despesa': 'expense',
        'Receita': 'income', 
        'Investimento': 'investment'
      };
      whereConditions.push('t.type = ?');
      queryParams.push(typeMap[req.query.transaction_type as string] || req.query.transaction_type);
    }
    
    // Filtro por categoria
    if (req.query.category_id) {
      whereConditions.push('t.category_id = ?');
      queryParams.push(req.query.category_id);
    }
    
    // Filtro por subcategoria
    if (req.query.subcategory_id) {
      whereConditions.push('t.subcategory_id = ?');
      queryParams.push(req.query.subcategory_id);
    }
    
    // Filtro por status de pagamento
    if (req.query.payment_status_id) {
      whereConditions.push('t.payment_status_id = ?');
      queryParams.push(req.query.payment_status_id);
    }
    
    // Filtro por contato
    if (req.query.contact_id) {
      whereConditions.push('t.contact_id = ?');
      queryParams.push(req.query.contact_id);
    }
    
    // Filtro por centro de custo
    if (req.query.cost_center_id) {
      console.log('Adding cost_center_id filter:', req.query.cost_center_id);
      whereConditions.push('t.cost_center_id = ?');
      queryParams.push(req.query.cost_center_id);
    }
    
    const whereClause = whereConditions.length > 0 ? 'WHERE ' + whereConditions.join(' AND ') : '';
    
    const query = `
      SELECT 
        t.*,
        CASE 
          WHEN t.type = 'expense' THEN 'Despesa'
          WHEN t.type = 'income' THEN 'Receita'
          WHEN t.type = 'investment' THEN 'Investimento'
          ELSE t.type
        END as transaction_type,
        c.name as category_name,
        s.name as subcategory_name,
        ps.name as payment_status_name,
        cont.name as contact_name,
        cc.name as cost_center_name,
        cc.number as cost_center_number
      FROM transactions t
      LEFT JOIN categories c ON t.category_id = c.id
      LEFT JOIN subcategories s ON t.subcategory_id = s.id
      LEFT JOIN payment_status ps ON t.payment_status_id = ps.id
      LEFT JOIN contacts cont ON t.contact_id = cont.id
      LEFT JOIN cost_centers cc ON t.cost_center_id = cc.id
      ${whereClause}
      ORDER BY t.transaction_date DESC, t.created_at DESC
    `;

    console.log('Executing query:', query);
    console.log('With params:', queryParams);

    const transactions = await new Promise<any[]>((resolve, reject) => {
      db.all(query, queryParams, (err: any, rows: any[]) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows || []);
        }
      });
    });

    console.log('Found transactions:', transactions.length);
    res.json(transactions);
  } catch (error) {
    console.error('Error fetching transactions:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

const getById = async (req: Request, res: Response) => {
  console.log('===== TRANSACTION CONTROLLER - GET BY ID =====');
  console.log('Transaction ID:', req.params.id);
  
  try {
    const db = getDatabase();
    const transactionId = req.params.id;

    if (!transactionId) {
      return res.status(400).json({ error: 'Transaction ID is required' });
    }

    const query = `
      SELECT 
        t.*,
        CASE 
          WHEN t.type = 'expense' THEN 'Despesa'
          WHEN t.type = 'income' THEN 'Receita'
          WHEN t.type = 'investment' THEN 'Investimento'
          ELSE t.type
        END as transaction_type,
        c.name as category_name,
        s.name as subcategory_name,
        ps.name as payment_status_name,
        cont.name as contact_name,
        cc.name as cost_center_name,
        cc.number as cost_center_number
      FROM transactions t
      LEFT JOIN categories c ON t.category_id = c.id
      LEFT JOIN subcategories s ON t.subcategory_id = s.id
      LEFT JOIN payment_status ps ON t.payment_status_id = ps.id
      LEFT JOIN contacts cont ON t.contact_id = cont.id
      LEFT JOIN cost_centers cc ON t.cost_center_id = cc.id
      WHERE t.id = ?
    `;

    const transaction = await new Promise<any>((resolve, reject) => {
      db.get(query, [transactionId], (err: any, row: any) => {
        if (err) {
          reject(err);
        } else {
          resolve(row);
        }
      });
    });

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    console.log('Found transaction:', transaction);
    res.json(transaction);
  } catch (error) {
    console.error('Error fetching transaction:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

const create = async (req: Request, res: Response) => {
  console.log('===== TRANSACTION CONTROLLER - CREATE =====');
  console.log('Request body:', req.body);
  
  try {
    const db = getDatabase();
    const {
      description,
      amount,
      type,
      transaction_type,
      category_id,
      subcategory_id,
      payment_status_id,
      bank_account_id,
      card_id,
      contact_id,
      transaction_date,
      cost_center_id,
      is_recurring,
      recurrence_type,
      recurrence_count,
      recurrence_end_date,
      recurrence_weekday,
      recurrence_days, // Para recorrência personalizada (a cada X dias)
      is_paid
    } = req.body;

    // Use transaction_type se estiver presente, senão usa type
    const finalType = transaction_type || type;

    // Convert Portuguese to English for database compatibility
    let dbType = finalType;
    if (finalType === 'Despesa') dbType = 'expense';
    if (finalType === 'Receita') dbType = 'income';
    if (finalType === 'Investimento') dbType = 'investment';

    // Validate required fields
    if (!description || !amount || !finalType || !transaction_date) {
      return res.status(400).json({ error: 'Missing required fields: description, amount, type, transaction_date' });
    }

    // Lógica para determinar o payment_status_id
    let finalPaymentStatusId = payment_status_id;
    
    // Se is_paid for verdadeiro, define como "Pago" (id: 2)
    if (is_paid === true) {
      finalPaymentStatusId = 2;
    }
    // Se payment_status_id for 2, considera como pago
    else if (payment_status_id === 2) {
      finalPaymentStatusId = 2;
    }
    // Se não for informado payment_status_id e não está marcado como pago
    else if (!payment_status_id && !is_paid) {
      const today = new Date().toISOString().split('T')[0]; // Data de hoje no formato YYYY-MM-DD
      
      // Se a data da transação é anterior a hoje e não está marcada como pago, define como "Vencido" (id: 4)
      if (transaction_date < today) {
        finalPaymentStatusId = 4; // Vencido
      } else {
        finalPaymentStatusId = 1; // Em aberto
      }
    }
    // Se não for informado, padrão é "Em aberto" (id: 1)
    else if (!payment_status_id) {
      finalPaymentStatusId = 1;
    }

    console.log('Calculated payment status:', {
      original_payment_status_id: payment_status_id,
      is_paid,
      transaction_date,
      today: new Date().toISOString().split('T')[0],
      final_payment_status_id: finalPaymentStatusId
    });

    console.log('Parameters for insertion:', {
      description, amount, dbType, category_id, subcategory_id,
      finalPaymentStatusId, bank_account_id, card_id, contact_id, 
      transaction_date, cost_center_id
    });

    console.log('Recurrence parameters:', {
      is_recurring, 
      recurrence_type, 
      recurrence_count,
      recurrence_end_date,
      recurrence_weekday,
      recurrence_count_type: typeof recurrence_count,
      condition_check_count: is_recurring && (recurrence_type === 'mensal' || recurrence_type === 'semanal') && recurrence_count > 1,
      condition_check_fixed: is_recurring && recurrence_type === 'fixo' && recurrence_end_date
    });

    // Se for transação recorrente
    if (is_recurring && recurrence_type) {
      console.log('=== RECURRENCE DEBUG ===');
      console.log('is_recurring:', is_recurring, typeof is_recurring);
      console.log('recurrence_type:', recurrence_type, typeof recurrence_type);
      console.log('recurrence_count:', recurrence_count, typeof recurrence_count);
      console.log('Creating recurring transactions:', { recurrence_type, recurrence_count, recurrence_end_date });
      
      const createdTransactions = [];
      let currentDate = new Date(transaction_date);
      let count = 0;
      const maxTransactions = 100; // limitador de segurança
      
      // Tipo "fixo" - criar até a data de finalização
      if (recurrence_type === 'fixo' && recurrence_end_date) {
        const endDate = new Date(recurrence_end_date);
        
        while (currentDate <= endDate && count < maxTransactions) {
          const formattedDate = currentDate.toISOString().split('T')[0];
          
          // Calcular payment_status_id para cada transação baseado na sua data
          let currentPaymentStatusId = finalPaymentStatusId;
          if (!is_paid && payment_status_id !== 2) {
            const today = new Date().toISOString().split('T')[0];
            if (formattedDate < today) {
              currentPaymentStatusId = 4; // Vencido
            } else {
              currentPaymentStatusId = 1; // Em aberto
            }
          }

          const result = await createSingleTransaction(db, {
            description, amount, dbType, category_id, subcategory_id,
            currentPaymentStatusId, bank_account_id, card_id, contact_id, 
            formattedDate, cost_center_id
          });
          
          createdTransactions.push({
            id: result.lastID,
            description,
            amount,
            type: dbType,
            category_id,
            subcategory_id,
            payment_status_id: currentPaymentStatusId,
            bank_account_id,
            card_id,
            contact_id,
            transaction_date: formattedDate,
            cost_center_id
          });

          // Avançar para o próximo mês com correção de overflow
          const originalDay = currentDate.getDate();
          const nextMonth = currentDate.getMonth() + 1;
          const nextYear = currentDate.getFullYear();
          
          // Criar data do próximo mês
          const nextDate = new Date(nextYear, nextMonth, 1);
          const maxDayInNextMonth = new Date(nextDate.getFullYear(), nextDate.getMonth() + 1, 0).getDate();
          
          if (originalDay > maxDayInNextMonth) {
            // Se o dia original não existe no próximo mês, usar o último dia
            currentDate = new Date(nextYear, nextMonth, maxDayInNextMonth);
          } else {
            // Se o dia existe, usar o dia original
            currentDate = new Date(nextYear, nextMonth, originalDay);
          }
          count++;
        }
      }
      // Tipos com quantidade definida (mensal, semanal e personalizado)
      else if ((recurrence_type === 'mensal' || recurrence_type === 'semanal' || recurrence_type === 'personalizado') && recurrence_count > 1) {
        // Calcular a data base para começar as recorrências usando construção explícita para evitar problemas de timezone
        const dateParts = transaction_date.split('-').map((part: string) => parseInt(part));
        let startDate = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]); // month is 0-indexed
        
        // Para semanal, armazenar o dia da semana especificado para as próximas recorrências
        let targetWeekday = null;
        if (recurrence_type === 'semanal' && recurrence_weekday) {
          targetWeekday = parseInt(recurrence_weekday);
          
          console.log('Semanal debug:', {
            originalDate: transaction_date,
            targetWeekday,
            currentDay: startDate.getDay(),
            startDateBefore: startDate.toISOString().split('T')[0]
          });
        }
        
        for (let i = 0; i < recurrence_count; i++) {
          // Calcular a data para cada transação
          currentDate = new Date(startDate);
          
          if (recurrence_type === 'mensal') {
            // Para mensal, avançar i meses
            const originalDay = startDate.getUTCDate();
            currentDate = new Date(startDate);
            
            // Calcular o mês e ano alvo
            const targetMonth = startDate.getUTCMonth() + i;
            const targetYear = startDate.getUTCFullYear() + Math.floor(targetMonth / 12);
            const adjustedMonth = targetMonth % 12;
            
            // Tentar criar a data com o dia original
            currentDate = new Date(Date.UTC(targetYear, adjustedMonth, originalDay));
            
            // Se o dia mudou (overflow), usar o último dia do mês
            if (currentDate.getUTCDate() !== originalDay) {
              currentDate = new Date(Date.UTC(targetYear, adjustedMonth + 1, 0));
            }
          } else if (recurrence_type === 'semanal') {
            if (i === 0) {
              // Primeira transação: usar a data original do registro
              currentDate = new Date(startDate);
            } else {
              // Próximas transações: usar o dia da semana especificado
              if (targetWeekday !== null) {
                // Para a segunda transação e subsequentes, 
                // calcular a próxima ocorrência do dia da semana especificado
                if (i === 1) {
                  // Segunda transação: encontrar a próxima ocorrência do dia alvo após a data inicial
                  const currentWeekDay = startDate.getDay();
                  let daysToAdd = (targetWeekday - currentWeekDay + 7) % 7;
                  
                  // Se o dia alvo é o mesmo dia da semana da data inicial, avançar uma semana
                  if (daysToAdd === 0) {
                    daysToAdd = 7;
                  }
                  
                  currentDate = new Date(startDate);
                  currentDate.setDate(startDate.getDate() + daysToAdd);
                } else {
                  // Terceira transação em diante: avançar semanas a partir da segunda transação
                  const secondTransactionWeekDay = startDate.getDay();
                  let daysToSecondTransaction = (targetWeekday - secondTransactionWeekDay + 7) % 7;
                  if (daysToSecondTransaction === 0) {
                    daysToSecondTransaction = 7;
                  }
                  
                  currentDate = new Date(startDate);
                  currentDate.setDate(startDate.getDate() + daysToSecondTransaction + (7 * (i - 1)));
                }
                
                console.log(`Semana ${i}: result=${currentDate.toISOString().split('T')[0]}`);
              } else {
                // Se não tem dia da semana especificado, usar a lógica antiga
                currentDate.setDate(currentDate.getDate() + (7 * i));
              }
            }
          } else if (recurrence_type === 'personalizado' && recurrence_days) {
            // Para personalizado, adicionar recurrence_days dias * i
            const daysToAdd = parseInt(recurrence_days) * i;
            currentDate.setDate(currentDate.getDate() + daysToAdd);
          }
          
          const formattedDate = currentDate.toISOString().split('T')[0];
          
          // Calcular payment_status_id para cada transação baseado na sua data
          let currentPaymentStatusId = finalPaymentStatusId;
          if (!is_paid && payment_status_id !== 2) {
            const today = new Date().toISOString().split('T')[0];
            if (formattedDate < today) {
              currentPaymentStatusId = 4; // Vencido
            } else {
              currentPaymentStatusId = 1; // Em aberto
            }
          }

          const result = await createSingleTransaction(db, {
            description, amount, dbType, category_id, subcategory_id,
            currentPaymentStatusId, bank_account_id, card_id, contact_id, 
            formattedDate, cost_center_id
          });
          
          createdTransactions.push({
            id: result.lastID,
            description,
            amount,
            type: dbType,
            category_id,
            subcategory_id,
            payment_status_id: currentPaymentStatusId,
            bank_account_id,
            card_id,
            contact_id,
            transaction_date: formattedDate,
            cost_center_id
          });
        }
      }
      
      if (createdTransactions.length > 0) {
        return res.status(201).json({ 
          message: `${createdTransactions.length} recurring transactions created successfully`,
          transactions: createdTransactions,
          count: createdTransactions.length
        });
      }
    }

    // Transação única
    const query = `
      INSERT INTO transactions (
        description, amount, type, category_id, subcategory_id,
        payment_status_id, bank_account_id, card_id, contact_id, 
        transaction_date, cost_center_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const result = await new Promise<any>((resolve, reject) => {
      db.run(query, [
        description, amount, dbType, category_id, subcategory_id,
        finalPaymentStatusId, bank_account_id, card_id, contact_id, 
        transaction_date, cost_center_id
      ], function(this: any, err: any) {
        if (err) {
          console.error('Database error:', err);
          reject(err);
        } else {
          console.log('Transaction created with ID:', this.lastID);
          resolve({ lastID: this.lastID });
        }
      });
    });

    res.status(201).json({ 
      id: result.lastID, 
      message: 'Transaction created successfully',
      transaction: {
        id: result.lastID,
        description,
        amount,
        type: dbType,
        category_id,
        subcategory_id,
        payment_status_id: finalPaymentStatusId,
        bank_account_id,
        card_id,
        contact_id,
        transaction_date
      }
    });
  } catch (error) {
    console.error('Error creating transaction:', error);
    res.status(500).json({ error: 'Failed to create transaction: ' + error });
  }
};

const update = async (req: Request, res: Response) => {
  console.log('===== TRANSACTION CONTROLLER - UPDATE =====');
  console.log('Request body:', req.body);
  console.log('Transaction ID:', req.params.id);
  
  try {
    const db = getDatabase();
    const transactionId = req.params.id;
    
    const {
      description,
      amount,
      type,
      transaction_type,
      category_id,
      subcategory_id,
      payment_status_id,
      bank_account_id,
      card_id,
      contact_id,
      transaction_date,
      cost_center_id,
      is_recurring,
      recurrence_type,
      recurrence_count,
      recurrence_end_date,
      recurrence_weekday,
      is_paid
    } = req.body;

    // Use transaction_type se estiver presente, senão usa type
    const finalType = transaction_type || type;

    // Convert Portuguese to English for database compatibility
    let dbType = finalType;
    if (finalType === 'Despesa') dbType = 'expense';
    if (finalType === 'Receita') dbType = 'income';
    if (finalType === 'Investimento') dbType = 'investment';

    // Validate required fields
    if (!description || !amount || !finalType || !transaction_date) {
      return res.status(400).json({ error: 'Missing required fields: description, amount, type, transaction_date' });
    }

    // Lógica para determinar o payment_status_id (mesma do create)
    let finalPaymentStatusId = payment_status_id;
    
    if (is_paid === true) {
      finalPaymentStatusId = 2;
    }
    else if (payment_status_id === 2) {
      finalPaymentStatusId = 2;
    }
    else if (!payment_status_id && !is_paid) {
      const today = new Date().toISOString().split('T')[0];
      
      if (transaction_date < today) {
        finalPaymentStatusId = 4; // Vencido
      } else {
        finalPaymentStatusId = 1; // Em aberto
      }
    }
    else if (!payment_status_id) {
      finalPaymentStatusId = 1;
    }

    console.log('Updating transaction with payment status:', {
      original_payment_status_id: payment_status_id,
      is_paid,
      transaction_date,
      today: new Date().toISOString().split('T')[0],
      final_payment_status_id: finalPaymentStatusId
    });

    const query = `
      UPDATE transactions SET
        description = ?, amount = ?, type = ?, category_id = ?, subcategory_id = ?,
        payment_status_id = ?, bank_account_id = ?, card_id = ?, contact_id = ?, 
        transaction_date = ?, cost_center_id = ?
      WHERE id = ?
    `;

    const result = await new Promise<any>((resolve, reject) => {
      db.run(query, [
        description, amount, dbType, category_id, subcategory_id,
        finalPaymentStatusId, bank_account_id, card_id, contact_id, 
        transaction_date, cost_center_id, transactionId
      ], function(this: any, err: any) {
        if (err) {
          console.error('Database error:', err);
          reject(err);
        } else {
          console.log('Transaction updated, changes:', this.changes);
          resolve({ changes: this.changes });
        }
      });
    });

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json({ 
      message: 'Transaction updated successfully',
      transactionId: transactionId
    });
  } catch (error) {
    console.error('Error updating transaction:', error);
    res.status(500).json({ error: 'Failed to update transaction: ' + error });
  }
};

const deleteTransaction = async (req: Request, res: Response) => {
  console.log('===== TRANSACTION CONTROLLER - DELETE =====');
  console.log('Transaction ID:', req.params.id);
  
  try {
    const db = getDatabase();
    const transactionId = req.params.id;

    // Validate transaction ID
    if (!transactionId) {
      return res.status(400).json({ error: 'Transaction ID is required' });
    }

    const query = `DELETE FROM transactions WHERE id = ?`;

    const result = await new Promise<any>((resolve, reject) => {
      db.run(query, [transactionId], function(this: any, err: any) {
        if (err) {
          console.error('Database error:', err);
          reject(err);
        } else {
          console.log('Transaction deleted, changes:', this.changes);
          resolve({ changes: this.changes });
        }
      });
    });

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json({ 
      message: 'Transaction deleted successfully',
      transactionId: transactionId
    });
  } catch (error) {
    console.error('Error deleting transaction:', error);
    res.status(500).json({ error: 'Failed to delete transaction: ' + error });
  }
};

export default {
  list,
  getById,
  create,
  update,
  delete: deleteTransaction
};
