import { useState } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Box,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

interface DailyTransaction {
  id: number;
  date: string;
  description: string;
  amount: number;
  category: string;
  type: 'despesa' | 'receita';
}

interface DailyBalance {
  date: string;
  planned: number;
  actual: number;
  remaining: number;
}

export default function CashFlow() {
  const [dailyTransactions, setDailyTransactions] = useState<DailyTransaction[]>([]);
  const [dailyBalance, setDailyBalance] = useState<DailyBalance[]>([]);

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} display="flex" justifyContent="space-between" alignItems="center">
        <Typography variant="h4">Fluxo de Caixa</Typography>
        <Button variant="contained" startIcon={<AddIcon />}>
          Nova Transação
        </Button>
      </Grid>

      {/* Daily Balance Summary */}
      <Grid item xs={12}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>
            Saldo Diário
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Data</TableCell>
                  <TableCell align="right">Planejado</TableCell>
                  <TableCell align="right">Realizado</TableCell>
                  <TableCell align="right">Restante</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {dailyBalance.map((day) => (
                  <TableRow key={day.date}>
                    <TableCell>{new Date(day.date).toLocaleDateString()}</TableCell>
                    <TableCell align="right">R$ {day.planned.toFixed(2)}</TableCell>
                    <TableCell align="right">R$ {day.actual.toFixed(2)}</TableCell>
                    <TableCell align="right">R$ {day.remaining.toFixed(2)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      </Grid>

      {/* Daily Transactions */}
      <Grid item xs={12}>
        <TableContainer component={Paper}>
          <Box p={2}>
            <Typography variant="h6" gutterBottom>
              Transações Diárias
            </Typography>
          </Box>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Data</TableCell>
                <TableCell>Descrição</TableCell>
                <TableCell align="right">Valor</TableCell>
                <TableCell>Categoria</TableCell>
                <TableCell>Tipo</TableCell>
                <TableCell>Ações</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {dailyTransactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>{new Date(transaction.date).toLocaleDateString()}</TableCell>
                  <TableCell>{transaction.description}</TableCell>
                  <TableCell align="right">R$ {transaction.amount.toFixed(2)}</TableCell>
                  <TableCell>{transaction.category}</TableCell>
                  <TableCell>{transaction.type}</TableCell>
                  <TableCell>
                    <Button size="small">Editar</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>
    </Grid>
  );
}
