import { useState } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Box,
  Card,
  CardContent,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

interface CreditCard {
  id: number;
  name: string;
  limit: number;
  available: number;
  closingDay: number;
  dueDay: number;
}

interface CreditCardTransaction {
  id: number;
  date: string;
  description: string;
  amount: number;
  installments: number;
  category: string;
  cardId: number;
}

export default function CreditCard() {
  const [cards, setCards] = useState<CreditCard[]>([]);
  const [transactions, setTransactions] = useState<CreditCardTransaction[]>([]);

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} display="flex" justifyContent="space-between" alignItems="center">
        <Typography variant="h4">Cartões de Crédito</Typography>
        <Button variant="contained" startIcon={<AddIcon />}>
          Nova Transação
        </Button>
      </Grid>

      {/* Credit Cards Summary */}
      <Grid item xs={12}>
        <Grid container spacing={2}>
          {cards.map((card) => (
            <Grid item xs={12} sm={6} md={4} key={card.id}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    {card.name}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Limite: R$ {card.limit.toFixed(2)}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Disponível: R$ {card.available.toFixed(2)}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Fechamento: Dia {card.closingDay}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Vencimento: Dia {card.dueDay}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Grid>

      {/* Transactions */}
      <Grid item xs={12}>
        <TableContainer component={Paper}>
          <Box p={2}>
            <Typography variant="h6" gutterBottom>
              Transações
            </Typography>
          </Box>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Data</TableCell>
                <TableCell>Descrição</TableCell>
                <TableCell align="right">Valor</TableCell>
                <TableCell>Parcelas</TableCell>
                <TableCell>Categoria</TableCell>
                <TableCell>Cartão</TableCell>
                <TableCell>Ações</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {transactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>{new Date(transaction.date).toLocaleDateString()}</TableCell>
                  <TableCell>{transaction.description}</TableCell>
                  <TableCell align="right">R$ {transaction.amount.toFixed(2)}</TableCell>
                  <TableCell>{transaction.installments}x</TableCell>
                  <TableCell>{transaction.category}</TableCell>
                  <TableCell>
                    {cards.find((card) => card.id === transaction.cardId)?.name}
                  </TableCell>
                  <TableCell>
                    <Button size="small">Editar</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>
    </Grid>
  );
}
