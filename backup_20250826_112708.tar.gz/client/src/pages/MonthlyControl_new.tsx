import React, { useState, useEffect } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Checkbox,
  IconButton,
  Menu,
  MenuItem,
  Box,
  Autocomplete,
  TextField,
  Chip,
  FormControl,
  InputLabel,
  Select,
  Fab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  ListItemIcon,
  ListItemText,
  Divider,
} from '@mui/material';
import {
  Add as AddIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  FileCopy as DuplicateIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  CalendarToday as CalendarIcon,
  Download as DownloadIcon,
  Paid as PaidIcon,
  Remove as RemoveIcon,
  TrendingUp as TrendingUpIcon,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { ptBR } from 'date-fns/locale';
import { format, addMonths, subMonths } from 'date-fns';
import api from '../services/api';

interface Transaction {
  id: number;
  description: string;
  amount: number;
  transaction_date: string;
  transaction_type: 'Despesa' | 'Receita' | 'Investimento';
  is_paid: boolean;
  contact?: {
    id: number;
    name: string;
  };
  category?: {
    id: number;
    name: string;
  };
  subcategory?: {
    id: number;
    name: string;
  };
  cost_center?: {
    id: number;
    name: string;
  };
}

interface Category {
  id: number;
  name: string;
  source_type: string;
}

interface Subcategory {
  id: number;
  name: string;
  category_id: number;
}

interface Contact {
  id: number;
  name: string;
}

interface CostCenter {
  id: number;
  name: string;
}

interface PaymentStatus {
  id: number;
  name: string;
}

interface Filters {
  transaction_type: string;
  payment_status_id: string;
  category_id: string;
  subcategory_id: string;
  contact_id: string;
}

export default function MonthlyControl() {
  // Estados
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  
  // Estados para filtros avançados de data
  const [dateFilterType, setDateFilterType] = useState<'month' | 'year' | 'custom'>('month');
  const [customStartDate, setCustomStartDate] = useState<Date | null>(null);
  const [customEndDate, setCustomEndDate] = useState<Date | null>(null);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  
  // Estados para filtros
  const [filters, setFilters] = useState<Filters>({
    transaction_type: '',
    payment_status_id: '',
    category_id: '',
    subcategory_id: '',
    contact_id: ''
  });
  
  // Estados para dados dos filtros
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [paymentStatuses, setPaymentStatuses] = useState<PaymentStatus[]>([]);
  
  // Estados para seleção e ações
  const [selectedTransactions, setSelectedTransactions] = useState<number[]>([]);
  const [actionMenuAnchorEl, setActionMenuAnchorEl] = useState<HTMLElement | null>(null);
  const [selectedTransactionId, setSelectedTransactionId] = useState<number | null>(null);
  const [newTransactionMenuAnchor, setNewTransactionMenuAnchor] = useState<HTMLElement | null>(null);

  // Cálculo dos totais
  const totalReceitas = transactions
    .filter(t => t.transaction_type === 'Receita')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const totalDespesas = transactions
    .filter(t => t.transaction_type === 'Despesa')
    .reduce((sum, t) => sum + t.amount, 0);

  // Carregar dados iniciais
  useEffect(() => {
    loadTransactions();
    loadFilterData();
  }, [currentDate, filters, dateFilterType, customStartDate, customEndDate, selectedYear]);

  const loadTransactions = async () => {
    try {
      setLoading(true);
      
      let startDate: string;
      let endDate: string;
      
      if (dateFilterType === 'month') {
        startDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth(), 1), 'yyyy-MM-dd');
        endDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0), 'yyyy-MM-dd');
      } else if (dateFilterType === 'year') {
        startDate = `${selectedYear}-01-01`;
        endDate = `${selectedYear}-12-31`;
      } else if (dateFilterType === 'custom' && customStartDate && customEndDate) {
        startDate = format(customStartDate, 'yyyy-MM-dd');
        endDate = format(customEndDate, 'yyyy-MM-dd');
      } else {
        // Fallback para mês atual
        startDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth(), 1), 'yyyy-MM-dd');
        endDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0), 'yyyy-MM-dd');
      }
      
      const params = new URLSearchParams({
        start_date: startDate,
        end_date: endDate,
        ...Object.fromEntries(Object.entries(filters).filter(([_, value]) => value !== ''))
      });
      
      console.log('Loading transactions with URL:', `/transactions?${params}`);
      console.log('Filters:', filters);
      
      const response = await api.get(`/transactions?${params}`);
      setTransactions(response.data);
    } catch (error) {
      console.error('Erro ao carregar transações:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadFilterData = async () => {
    try {
      const [categoriesRes, subcategoriesRes, contactsRes, costCentersRes, paymentStatusesRes] = await Promise.all([
        api.get('/categories'),
        api.get('/subcategories'),
        api.get('/contacts'),
        api.get('/cost-centers'),
        api.get('/payment-statuses')
      ]);
      
      setCategories(categoriesRes.data);
      setSubcategories(subcategoriesRes.data);
      setContacts(contactsRes.data);
      setCostCenters(costCentersRes.data);
      setPaymentStatuses(paymentStatusesRes.data);
    } catch (error) {
      console.error('Erro ao carregar dados dos filtros:', error);
    }
  };

  // Seleção de transações
  const handleSelectTransaction = (transactionId: number) => {
    setSelectedTransactions(prev => 
      prev.includes(transactionId) 
        ? prev.filter(id => id !== transactionId)
        : [...prev, transactionId]
    );
  };

  const handleSelectAllTransactions = () => {
    setSelectedTransactions(
      selectedTransactions.length === transactions.length 
        ? [] 
        : transactions.map(t => t.id)
    );
  };

  // Menu de ações
  const handleActionMenuOpen = (event: React.MouseEvent<HTMLElement>, transactionId: number) => {
    setActionMenuAnchorEl(event.currentTarget);
    setSelectedTransactionId(transactionId);
  };

  const handleActionMenuClose = () => {
    setActionMenuAnchorEl(null);
    setSelectedTransactionId(null);
  };

  // Ações de transação
  const handleEditTransaction = (id: number) => {
    console.log('Editar transação:', id);
    handleActionMenuClose();
  };

  const handleDuplicateTransaction = (id: number) => {
    console.log('Duplicar transação:', id);
    handleActionMenuClose();
  };

  const handleDeleteTransaction = async (id: number) => {
    if (window.confirm('Tem certeza que deseja excluir esta transação?')) {
      try {
        await api.delete(`/transactions/${id}`);
        loadTransactions();
      } catch (error) {
        console.error('Erro ao excluir transação:', error);
      }
    }
    handleActionMenuClose();
  };

  const handleMarkAsPaid = async (id: number) => {
    try {
      await api.patch(`/transactions/${id}`, { is_paid: true });
      loadTransactions();
    } catch (error) {
      console.error('Erro ao marcar como pago:', error);
    }
    handleActionMenuClose();
  };

  // Formatação de valor
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Cor do tipo de transação
  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'Receita': return '#4caf50';
      case 'Despesa': return '#f44336';
      case 'Investimento': return '#2196f3';
      default: return '#757575';
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={ptBR}>
      <Box sx={{ p: 3, minHeight: '100vh', bgcolor: '#f5f5f5' }}>
        {/* Header com navegação e filtros */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          {/* Navegação de Data */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <FormControl size="small" sx={{ minWidth: 120 }}>
              <InputLabel>Filtro</InputLabel>
              <Select
                value={dateFilterType}
                label="Filtro"
                onChange={(e) => setDateFilterType(e.target.value as 'month' | 'year' | 'custom')}
              >
                <MenuItem value="month">Mensal</MenuItem>
                <MenuItem value="year">Anual</MenuItem>
                <MenuItem value="custom">Personalizado</MenuItem>
              </Select>
            </FormControl>

            {dateFilterType === 'month' && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <IconButton 
                  onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))}
                  size="small"
                >
                  <ChevronLeftIcon />
                </IconButton>
                <Typography variant="h6" sx={{ minWidth: 120, textAlign: 'center' }}>
                  {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
                </Typography>
                <IconButton 
                  onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))}
                  size="small"
                >
                  <ChevronRightIcon />
                </IconButton>
              </Box>
            )}

            {dateFilterType === 'year' && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <IconButton 
                  onClick={() => setSelectedYear(selectedYear - 1)}
                  size="small"
                >
                  <ChevronLeftIcon />
                </IconButton>
                <Typography variant="h6" sx={{ minWidth: 80, textAlign: 'center' }}>
                  {selectedYear}
                </Typography>
                <IconButton 
                  onClick={() => setSelectedYear(selectedYear + 1)}
                  size="small"
                >
                  <ChevronRightIcon />
                </IconButton>
              </Box>
            )}

            {dateFilterType === 'custom' && (
              <Box sx={{ display: 'flex', gap: 2 }}>
                <DatePicker
                  label="Data Início"
                  value={customStartDate}
                  onChange={(newDate) => setCustomStartDate(newDate)}
                  format="dd/MM/yyyy"
                  slotProps={{ textField: { size: 'small' } }}
                />
                <DatePicker
                  label="Data Fim"
                  value={customEndDate}
                  onChange={(newDate) => setCustomEndDate(newDate)}
                  format="dd/MM/yyyy"
                  slotProps={{ textField: { size: 'small' } }}
                />
              </Box>
            )}
          </Box>

          {/* Estatísticas */}
          <Paper elevation={1} sx={{ p: 2, backgroundColor: '#f5f5f5' }}>
            <Typography variant="body2" color="text.secondary">
              Total: {transactions.length} registros | 
              Receitas: R$ {totalReceitas.toFixed(2)} | 
              Despesas: R$ {totalDespesas.toFixed(2)} | 
              Saldo: R$ {(totalReceitas - totalDespesas).toFixed(2)}
            </Typography>
          </Paper>
        </Box>

        {/* Filtros */}
        <Paper sx={{ p: 3, mb: 3, borderRadius: 3, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Filtros</Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={2}>
              <FormControl fullWidth size="small">
                <InputLabel>Tipo de Registro</InputLabel>
                <Select
                  value={filters.transaction_type}
                  label="Tipo de Registro"
                  onChange={(e) => setFilters(prev => ({ ...prev, transaction_type: e.target.value }))}
                >
                  <MenuItem value="">Todos</MenuItem>
                  <MenuItem value="Despesa">Despesa</MenuItem>
                  <MenuItem value="Receita">Receita</MenuItem>
                  <MenuItem value="Investimento">Investimento</MenuItem>
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Autocomplete
                size="small"
                options={paymentStatuses}
                getOptionLabel={(option) => option.name}
                value={paymentStatuses.find(ps => ps.id.toString() === filters.payment_status_id) || null}
                onChange={(_, newValue) => setFilters(prev => ({ ...prev, payment_status_id: newValue ? newValue.id.toString() : '' }))}
                renderInput={(params) => <TextField {...params} label="Status" />}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Autocomplete
                size="small"
                options={categories.filter(cat => !filters.transaction_type || cat.source_type === filters.transaction_type)}
                getOptionLabel={(option) => option.name}
                value={categories.find(cat => cat.id.toString() === filters.category_id) || null}
                onChange={(_, newValue) => setFilters(prev => ({ 
                  ...prev, 
                  category_id: newValue ? newValue.id.toString() : '',
                  subcategory_id: '' // Reset subcategoria quando mudar categoria
                }))}
                renderInput={(params) => <TextField {...params} label="Categoria" />}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Autocomplete
                size="small"
                options={subcategories.filter(sub => !filters.category_id || sub.category_id.toString() === filters.category_id)}
                getOptionLabel={(option) => option.name}
                value={subcategories.find(sub => sub.id.toString() === filters.subcategory_id) || null}
                onChange={(_, newValue) => setFilters(prev => ({ ...prev, subcategory_id: newValue ? newValue.id.toString() : '' }))}
                renderInput={(params) => <TextField {...params} label="Subcategoria" />}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Autocomplete
                size="small"
                options={contacts}
                getOptionLabel={(option) => option.name}
                value={contacts.find(contact => contact.id.toString() === filters.contact_id) || null}
                onChange={(_, newValue) => setFilters(prev => ({ ...prev, contact_id: newValue ? newValue.id.toString() : '' }))}
                renderInput={(params) => <TextField {...params} label="Contato" />}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Button
                variant="outlined"
                fullWidth
                size="small"
                sx={{ height: 40 }}
                onClick={() => setFilters({
                  transaction_type: '',
                  payment_status_id: '',
                  category_id: '',
                  subcategory_id: '',
                  contact_id: ''
                })}
              >
                Limpar Filtros
              </Button>
            </Grid>
          </Grid>
        </Paper>

        {/* Ações em massa */}
        {selectedTransactions.length > 0 && (
          <Paper sx={{ p: 2, mb: 3, borderRadius: 3, bgcolor: '#e3f2fd' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                {selectedTransactions.length} transação(ões) selecionada(s)
              </Typography>
              <Button size="small" startIcon={<PaidIcon />}>
                Marcar como Pago
              </Button>
              <Button size="small" startIcon={<DeleteIcon />} color="error">
                Excluir Selecionadas
              </Button>
              <Button size="small" startIcon={<DownloadIcon />}>
                Exportar
              </Button>
            </Box>
          </Paper>
        )}

        {/* Tabela */}
        <Paper sx={{ borderRadius: 3, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
          <TableContainer>
            <Table>
              <TableHead sx={{ bgcolor: '#f8f9fa' }}>
                <TableRow>
                  <TableCell padding="checkbox">
                    <Checkbox
                      checked={selectedTransactions.length === transactions.length && transactions.length > 0}
                      indeterminate={selectedTransactions.length > 0 && selectedTransactions.length < transactions.length}
                      onChange={handleSelectAllTransactions}
                    />
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Venc.</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Descrição</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }} align="right">Total (R$)</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Situação</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Ações</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow 
                    key={transaction.id}
                    sx={{ 
                      '&:hover': { bgcolor: '#f5f5f5' },
                      bgcolor: selectedTransactions.includes(transaction.id) ? '#e3f2fd' : 'inherit'
                    }}
                  >
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedTransactions.includes(transaction.id)}
                        onChange={() => handleSelectTransaction(transaction.id)}
                      />
                    </TableCell>
                    
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                        {format(new Date(transaction.transaction_date + 'T00:00:00'), 'dd/MM/yyyy')}
                      </Typography>
                    </TableCell>
                    
                    <TableCell>
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 'bold', mb: 0.5 }}>
                          {transaction.description}
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                          {transaction.contact && (
                            <Chip 
                              label={transaction.contact.name} 
                              size="small" 
                              variant="outlined"
                              sx={{ fontSize: '0.7rem', height: 20 }}
                            />
                          )}
                          {transaction.category && (
                            <Chip 
                              label={`${transaction.category.name}${transaction.subcategory ? ` > ${transaction.subcategory.name}` : ''}`} 
                              size="small" 
                              variant="outlined"
                              sx={{ fontSize: '0.7rem', height: 20 }}
                            />
                          )}
                          {transaction.cost_center && (
                            <Chip 
                              label={transaction.cost_center.name} 
                              size="small" 
                              variant="outlined"
                              sx={{ fontSize: '0.7rem', height: 20 }}
                            />
                          )}
                        </Box>
                      </Box>
                    </TableCell>
                    
                    <TableCell align="right">
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          fontWeight: 'bold',
                          color: getTransactionTypeColor(transaction.transaction_type)
                        }}
                      >
                        {formatCurrency(transaction.amount)}
                      </Typography>
                    </TableCell>
                    
                    <TableCell>
                      <Chip
                        label={transaction.is_paid ? 'Pago' : 'Em aberto'}
                        size="small"
                        color={transaction.is_paid ? 'success' : 'warning'}
                        sx={{ fontSize: '0.7rem' }}
                      />
                    </TableCell>
                    
                    <TableCell>
                      <IconButton
                        size="small"
                        onClick={(e) => handleActionMenuOpen(e, transaction.id)}
                      >
                        <MoreVertIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                
                {transactions.length === 0 && !loading && (
                  <TableRow>
                    <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                      <Typography variant="body2" color="text.secondary">
                        Nenhuma transação encontrada para este período
                      </Typography>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>

        {/* Menu de ações */}
        <Menu
          anchorEl={actionMenuAnchorEl}
          open={Boolean(actionMenuAnchorEl)}
          onClose={handleActionMenuClose}
        >
          <MenuItem onClick={() => selectedTransactionId && handleEditTransaction(selectedTransactionId)}>
            <ListItemIcon>
              <EditIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Editar</ListItemText>
          </MenuItem>
          
          <MenuItem onClick={() => selectedTransactionId && handleDuplicateTransaction(selectedTransactionId)}>
            <ListItemIcon>
              <DuplicateIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Duplicar</ListItemText>
          </MenuItem>
          
          <MenuItem onClick={() => selectedTransactionId && handleMarkAsPaid(selectedTransactionId)}>
            <ListItemIcon>
              <PaidIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Marcar como Pago</ListItemText>
          </MenuItem>
          
          <MenuItem 
            onClick={() => selectedTransactionId && handleDeleteTransaction(selectedTransactionId)}
            sx={{ color: 'error.main' }}
          >
            <ListItemIcon>
              <DeleteIcon fontSize="small" color="error" />
            </ListItemIcon>
            <ListItemText>Excluir</ListItemText>
          </MenuItem>
        </Menu>

        {/* Date Picker Dialog */}
        <Dialog open={datePickerOpen} onClose={() => setDatePickerOpen(false)}>
          <DialogTitle>Selecionar Mês</DialogTitle>
          <DialogContent>
            <DatePicker
              views={['year', 'month']}
              value={currentDate}
              onChange={(newValue) => {
                if (newValue) {
                  setCurrentDate(newValue);
                  setDatePickerOpen(false);
                }
              }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDatePickerOpen(false)}>Cancelar</Button>
          </DialogActions>
        </Dialog>

        {/* FAB para nova transação */}
        <Fab
          color="primary"
          aria-label="add"
          sx={{ position: 'fixed', bottom: 16, right: 16 }}
          onClick={(e) => setNewTransactionMenuAnchor(e.currentTarget)}
        >
          <AddIcon />
        </Fab>

        {/* Menu de nova transação */}
        <Menu
          anchorEl={newTransactionMenuAnchor}
          open={Boolean(newTransactionMenuAnchor)}
          onClose={() => setNewTransactionMenuAnchor(null)}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'left',
          }}
          transformOrigin={{
            vertical: 'bottom',
            horizontal: 'right',
          }}
        >
          <MenuItem disabled sx={{ fontWeight: 'bold', color: 'primary.main' }}>
            + Novo Registro
          </MenuItem>
          <Divider />
          <MenuItem 
            onClick={() => {
              console.log('Criar nova despesa');
              setNewTransactionMenuAnchor(null);
            }}
          >
            <ListItemIcon>
              <RemoveIcon color="error" />
            </ListItemIcon>
            <ListItemText>Despesa</ListItemText>
          </MenuItem>
          <MenuItem 
            onClick={() => {
              console.log('Criar nova receita');
              setNewTransactionMenuAnchor(null);
            }}
          >
            <ListItemIcon>
              <AddIcon color="success" />
            </ListItemIcon>
            <ListItemText>Receita</ListItemText>
          </MenuItem>
          <MenuItem 
            onClick={() => {
              console.log('Criar novo investimento');
              setNewTransactionMenuAnchor(null);
            }}
          >
            <ListItemIcon>
              <TrendingUpIcon color="primary" />
            </ListItemIcon>
            <ListItemText>Investimento</ListItemText>
          </MenuItem>
        </Menu>
      </Box>
    </LocalizationProvider>
  );
}
