import React, { useState, useEffect } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Checkbox,
  IconButton,
  Menu,
  MenuItem,
  Box,
  Autocomplete,
  TextField,
  Chip,
  FormControl,
  InputLabel,
  Select,
  Fab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  ListItemIcon,
  ListItemText,
  Divider,
  FormControlLabel,
  Switch,
  Snackbar,
  Alert,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import {
  Add as AddIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  FileCopy as DuplicateIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  CalendarToday as CalendarIcon,
  Download as DownloadIcon,
  Paid as PaidIcon,
  Remove as RemoveIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as ExpenseIcon,
  TrendingUp as IncomeIcon,
  ShowChart as InvestmentIcon,
  FilterList as FilterIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { ptBR } from 'date-fns/locale';
import { format, addMonths, subMonths } from 'date-fns';
import api from '../services/api';
import axios from 'axios';

interface Transaction {
  id: number;
  description: string;
  amount: number;
  transaction_date: string;
  transaction_type: 'Despesa' | 'Receita' | 'Investimento';
  is_paid: boolean;
  contact?: {
    id: number;
    name: string;
  };
  category?: {
    id: number;
    name: string;
  };
  subcategory?: {
    id: number;
    name: string;
  };
  cost_center?: {
    id: number;
    name: string;
  };
}

interface Category {
  id: number;
  name: string;
  source_type: string;
}

interface Subcategory {
  id: number;
  name: string;
  category_id: number;
}

interface Contact {
  id: number;
  name: string;
}

interface CostCenter {
  id: number;
  name: string;
  number?: string;
}

interface PaymentStatus {
  id: number;
  name: string;
}

interface Filters {
  transaction_type: string;
  payment_status_id: string;
  category_id: string;
  subcategory_id: string;
  contact_id: string;
  cost_center_id: string;
}

export default function MonthlyControl() {
  // Responsividade
  const theme = useTheme();
  const isMediumScreen = useMediaQuery(theme.breakpoints.up('md'));
  
  // Estados
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [monthPickerOpen, setMonthPickerOpen] = useState(false);
  
  // Estados para filtros avançados de data
  const [dateFilterType, setDateFilterType] = useState<'month' | 'year' | 'custom'>('month');
  const [customStartDate, setCustomStartDate] = useState<Date | null>(null);
  const [customEndDate, setCustomEndDate] = useState<Date | null>(null);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  
  // Estados para filtros
  const [filters, setFilters] = useState<Filters>({
    transaction_type: '',
    payment_status_id: '',
    category_id: '',
    subcategory_id: '',
    contact_id: '',
    cost_center_id: ''
  });
  
  // Estados para dados dos filtros
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [paymentStatuses, setPaymentStatuses] = useState<PaymentStatus[]>([]);
  
  // Estados para seleção e ações
  const [selectedTransactions, setSelectedTransactions] = useState<number[]>([]);
  const [actionMenuAnchorEl, setActionMenuAnchorEl] = useState<HTMLElement | null>(null);
  const [selectedTransactionId, setSelectedTransactionId] = useState<number | null>(null);
  const [newTransactionMenuAnchor, setNewTransactionMenuAnchor] = useState<HTMLElement | null>(null);
  const [moreFiltersOpen, setMoreFiltersOpen] = useState<boolean>(false);
  const [batchActionsAnchor, setBatchActionsAnchor] = useState<HTMLElement | null>(null);

  // Estados para modal de criação/edição de transação
  const [transactionDialogOpen, setTransactionDialogOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    transaction_date: new Date().toISOString().split('T')[0],
    category_id: '',
    subcategory_id: '',
    payment_status_id: '',
    contact_id: '',
    cost_center_id: '',
    transaction_type: 'Despesa' as 'Despesa' | 'Receita' | 'Investimento',
    is_recurring: false,
    recurrence_type: 'mensal' as 'unica' | 'diaria' | 'semanal' | 'mensal' | 'anual' | 'personalizada',
    recurrence_count: 1 as number | string,
    recurrence_interval: 1,
    recurrence_weekday: 1,
    is_paid: false
  });

  // Estado para preview de recorrências
  const [recurrencePreview, setRecurrencePreview] = useState<Array<{
    creation_date: string;
    due_date: string;
    description: string;
    amount: number;
  }>>([]);

  // Estados de notificação
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error' | 'warning' | 'info'
  });

  // Cálculo dos totais e status de vencimento
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const totalReceitas = transactions
    .filter(t => t.transaction_type === 'Receita')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const totalDespesas = transactions
    .filter(t => t.transaction_type === 'Despesa')
    .reduce((sum, t) => sum + t.amount, 0);

  // Cálculos dos totalizadores
  const vencidos = transactions.filter(t => {
    const transactionDate = new Date(t.transaction_date + 'T00:00:00');
    transactionDate.setHours(0, 0, 0, 0);
    return !t.is_paid && transactionDate < today;
  });

  const vencemHoje = transactions.filter(t => {
    const transactionDate = new Date(t.transaction_date + 'T00:00:00');
    transactionDate.setHours(0, 0, 0, 0);
    return !t.is_paid && transactionDate.getTime() === today.getTime();
  });

  const aVencer = transactions.filter(t => {
    const transactionDate = new Date(t.transaction_date + 'T00:00:00');
    transactionDate.setHours(0, 0, 0, 0);
    return !t.is_paid && transactionDate > today;
  });

  const totalVencidos = vencidos.reduce((sum, t) => sum + (t.transaction_type === 'Despesa' ? -t.amount : t.amount), 0);
  const totalVencemHoje = vencemHoje.reduce((sum, t) => sum + (t.transaction_type === 'Despesa' ? -t.amount : t.amount), 0);
  const totalAVencer = aVencer.reduce((sum, t) => sum + (t.transaction_type === 'Despesa' ? -t.amount : t.amount), 0);
  const saldoPeriodo = totalReceitas - totalDespesas;

  // Carregar dados iniciais
  useEffect(() => {
    console.log("useEffect para carregar dados foi acionado. Dependências:", {
      currentDate,
      filters,
      dateFilterType,
      customStartDate,
      customEndDate,
      selectedYear,
    });
    loadTransactions();
    loadFilterData();
  }, [currentDate, filters, dateFilterType, customStartDate, customEndDate, selectedYear]);

  // Atualizar preview de recorrências quando dados do formulário mudam
  useEffect(() => {
    if (formData.is_recurring && formData.transaction_date && formData.amount) {
      generateRecurrencePreview();
    } else {
      setRecurrencePreview([]);
    }
  }, [formData.is_recurring, formData.recurrence_type, formData.recurrence_count, formData.recurrence_interval, formData.recurrence_weekday, formData.transaction_date, formData.amount, formData.description]);

  // Função para gerar preview de recorrências
  const generateRecurrencePreview = () => {
    const count = typeof formData.recurrence_count === 'string' ? parseInt(formData.recurrence_count) || 0 : formData.recurrence_count;
    
    if (!formData.transaction_date || !formData.amount || count < 1) {
      setRecurrencePreview([]);
      return;
    }

    const previews: Array<{
      creation_date: string;
      due_date: string;
      description: string;
      amount: number;
    }> = [];
    
    const amount = parseFloat(formData.amount.toString().replace(/\./g, '').replace(',', '.')) || parseFloat(formData.amount);

    // Função para adicionar meses sem usar Date
    const addMonths = (dateStr: string, months: number): string => {
      const [year, month, day] = dateStr.split('-').map(Number);
      let newYear = year;
      let newMonth = month + months;
      
      while (newMonth > 12) {
        newMonth -= 12;
        newYear += 1;
      }
      
      // Verificar se o dia existe no novo mês
      const daysInMonth = new Date(newYear, newMonth, 0).getDate();
      const newDay = Math.min(day, daysInMonth);
      
      return newYear + '-' + String(newMonth).padStart(2, '0') + '-' + String(newDay).padStart(2, '0');
    };

    // Função para adicionar dias sem usar Date
    const addDays = (dateStr: string, days: number): string => {
      const [year, month, day] = dateStr.split('-').map(Number);
      const date = new Date(year, month - 1, day + days);
      return date.getFullYear() + '-' + 
             String(date.getMonth() + 1).padStart(2, '0') + '-' + 
             String(date.getDate()).padStart(2, '0');
    };

    for (let i = 0; i < count; i++) {
      let resultDate: string = formData.transaction_date; // Inicializar com valor padrão
      
      if (i === 0) {
        // PRIMEIRA PARCELA: usar EXATAMENTE a data do formulário
        resultDate = formData.transaction_date;
      } else {
        // DEMAIS PARCELAS
        switch (formData.recurrence_type) {
          case 'semanal':
            if (i === 1) {
              // SEGUNDA OCORRÊNCIA: Calcular próxima ocorrência do dia da semana selecionado
              const [year, month, day] = formData.transaction_date.split('-').map(Number);
              const baseDate = new Date(year, month - 1, day);
              const currentDayOfWeek = baseDate.getDay(); // 0=domingo, 1=segunda, etc.
              const targetDayOfWeek = formData.recurrence_weekday; // 0=domingo, 1=segunda, etc.
              
              // Calcular quantos dias até o próximo dia alvo
              let daysUntilTarget = (targetDayOfWeek - currentDayOfWeek + 7) % 7;
              if (daysUntilTarget === 0) daysUntilTarget = 7; // Se for o mesmo dia, vai para a próxima semana
              
              const nextDate = new Date(year, month - 1, day + daysUntilTarget);
              resultDate = nextDate.getFullYear() + '-' + 
                          String(nextDate.getMonth() + 1).padStart(2, '0') + '-' + 
                          String(nextDate.getDate()).padStart(2, '0');
            } else if (i > 1) {
              // TERCEIRA OCORRÊNCIA EM DIANTE: Adicionar 7 dias à segunda ocorrência
              const [year, month, day] = formData.transaction_date.split('-').map(Number);
              const baseDate = new Date(year, month - 1, day);
              const currentDayOfWeek = baseDate.getDay();
              const targetDayOfWeek = formData.recurrence_weekday;
              
              let daysUntilTarget = (targetDayOfWeek - currentDayOfWeek + 7) % 7;
              if (daysUntilTarget === 0) daysUntilTarget = 7;
              
              // Adicionar semanas adicionais
              const totalDays = daysUntilTarget + (7 * (i - 1));
              const futureDate = new Date(year, month - 1, day + totalDays);
              resultDate = futureDate.getFullYear() + '-' + 
                          String(futureDate.getMonth() + 1).padStart(2, '0') + '-' + 
                          String(futureDate.getDate()).padStart(2, '0');
            }
            break;
          case 'mensal':
            resultDate = addMonths(formData.transaction_date, i);
            break;
          case 'anual':
            const [year, month, day] = formData.transaction_date.split('-');
            resultDate = (parseInt(year) + i) + '-' + month + '-' + day;
            break;
          case 'personalizada':
            resultDate = addDays(formData.transaction_date, i * (formData.recurrence_interval || 1));
            break;
          default:
            resultDate = formData.transaction_date;
        }
      }

      previews.push({
        creation_date: resultDate,
        due_date: resultDate,
        description: formData.description || 'Nova transação',
        amount: amount
      });
    }

    setRecurrencePreview(previews);
  };

  const loadTransactions = async () => {
    console.log("Iniciando loadTransactions...");
    try {
      setLoading(true);
      
      let startDate: string;
      let endDate: string;
      
      if (dateFilterType === 'month') {
        startDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth(), 1), 'yyyy-MM-dd');
        endDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0), 'yyyy-MM-dd');
      } else if (dateFilterType === 'year') {
        startDate = `${selectedYear}-01-01`;
        endDate = `${selectedYear}-12-31`;
      } else if (dateFilterType === 'custom' && customStartDate && customEndDate) {
        startDate = format(customStartDate, 'yyyy-MM-dd');
        endDate = format(customEndDate, 'yyyy-MM-dd');
      } else {
        // Fallback para mês atual
        startDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth(), 1), 'yyyy-MM-dd');
        endDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0), 'yyyy-MM-dd');
      }
      
      // Preparar parâmetros de filtro
      const baseParams = {
        start_date: startDate,
        end_date: endDate,
        ...Object.fromEntries(Object.entries(filters).filter(([key, value]) => {
          // Tratar filtro de pagamento separadamente e excluir filtros especiais
          if (key === 'payment_status_id') {
            return !value.startsWith('FILTER_'); // Não incluir filtros especiais nos parâmetros da URL
          }
          return value !== '';
        }))
      };
      
      const params = new URLSearchParams(baseParams);
      
      console.log('Enviando requisição para /api/transactions com os parâmetros:', params.toString());
      
      const response = await api.get(`/transactions?${params}`);
      console.log("Resposta da API recebida:", response.data);
      
      // Aplicar filtro de pagamento no frontend
      let filteredTransactions = response.data;
      
      if (filters.payment_status_id === 'FILTER_OVERDUE') {
        // Filtrar apenas transações vencidas
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        filteredTransactions = filteredTransactions.filter((t: any) => {
          if (t.payment_status_id === 2) return false; // Não incluir pagas
          const transactionDate = new Date(t.transaction_date + 'T00:00:00');
          transactionDate.setHours(0, 0, 0, 0);
          return transactionDate < today;
        });
      } else if (filters.payment_status_id === 'FILTER_DUE_TODAY') {
        // Filtrar apenas transações que vencem hoje
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        filteredTransactions = filteredTransactions.filter((t: any) => {
          if (t.payment_status_id === 2) return false; // Não incluir pagas
          const transactionDate = new Date(t.transaction_date + 'T00:00:00');
          transactionDate.setHours(0, 0, 0, 0);
          return transactionDate.getTime() === today.getTime();
        });
      } else if (filters.payment_status_id && !filters.payment_status_id.startsWith('FILTER_')) {
        // Se há um filtro de payment_status_id específico, aplicar diretamente
        filteredTransactions = filteredTransactions.filter((t: any) => 
          t.payment_status_id.toString() === filters.payment_status_id
        );
      }
      
      setTransactions(filteredTransactions.map((transaction: any) => ({
        ...transaction,
        // Mapear os dados relacionados para o formato esperado pelo frontend
        contact: transaction.contact_name ? { 
          id: transaction.contact_id, 
          name: transaction.contact_name 
        } : null,
        category: transaction.category_name ? { 
          id: transaction.category_id, 
          name: transaction.category_name 
        } : null,
        subcategory: transaction.subcategory_name ? { 
          id: transaction.subcategory_id, 
          name: transaction.subcategory_name 
        } : null,
        cost_center: transaction.cost_center_name ? { 
          id: transaction.cost_center_number || transaction.cost_center_id, 
          name: transaction.cost_center_name 
        } : null,
        // Converter o campo is_paid baseado no payment_status_id
        is_paid: transaction.payment_status_id === 2
      })).sort((a: any, b: any) => {
        // Ordenar por data da transação (mais antigas primeiro)
        const dateA = new Date(a.transaction_date + 'T00:00:00');
        const dateB = new Date(b.transaction_date + 'T00:00:00');
        return dateA.getTime() - dateB.getTime();
      }));
    } catch (error) {
      console.error('Erro detalhado ao carregar transações:', error);
      if (axios.isAxiosError(error)) {
        console.error("Detalhes do erro Axios:", {
          message: error.message,
          config: error.config,
          response: error.response?.data,
          status: error.response?.status,
        });
      }
    } finally {
      console.log("Finalizando loadTransactions.");
      setLoading(false);
    }
  };

  const loadFilterData = async () => {
    try {
      const [categoriesRes, subcategoriesRes, contactsRes, costCentersRes, paymentStatusesRes] = await Promise.all([
        api.get('/categories'),
        api.get('/subcategories'),
        api.get('/contacts'),
        api.get('/cost-centers'),
        api.get('/payment-statuses')
      ]);
      
      setCategories(categoriesRes.data);
      setSubcategories(subcategoriesRes.data);
      setContacts(contactsRes.data);
      setCostCenters(costCentersRes.data);
      setPaymentStatuses(paymentStatusesRes.data);
    } catch (error) {
      console.error('Erro ao carregar dados dos filtros:', error);
    }
  };

  // Seleção de transações
  const handleSelectTransaction = (transactionId: number) => {
    setSelectedTransactions(prev => 
      prev.includes(transactionId) 
        ? prev.filter(id => id !== transactionId)
        : [...prev, transactionId]
    );
  };

  const handleSelectAllTransactions = () => {
    setSelectedTransactions(
      selectedTransactions.length === transactions.length 
        ? [] 
        : transactions.map(t => t.id)
    );
  };

  // Menu de ações
  const handleActionMenuOpen = (event: React.MouseEvent<HTMLElement>, transactionId: number) => {
    setActionMenuAnchorEl(event.currentTarget);
    setSelectedTransactionId(transactionId);
  };

  const handleActionMenuClose = () => {
    setActionMenuAnchorEl(null);
    setSelectedTransactionId(null);
  };

  // Ações de transação
  const handleDuplicateTransaction = (id: number) => {
    console.log('Duplicar transação:', id);
    handleActionMenuClose();
  };

  const handleDeleteTransaction = async (id: number) => {
    if (window.confirm('Tem certeza que deseja excluir esta transação?')) {
      try {
        await api.delete(`/transactions/${id}`);
        loadTransactions();
      } catch (error) {
        console.error('Erro ao excluir transação:', error);
      }
    }
    handleActionMenuClose();
  };

  const handleMarkAsPaid = async (id: number) => {
    try {
      await api.patch(`/transactions/${id}`, { is_paid: true });
      loadTransactions();
    } catch (error) {
      console.error('Erro ao marcar como pago:', error);
    }
    handleActionMenuClose();
  };

  // Ações em lote
  const handleBatchMarkAsPaid = async () => {
    if (selectedTransactions.length === 0) return;
    
    try {
      await Promise.all(
        selectedTransactions.map(id => 
          api.patch(`/transactions/${id}`, { is_paid: true })
        )
      );
      setSelectedTransactions([]);
      loadTransactions();
      showSnackbar(`${selectedTransactions.length} transações marcadas como pagas`);
    } catch (error) {
      console.error('Erro ao marcar transações como pagas:', error);
      showSnackbar('Erro ao marcar transações como pagas', 'error');
    }
    setBatchActionsAnchor(null);
  };

  const handleBatchDelete = async () => {
    if (selectedTransactions.length === 0) return;
    
    if (window.confirm(`Tem certeza que deseja excluir ${selectedTransactions.length} transação(ões) selecionada(s)?`)) {
      try {
        await Promise.all(
          selectedTransactions.map(id => 
            api.delete(`/transactions/${id}`)
          )
        );
        setSelectedTransactions([]);
        loadTransactions();
        showSnackbar(`${selectedTransactions.length} transações excluídas`);
      } catch (error) {
        console.error('Erro ao excluir transações:', error);
        showSnackbar('Erro ao excluir transações', 'error');
      }
    }
    setBatchActionsAnchor(null);
  };

  // Funções para modal de transação
  const showSnackbar = (message: string, severity: 'success' | 'error' | 'warning' | 'info' = 'success') => {
    setSnackbar({
      open: true,
      message,
      severity
    });
  };

  const handleNewTransaction = (type: 'Despesa' | 'Receita' | 'Investimento') => {
    setFormData({
      description: '',
      amount: '',
      transaction_date: new Date().toISOString().split('T')[0],
      category_id: '',
      subcategory_id: '',
      payment_status_id: '',
      contact_id: '',
      cost_center_id: '',
      transaction_type: type,
      is_recurring: false,
      recurrence_type: 'mensal',
      recurrence_count: 1,
      recurrence_interval: 1,
      recurrence_weekday: 1,
      is_paid: false
    });
    setEditingTransaction(null);
    setRecurrencePreview([]);
    setTransactionDialogOpen(true);
    setNewTransactionMenuAnchor(null);
  };

  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setFormData({
      description: transaction.description,
      amount: transaction.amount.toString(),
      transaction_date: transaction.transaction_date.split('T')[0],
      category_id: transaction.category?.id?.toString() || '',
      subcategory_id: transaction.subcategory?.id?.toString() || '',
      payment_status_id: '', // Não disponível na interface atual
      contact_id: transaction.contact?.id?.toString() || '',
      cost_center_id: transaction.cost_center?.id?.toString() || '',
      transaction_type: transaction.transaction_type,
      is_recurring: false, // Default para edição
      recurrence_type: 'mensal',
      recurrence_count: 1,
      recurrence_interval: 1,
      recurrence_weekday: 1,
      is_paid: transaction.is_paid || false
    });
    setRecurrencePreview([]);
    setTransactionDialogOpen(true);
    handleActionMenuClose();
  };

  const handleCloseTransactionDialog = () => {
    setTransactionDialogOpen(false);
    setEditingTransaction(null);
  };

  const handleTransactionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const transactionData = {
        description: formData.description,
        amount: typeof formData.amount === 'string' 
          ? parseFloat(formData.amount.replace(/\./g, '').replace(',', '.')) 
          : parseFloat(formData.amount),
        transaction_type: formData.transaction_type,
        transaction_date: formData.transaction_date,
        category_id: formData.category_id ? parseInt(formData.category_id) : null,
        subcategory_id: formData.subcategory_id ? parseInt(formData.subcategory_id) : null,
        payment_status_id: formData.payment_status_id ? parseInt(formData.payment_status_id) : null,
        contact_id: formData.contact_id ? parseInt(formData.contact_id) : null,
        cost_center_id: formData.cost_center_id ? parseInt(formData.cost_center_id) : null,
        is_recurring: formData.is_recurring,
        recurrence_type: formData.is_recurring ? formData.recurrence_type : null,
        recurrence_count: formData.is_recurring ? formData.recurrence_count : null,
        recurrence_interval: formData.is_recurring && formData.recurrence_type === 'personalizada' ? formData.recurrence_interval : null,
        recurrence_weekday: formData.is_recurring && formData.recurrence_type === 'semanal' ? formData.recurrence_weekday : null,
        is_paid: formData.is_paid
      };

      if (editingTransaction) {
        await api.put(`/transactions/${editingTransaction.id}`, transactionData);
        showSnackbar('Transação atualizada com sucesso!');
      } else {
        await api.post('/transactions', transactionData);
        showSnackbar('Transação criada com sucesso!');
      }

      handleCloseTransactionDialog();
      loadTransactions();
    } catch (error) {
      console.error('Erro ao salvar transação:', error);
      showSnackbar('Erro ao salvar transação', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Formatação de valor
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Cor do tipo de transação
  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'Receita': return '#4caf50';
      case 'Despesa': return '#f44336';
      case 'Investimento': return '#2196f3';
      default: return '#757575';
    }
  };

  // Verificar se transação está vencida
  const isTransactionOverdue = (transaction: Transaction) => {
    if (transaction.is_paid) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const transactionDate = new Date(transaction.transaction_date + 'T00:00:00');
    transactionDate.setHours(0, 0, 0, 0);
    return transactionDate < today;
  };

  // Verificar se transação vence hoje
  const isTransactionDueToday = (transaction: Transaction) => {
    if (transaction.is_paid) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const transactionDate = new Date(transaction.transaction_date + 'T00:00:00');
    transactionDate.setHours(0, 0, 0, 0);
    return transactionDate.getTime() === today.getTime();
  };

  // Obter status da transação
  const getTransactionStatus = (transaction: Transaction) => {
    if (transaction.is_paid) return 'Pago';
    if (isTransactionOverdue(transaction)) return 'Vencido';
    return 'Em aberto';
  };

  // Obter cor do status
  const getStatusColor = (transaction: Transaction) => {
    if (transaction.is_paid) return { bg: '#e8f5e8', color: '#2e7d32', border: '#4caf50' };
    if (isTransactionOverdue(transaction)) return { bg: '#ffebee', color: '#d32f2f', border: '#f44336' };
    return { bg: '#fff3e0', color: '#f57c00', border: '#ff9800' };
  };

  // Funções para filtros rápidos dos totalizadores
  const applyVencidosFilter = () => {
    // Para filtrar vencidos, vamos usar um filtro especial
    setFilters(prev => ({
      ...prev,
      payment_status_id: 'FILTER_OVERDUE', // Flag especial
      transaction_type: ''
    }));
  };

  const applyVencemHojeFilter = () => {
    // Para filtrar vencem hoje, vamos usar um filtro especial
    setFilters(prev => ({
      ...prev,
      payment_status_id: 'FILTER_DUE_TODAY', // Flag especial
      transaction_type: ''
    }));
  };

  const applyAVencerFilter = () => {
    setFilters(prev => ({
      ...prev,
      payment_status_id: '1', // Em aberto
      transaction_type: ''
    }));
  };

  const applyReceitasFilter = () => {
    setFilters(prev => ({
      ...prev,
      transaction_type: 'Receita',
      payment_status_id: ''
    }));
  };

  const applyDespesasFilter = () => {
    setFilters(prev => ({
      ...prev,
      transaction_type: 'Despesa',
      payment_status_id: ''
    }));
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={ptBR}>
      <Box sx={{ p: 3, minHeight: '100vh', bgcolor: '#EDF5FD' }}>
        {/* Header com Navegação e Filtros */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 3, mb: 2, flexWrap: 'wrap' }}>
          {/* Container dos Filtros */}
          <Paper 
            sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: { xs: 1, sm: 2 }, 
              width: '100%',
              p: { xs: 1, sm: 2 },
              borderRadius: 2,
              bgcolor: 'white',
              boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
              border: '1px solid #e0e0e0',
              flexWrap: { xs: 'wrap', lg: 'nowrap' }
            }}
          >
            {/* Seletor de Período */}
            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: 1,
              width: { xs: '100%', lg: 'auto' },
              mb: { xs: 1, lg: 0 }
            }}>
              <FormControl size="small" sx={{ minWidth: { xs: 100, sm: 120 } }}>
                <InputLabel>Período</InputLabel>
                <Select
                  value={dateFilterType}
                  label="Período"
                  onChange={(e) => setDateFilterType(e.target.value as 'month' | 'year' | 'custom')}
                  sx={{ 
                    bgcolor: 'white',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#e0e0e0',
                    }
                  }}
                >
                  <MenuItem value="month">Mês</MenuItem>
                  <MenuItem value="year">Ano</MenuItem>
                  <MenuItem value="custom">Personalizado</MenuItem>
                </Select>
              </FormControl>

              {dateFilterType === 'month' && (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <IconButton
                    size="small"
                    onClick={() => setCurrentDate(prev => subMonths(prev, 1))}
                    sx={{ color: '#666' }}
                  >
                    <ChevronLeftIcon />
                  </IconButton>
                  <Button
                    variant="outlined"
                    onClick={() => setMonthPickerOpen(true)}
                    sx={{ 
                      minWidth: { xs: 120, sm: 150 }, 
                      textAlign: 'center', 
                      fontWeight: 400,
                      textTransform: 'capitalize',
                      fontSize: { xs: '0.875rem', sm: '1rem' },
                      borderColor: '#ddd',
                      color: '#666',
                      bgcolor: 'white',
                      '&:hover': {
                        bgcolor: '#f8f9fa',
                        borderColor: '#1976d2',
                        color: '#1976d2',
                      },
                      borderRadius: 2,
                      border: '1px solid #ddd'
                    }}
                    startIcon={<CalendarIcon sx={{ fontSize: '1rem' }} />}
                  >
                    {format(currentDate, 'MMM yyyy', { locale: ptBR })}
                  </Button>
                  <IconButton
                    size="small"
                    onClick={() => setCurrentDate(prev => addMonths(prev, 1))}
                    sx={{ color: '#666' }}
                  >
                    <ChevronRightIcon />
                  </IconButton>
                  
                  {/* Modal do seletor de mês/ano */}
                  <Dialog
                    open={monthPickerOpen}
                    onClose={() => setMonthPickerOpen(false)}
                    maxWidth="xs"
                    fullWidth
                  >
                    <DialogTitle sx={{ textAlign: 'center', pb: 1 }}>
                      Selecionar Período
                    </DialogTitle>
                    <DialogContent sx={{ pt: 1 }}>
                      <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={ptBR}>
                        <DatePicker
                          views={['year', 'month']}
                          value={currentDate}
                          onChange={(newValue) => {
                            if (newValue) {
                              setCurrentDate(newValue);
                              setMonthPickerOpen(false);
                            }
                          }}
                          slotProps={{
                            textField: {
                              fullWidth: true,
                              variant: 'outlined',
                              sx: { mb: 2 }
                            }
                          }}
                        />
                      </LocalizationProvider>
                    </DialogContent>
                    <DialogActions>
                      <Button onClick={() => setMonthPickerOpen(false)}>
                        Cancelar
                      </Button>
                    </DialogActions>
                  </Dialog>
                </Box>
              )}

              {dateFilterType === 'year' && (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <IconButton
                    size="small"
                    onClick={() => setSelectedYear(prev => prev - 1)}
                    sx={{ color: '#666' }}
                  >
                    <ChevronLeftIcon />
                  </IconButton>
                  <Typography variant="body1" sx={{ 
                    minWidth: 80, 
                    textAlign: 'center', 
                    fontWeight: 500 
                  }}>
                    {selectedYear}
                  </Typography>
                  <IconButton
                    size="small"
                    onClick={() => setSelectedYear(prev => prev + 1)}
                    sx={{ color: '#666' }}
                  >
                    <ChevronRightIcon />
                  </IconButton>
                </Box>
              )}

              {dateFilterType === 'custom' && (
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 1,
                  flexWrap: { xs: 'wrap', sm: 'nowrap' }
                }}>
                  <DatePicker
                    label="Data inicial"
                    value={customStartDate}
                    onChange={(newValue) => setCustomStartDate(newValue)}
                    slotProps={{
                      textField: { 
                        size: 'small',
                        sx: { width: { xs: 120, sm: 140 }, bgcolor: 'white' }
                      }
                    }}
                  />
                  <Typography variant="body2" sx={{ color: '#666' }}>até</Typography>
                  <DatePicker
                    label="Data final"
                    value={customEndDate}
                    onChange={(newValue) => setCustomEndDate(newValue)}
                    slotProps={{
                      textField: { 
                        size: 'small',
                        sx: { width: { xs: 120, sm: 140 }, bgcolor: 'white' }
                      }
                    }}
                  />
                </Box>
              )}
            </Box>

            {/* Separador Visual */}
            <Divider 
              orientation="vertical" 
              flexItem 
              sx={{ 
                mx: 1,
                display: { xs: 'none', lg: 'block' }
              }} 
            />

            {/* Filtros Principais */}
            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: { xs: 1, sm: 2 }, 
              flex: 1,
              flexWrap: { xs: 'wrap', lg: 'nowrap' },
              width: { xs: '100%', lg: 'auto' }
            }}>
              <FormControl size="small" sx={{ minWidth: { xs: 120, sm: 150 } }}>
                <InputLabel>Situação</InputLabel>
                <Select
                  value={filters.payment_status_id}
                  label="Situação"
                  onChange={(e) => setFilters(prev => ({ ...prev, payment_status_id: e.target.value }))}
                  sx={{ 
                    bgcolor: 'white',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#e0e0e0',
                    }
                  }}
                >
                  <MenuItem value="">Todos</MenuItem>
                  {paymentStatuses.map((status) => (
                    <MenuItem key={status.id} value={status.id.toString()}>
                      {status.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <FormControl size="small" sx={{ minWidth: { xs: 140, sm: 180 } }}>
                <InputLabel>Tipo de Registro</InputLabel>
                <Select
                  value={filters.transaction_type}
                  label="Tipo de Registro"
                  onChange={(e) => setFilters(prev => ({ ...prev, transaction_type: e.target.value }))}
                  sx={{ 
                    bgcolor: 'white',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#e0e0e0',
                    }
                  }}
                >
                  <MenuItem value="">Todos</MenuItem>
                  <MenuItem value="Despesa">Despesa</MenuItem>
                  <MenuItem value="Receita">Receita</MenuItem>
                  <MenuItem value="Investimento">Investimento</MenuItem>
                </Select>
              </FormControl>

              <FormControl size="small" sx={{ minWidth: { xs: 140, sm: 180 } }}>
                <InputLabel>Centro de Custo</InputLabel>
                <Select
                  value={filters.cost_center_id}
                  label="Centro de Custo"
                  onChange={(e) => setFilters(prev => ({ ...prev, cost_center_id: e.target.value }))}
                  sx={{ 
                    bgcolor: 'white',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#e0e0e0',
                    }
                  }}
                >
                  <MenuItem value="">Todos</MenuItem>
                  {costCenters.map((costCenter) => (
                    <MenuItem key={costCenter.id} value={costCenter.id.toString()}>
                      {costCenter.number || costCenter.id} - {costCenter.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>

            {/* Botões de Ação */}
            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: 1,
              mt: { xs: 1, lg: 0 },
              width: { xs: '100%', lg: 'auto' },
              justifyContent: { xs: 'flex-end', lg: 'flex-start' }
            }}>
              <IconButton
                size="small"
                onClick={() => setMoreFiltersOpen(!moreFiltersOpen)}
                sx={{ 
                  color: '#666',
                  bgcolor: 'transparent',
                  border: '1px solid #ddd',
                  '&:hover': {
                    bgcolor: '#f5f5f5',
                    color: '#1976d2',
                    borderColor: '#1976d2',
                  }
                }}
              >
                <FilterIcon fontSize="small" />
              </IconButton>
            </Box>
          </Paper>
        </Box>

        {/* Painel de Filtros */}
        {moreFiltersOpen && (
          <Paper sx={{ p: 2, mb: 3, borderRadius: 1, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <Grid container spacing={2} alignItems="center">
              <Grid item xs={12} sm={6} md={3}>
                <Autocomplete
                  size="small"
                  options={categories.filter(cat => !filters.transaction_type || cat.source_type === filters.transaction_type)}
                  getOptionLabel={(option) => option.name}
                  value={categories.find(cat => cat.id.toString() === filters.category_id) || null}
                  onChange={(_, newValue) => setFilters(prev => ({ 
                    ...prev, 
                    category_id: newValue ? newValue.id.toString() : '',
                    subcategory_id: ''
                  }))}
                  renderOption={(props, option) => (
                    <Box component="li" {...props} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Box sx={{ color: option.source_type === 'Despesa' ? '#f44336' : '#4caf50' }}>
                        {option.source_type === 'Despesa' && <ExpenseIcon fontSize="small" />}
                        {option.source_type === 'Receita' && <IncomeIcon fontSize="small" />}
                        {option.source_type === 'Investimento' && <InvestmentIcon fontSize="small" />}
                      </Box>
                      {option.name}
                    </Box>
                  )}
                  renderInput={(params) => <TextField {...params} label="Categoria" />}
                />
              </Grid>

              <Grid item xs={12} sm={6} md={3}>
                <Autocomplete
                  size="small"
                  options={subcategories.filter(sub => 
                    filters.category_id ? 
                    sub.category_id.toString() === filters.category_id : 
                    false
                  )}
                  getOptionLabel={(option) => option.name}
                  value={subcategories.find(sub => sub.id.toString() === filters.subcategory_id) || null}
                  onChange={(_, newValue) => setFilters(prev => ({ ...prev, subcategory_id: newValue ? newValue.id.toString() : '' }))}
                  renderInput={(params) => <TextField {...params} label="Subcategoria" />}
                  disabled={!filters.category_id}
                />
              </Grid>

              <Grid item xs={12} sm={6} md={3}>
                <Autocomplete
                  size="small"
                  options={contacts}
                  getOptionLabel={(option) => option.name}
                  value={contacts.find(contact => contact.id.toString() === filters.contact_id) || null}
                  onChange={(_, newValue) => setFilters(prev => ({ ...prev, contact_id: newValue ? newValue.id.toString() : '' }))}
                  renderInput={(params) => <TextField {...params} label="Contato" />}
                />
              </Grid>

              <Grid item xs={12} sm={6} md={3}>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<ClearIcon />}
                    sx={{ 
                      flex: 1,
                      height: 40,
                      color: '#666',
                      borderColor: '#e0e0e0',
                      '&:hover': {
                        bgcolor: '#f5f5f5',
                        borderColor: '#d0d0d0'
                      }
                    }}
                    onClick={() => setFilters({
                      transaction_type: '',
                      payment_status_id: '',
                      category_id: '',
                      subcategory_id: '',
                      contact_id: '',
                      cost_center_id: ''
                    })}
                  >
                    Limpar
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    sx={{ 
                      flex: 1,
                      height: 40,
                      color: '#1976d2',
                      borderColor: '#1976d2',
                      '&:hover': {
                        bgcolor: '#f0f7ff',
                        borderColor: '#1976d2'
                      }
                    }}
                    onClick={() => setMoreFiltersOpen(false)}
                  >
                    Fechar
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </Paper>
        )}

        {/* Totalizadores */}
        <Grid container spacing={1} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={6} md={2.4}>
            <Paper 
              onClick={applyVencidosFilter}
              sx={{ 
                p: 2, 
                textAlign: 'center',
                border: '1px solid #e0e0e0',
                borderRadius: 1,
                bgcolor: 'white',
                boxShadow: 'none',
                cursor: 'pointer',
                transition: 'border-color 0.2s ease',
                '&:hover': {
                  borderColor: '#b71c1c'
                }
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 'bold', color: '#666', mb: 0.5 }}>
                Vencidos (R$)
              </Typography>
              <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#f44336' }}>
                {formatCurrency(Math.abs(totalVencidos)).replace('R$', '').trim()}
              </Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={2.4}>
            <Paper 
              onClick={applyVencemHojeFilter}
              sx={{ 
                p: 2, 
                textAlign: 'center',
                border: '1px solid #e0e0e0',
                borderRadius: 1,
                bgcolor: 'white',
                boxShadow: 'none',
                cursor: 'pointer',
                transition: 'border-color 0.2s ease',
                '&:hover': {
                  borderColor: '#e65100'
                }
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 'bold', color: '#666', mb: 0.5 }}>
                Vencem hoje (R$)
              </Typography>
              <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#f44336' }}>
                {formatCurrency(Math.abs(totalVencemHoje)).replace('R$', '').trim()}
              </Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={2.4}>
            <Paper 
              onClick={applyAVencerFilter}
              sx={{ 
                p: 2, 
                textAlign: 'center',
                border: '1px solid #e0e0e0',
                borderRadius: 1,
                bgcolor: 'white',
                boxShadow: 'none',
                cursor: 'pointer',
                transition: 'border-color 0.2s ease',
                '&:hover': {
                  borderColor: '#1565c0'
                }
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 'bold', color: '#666', mb: 0.5 }}>
                A vencer (R$)
              </Typography>
              <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#2196f3' }}>
                {formatCurrency(Math.abs(totalAVencer)).replace('R$', '').trim()}
              </Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={2.4}>
            <Paper 
              onClick={() => setFilters(prev => ({ ...prev, payment_status_id: '2', transaction_type: '' }))}
              sx={{ 
                p: 2, 
                textAlign: 'center',
                border: '1px solid #e0e0e0',
                borderRadius: 1,
                bgcolor: 'white',
                boxShadow: 'none',
                cursor: 'pointer',
                transition: 'border-color 0.2s ease',
                '&:hover': {
                  borderColor: '#2e7d32'
                }
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 'bold', color: '#666', mb: 0.5 }}>
                Pagos (R$)
              </Typography>
              <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#4caf50' }}>
                {formatCurrency(transactions.filter(t => t.is_paid).reduce((sum, t) => sum + t.amount, 0)).replace('R$', '').trim()}
              </Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={2.4}>
            <Paper 
              onClick={() => setFilters({
                transaction_type: '',
                payment_status_id: '',
                category_id: '',
                subcategory_id: '',
                contact_id: '',
                cost_center_id: ''
              })}
              sx={{ 
                p: 2, 
                textAlign: 'center',
                border: '1px solid #2196f3',
                borderRadius: 1,
                bgcolor: 'white',
                boxShadow: 'none',
                cursor: 'pointer',
                transition: 'border-color 0.2s ease',
                '&:hover': {
                  borderColor: '#1565c0'
                }
              }}
            >
              <Typography 
                variant="body2" 
                sx={{ 
                  fontWeight: 'bold', 
                  color: '#666', 
                  mb: 0.5,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 0.5
                }}
              >
                Total do período (R$)
                <IconButton size="small" sx={{ p: 0, color: '#666' }}>
                  <CalendarIcon fontSize="small" />
                </IconButton>
              </Typography>
              <Typography variant="h6" sx={{ 
                fontWeight: 'bold', 
                color: saldoPeriodo >= 0 ? '#4caf50' : '#f44336'
              }}>
                {formatCurrency(saldoPeriodo).replace('R$', '').trim()}
              </Typography>
            </Paper>
          </Grid>
        </Grid>

        {/* Contador de registros selecionados */}
        <Box sx={{ 
          mb: 2, 
          display: 'flex', 
          alignItems: 'center', 
          gap: 2,
          minHeight: 32
        }}>
          <Typography variant="body2" color="text.secondary">
            {selectedTransactions.length} registro(s) selecionado(s)
          </Typography>
          
          <Button
            size="small"
            variant="text"
            disabled={selectedTransactions.length === 0}
            onClick={(e) => setBatchActionsAnchor(e.currentTarget)}
            sx={{ 
              textTransform: 'none',
              minWidth: 'auto',
              fontSize: '0.75rem',
              padding: '4px 12px',
              color: selectedTransactions.length > 0 ? '#1976d2' : '#999',
              '&:disabled': {
                color: '#999'
              }
            }}
          >
            Ações em lote
          </Button>
          
          <Menu
            anchorEl={batchActionsAnchor}
            open={Boolean(batchActionsAnchor)}
            onClose={() => setBatchActionsAnchor(null)}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'left',
            }}
          >
            <MenuItem onClick={handleBatchMarkAsPaid}>
              <ListItemIcon>
                <PaidIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText>Marcar como Pago</ListItemText>
            </MenuItem>
            <MenuItem onClick={handleBatchDelete} sx={{ color: '#f44336' }}>
              <ListItemIcon>
                <DeleteIcon fontSize="small" sx={{ color: '#f44336' }} />
              </ListItemIcon>
              <ListItemText>Excluir Selecionados</ListItemText>
            </MenuItem>
          </Menu>
        </Box>

        {/* Tabela */}
        <Paper sx={{ borderRadius: 3, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', bgcolor: 'white' }}>
          <TableContainer sx={{ bgcolor: 'white' }}>
            <Table sx={{ bgcolor: 'white' }}>
              <TableHead sx={{ bgcolor: 'white' }}>
                <TableRow>
                  <TableCell padding="checkbox" sx={{ width: '4%' }}>
                    <Checkbox
                      checked={selectedTransactions.length === transactions.length && transactions.length > 0}
                      indeterminate={selectedTransactions.length > 0 && selectedTransactions.length < transactions.length}
                      onChange={handleSelectAllTransactions}
                    />
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold', width: '8%' }}>Vencimento</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', width: '50%' }}>Descrição</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', width: '15%' }} align="right">Total (R$)</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', width: '13%' }} align="center">Situação</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', width: '10%' }}>Ações</TableCell>
                </TableRow>
              </TableHead>
              <TableBody sx={{ bgcolor: 'white' }}>
                {transactions.map((transaction) => {
                  const statusColors = getStatusColor(transaction);
                  const isOverdue = isTransactionOverdue(transaction);
                  const isDueToday = isTransactionDueToday(transaction);
                  
                  // Definir cor de fundo baseada no status
                  let rowBgColor = 'transparent';
                  let hoverBgColor = '#e3f2fd';
                  
                  if (isOverdue) {
                    rowBgColor = '#ffeaea'; // Vermelho mais escuro para vencidas
                    hoverBgColor = '#ffebee';
                  } else if (isDueToday) {
                    rowBgColor = '#fffbf0'; // Amarelo sutil para que vencem hoje
                    hoverBgColor = '#fff8e1';
                  }
                  
                  return (
                  <TableRow 
                    key={transaction.id}
                    sx={{ 
                      '&:hover': { bgcolor: hoverBgColor },
                      bgcolor: selectedTransactions.includes(transaction.id) 
                        ? hoverBgColor 
                        : rowBgColor
                    }}
                  >
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedTransactions.includes(transaction.id)}
                        onChange={() => handleSelectTransaction(transaction.id)}
                      />
                    </TableCell>
                    
                    <TableCell sx={{ minWidth: 90 }}>
                      <Typography variant="body2">
                        {format(new Date(transaction.transaction_date + 'T00:00:00'), 'dd/MM/yyyy')}
                      </Typography>
                    </TableCell>
                    
                    <TableCell sx={{ maxWidth: 400 }}>
                      <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                        {/* Ícone específico por tipo de transação */}
                        <Box 
                          sx={{ 
                            p: 0.5,
                            mt: 0.5,
                            borderRadius: 1,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            bgcolor: transaction.transaction_type === 'Despesa' ? '#ffebee' : 
                                   transaction.transaction_type === 'Receita' ? '#e8f5e8' : 
                                   '#e3f2fd',
                            color: transaction.transaction_type === 'Despesa' ? '#f44336' : 
                                  transaction.transaction_type === 'Receita' ? '#4caf50' : 
                                  '#2196f3'
                          }}
                        >
                          {transaction.transaction_type === 'Despesa' && <ExpenseIcon fontSize="small" />}
                          {transaction.transaction_type === 'Receita' && <IncomeIcon fontSize="small" />}
                          {transaction.transaction_type === 'Investimento' && <InvestmentIcon fontSize="small" />}
                        </Box>
                        
                        <Box sx={{ flex: 1, minWidth: 0 }}>
                          <Typography 
                            variant="body2" 
                            sx={{ 
                              mb: 0.5,
                              wordBreak: 'break-word',
                              lineHeight: 1.2,
                              fontWeight: 500
                            }}
                          >
                            {transaction.description}
                          </Typography>
                          
                          {/* Informações adicionais em containers separados */}
                          <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 0.5 }}>
                            {transaction.contact && (
                              <Chip 
                                label={transaction.contact.name} 
                                size="small" 
                                variant="outlined"
                                sx={{ 
                                  fontSize: '0.65rem', 
                                  height: 18,
                                  bgcolor: 'white',
                                  '& .MuiChip-label': {
                                    px: 0.5
                                  }
                                }}
                              />
                            )}
                            {transaction.category && (
                              <Chip 
                                label={`${transaction.category.name}${transaction.subcategory ? ` > ${transaction.subcategory.name}` : ''}`} 
                                size="small" 
                                variant="outlined"
                                sx={{ 
                                  fontSize: '0.65rem', 
                                  height: 18,
                                  bgcolor: 'white',
                                  '& .MuiChip-label': {
                                    px: 0.5
                                  }
                                }}
                              />
                            )}
                            {transaction.cost_center && (
                              <Chip 
                                label={`${transaction.cost_center.id} - ${transaction.cost_center.name}`} 
                                size="small" 
                                variant="outlined"
                                sx={{ 
                                  fontSize: '0.65rem', 
                                  height: 18,
                                  bgcolor: 'white',
                                  '& .MuiChip-label': {
                                    px: 0.5
                                  }
                                }}
                              />
                            )}
                          </Box>
                        </Box>
                      </Box>
                    </TableCell>
                    
                    <TableCell align="right" sx={{ minWidth: 120 }}>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          fontWeight: 'bold',
                          color: getTransactionTypeColor(transaction.transaction_type)
                        }}
                      >
                        {formatCurrency(transaction.amount)}
                      </Typography>
                    </TableCell>
                    
                    <TableCell sx={{ minWidth: 100 }} align="center">
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Chip
                          label={
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                              <Box
                                sx={{
                                  width: 6,
                                  height: 6,
                                  borderRadius: '50%',
                                  bgcolor: 'currentColor',
                                  flexShrink: 0
                                }}
                              />
                              <span>{getTransactionStatus(transaction)}</span>
                            </Box>
                          }
                          size="small"
                          sx={{ 
                            fontSize: '0.7rem',
                            height: 22,
                            bgcolor: statusColors.bg,
                            color: statusColors.color,
                            border: `1px solid ${statusColors.border}`,
                            '& .MuiChip-label': {
                              px: 1
                            }
                          }}
                        />
                      </Box>
                    </TableCell>
                    
                    <TableCell sx={{ minWidth: 60 }}>
                      <IconButton
                        size="small"
                        onClick={(e) => handleActionMenuOpen(e, transaction.id)}
                        sx={{ color: '#666' }}
                      >
                        <MoreVertIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                  );
                })}
                
                {transactions.length === 0 && !loading && (
                  <TableRow>
                    <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                      <Typography variant="body2" color="text.secondary">
                        Nenhuma transação encontrada para este período
                      </Typography>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>

        {/* Menu de ações */}
        <Menu
          anchorEl={actionMenuAnchorEl}
          open={Boolean(actionMenuAnchorEl)}
          onClose={handleActionMenuClose}
        >
          <MenuItem onClick={() => {
            if (selectedTransactionId) {
              const transaction = transactions.find(t => t.id === selectedTransactionId);
              if (transaction) {
                handleEditTransaction(transaction);
              }
            }
          }}>
            <ListItemIcon>
              <EditIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Editar</ListItemText>
          </MenuItem>
          
          <MenuItem onClick={() => selectedTransactionId && handleDuplicateTransaction(selectedTransactionId)}>
            <ListItemIcon>
              <DuplicateIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Duplicar</ListItemText>
          </MenuItem>
          
          <MenuItem onClick={() => selectedTransactionId && handleMarkAsPaid(selectedTransactionId)}>
            <ListItemIcon>
              <PaidIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Marcar como Pago</ListItemText>
          </MenuItem>
          
          <MenuItem 
            onClick={() => selectedTransactionId && handleDeleteTransaction(selectedTransactionId)}
            sx={{ color: 'error.main' }}
          >
            <ListItemIcon>
              <DeleteIcon fontSize="small" color="error" />
            </ListItemIcon>
            <ListItemText>Excluir</ListItemText>
          </MenuItem>
        </Menu>

        {/* Date Picker Dialog */}
        <Dialog open={datePickerOpen} onClose={() => setDatePickerOpen(false)}>
          <DialogTitle>Selecionar Mês</DialogTitle>
          <DialogContent>
            <DatePicker
              views={['year', 'month']}
              value={currentDate}
              onChange={(newValue) => {
                if (newValue) {
                  setCurrentDate(newValue);
                  setDatePickerOpen(false);
                }
              }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDatePickerOpen(false)}>Cancelar</Button>
          </DialogActions>
        </Dialog>

        {/* FAB para nova transação */}
        <Fab
          color="primary"
          aria-label="add"
          sx={{ position: 'fixed', bottom: 16, right: 16 }}
          onClick={(e) => setNewTransactionMenuAnchor(e.currentTarget)}
        >
          <AddIcon />
        </Fab>

        {/* Menu de nova transação */}
        <Menu
          anchorEl={newTransactionMenuAnchor}
          open={Boolean(newTransactionMenuAnchor)}
          onClose={() => setNewTransactionMenuAnchor(null)}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'left',
          }}
          transformOrigin={{
            vertical: 'bottom',
            horizontal: 'right',
          }}
        >
          <MenuItem disabled sx={{ fontWeight: 'bold', color: 'primary.main' }}>
            + Novo Registro
          </MenuItem>
          <Divider />
          <MenuItem 
            onClick={() => handleNewTransaction('Despesa')}
          >
            <ListItemIcon>
              <RemoveIcon color="error" />
            </ListItemIcon>
            <ListItemText>Despesa</ListItemText>
          </MenuItem>
          <MenuItem 
            onClick={() => handleNewTransaction('Receita')}
          >
            <ListItemIcon>
              <AddIcon color="success" />
            </ListItemIcon>
            <ListItemText>Receita</ListItemText>
          </MenuItem>
          <MenuItem 
            onClick={() => handleNewTransaction('Investimento')}
          >
            <ListItemIcon>
              <TrendingUpIcon color="primary" />
            </ListItemIcon>
            <ListItemText>Investimento</ListItemText>
          </MenuItem>
        </Menu>

        {/* Dialog para criar/editar transação */}
        <Dialog 
          open={transactionDialogOpen} 
          onClose={handleCloseTransactionDialog} 
          maxWidth="lg" 
          fullWidth
          PaperProps={{
            sx: { borderRadius: 3 }
          }}
        >
          <form onSubmit={handleTransactionSubmit}>
            <DialogTitle sx={{ bgcolor: '#f8fafc', fontWeight: 'bold', color: '#1a365d' }}>
              {editingTransaction ? 'Editar Transação' : 'Nova Transação'}
            </DialogTitle>
            <DialogContent sx={{ p: 3 }}>
              <Grid container spacing={2} sx={{ mt: 0.5 }}>
                {/* Primeira linha - 3 colunas */}
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth required size="small">
                    <InputLabel>Tipo de Registro</InputLabel>
                    <Select
                      value={formData.transaction_type}
                      onChange={(e) => setFormData(prev => ({ ...prev, transaction_type: e.target.value as any }))}
                      label="Tipo de Registro"
                    >
                      <MenuItem value="Despesa">
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <ExpenseIcon sx={{ color: '#f44336', mr: 1 }} />
                          Despesa
                        </Box>
                      </MenuItem>
                      <MenuItem value="Receita">
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <IncomeIcon sx={{ color: '#4caf50', mr: 1 }} />
                          Receita
                        </Box>
                      </MenuItem>
                      <MenuItem value="Investimento">
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <InvestmentIcon sx={{ color: '#2196f3', mr: 1 }} />
                          Investimento
                        </Box>
                      </MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="Data do Registro"
                    type="date"
                    value={formData.transaction_date}
                    onChange={(e) => setFormData(prev => ({ ...prev, transaction_date: e.target.value }))}
                    fullWidth
                    required
                    size="small"
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="Valor"
                    type="text"
                    value={formData.amount}
                    onChange={(e) => {
                      const value = e.target.value.replace(/[^0-9.,]/g, '');
                      setFormData(prev => ({ ...prev, amount: value }));
                    }}
                    onBlur={(e) => {
                      const value = e.target.value.replace(/[^0-9.,]/g, '');
                      if (value) {
                        const numericValue = parseFloat(value.replace(',', '.'));
                        if (!isNaN(numericValue)) {
                          const formattedValue = numericValue.toLocaleString('pt-BR', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          });
                          setFormData(prev => ({ ...prev, amount: formattedValue }));
                        }
                      }
                    }}
                    onFocus={(e) => {
                      const value = e.target.value.replace(/\./g, '').replace(',', '.');
                      const numericValue = parseFloat(value);
                      if (!isNaN(numericValue)) {
                        setFormData(prev => ({ ...prev, amount: numericValue.toString() }));
                      }
                    }}
                    fullWidth
                    required
                    size="small"
                    InputProps={{
                      startAdornment: <Box sx={{ mr: 1 }}>R$</Box>
                    }}
                  />
                </Grid>

                {/* Segunda linha - Descrição */}
                <Grid item xs={12}>
                  <TextField
                    label="Descrição da Transação"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    fullWidth
                    required
                    size="small"
                    multiline
                    rows={2}
                  />
                </Grid>

                {/* Terceira linha - Filtros adicionais */}
                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    options={categories.filter(cat => cat.source_type === formData.transaction_type)}
                    getOptionLabel={(option) => option.name}
                    value={categories.find(cat => cat.id.toString() === formData.category_id) || null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({
                        ...prev,
                        category_id: newValue?.id.toString() || '',
                        subcategory_id: '' // Reset subcategory when category changes
                      }));
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Categoria"
                        size="small"
                      />
                    )}
                  />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    options={subcategories.filter(sub => 
                      formData.category_id ? 
                      sub.category_id.toString() === formData.category_id : 
                      false
                    )}
                    getOptionLabel={(option) => option.name}
                    value={subcategories.find(sub => sub.id.toString() === formData.subcategory_id) || null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({
                        ...prev,
                        subcategory_id: newValue?.id.toString() || ''
                      }));
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Subcategoria"
                        size="small"
                      />
                    )}
                    disabled={!formData.category_id}
                  />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    options={contacts}
                    getOptionLabel={(option) => option.name}
                    value={contacts.find(contact => contact.id.toString() === formData.contact_id) || null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({
                        ...prev,
                        contact_id: newValue?.id.toString() || ''
                      }));
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Contato"
                        size="small"
                      />
                    )}
                  />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    options={costCenters}
                    getOptionLabel={(option) => option.name}
                    value={costCenters.find(cc => cc.id.toString() === formData.cost_center_id) || null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({
                        ...prev,
                        cost_center_id: newValue?.id.toString() || ''
                      }));
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Centro de Custo"
                        size="small"
                      />
                    )}
                  />
                </Grid>

                {/* Quinta linha - Switches lado a lado */}
                <Grid item xs={12}>
                  <Box sx={{ display: 'flex', gap: 4, mt: 1 }}>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={formData.is_recurring}
                          onChange={(e) => setFormData(prev => ({ ...prev, is_recurring: e.target.checked }))}
                          color="primary"
                        />
                      }
                      label="Transação Recorrente"
                    />
                    <FormControlLabel
                      control={
                        <Switch
                          checked={formData.is_paid}
                          onChange={(e) => setFormData(prev => ({ ...prev, is_paid: e.target.checked }))}
                          color="success"
                        />
                      }
                      label="Já foi pago/recebido?"
                    />
                  </Box>
                </Grid>

                {/* Campos de recorrência */}
                {formData.is_recurring && (
                  <>
                    {/* Todos os campos de recorrência na mesma linha */}
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={4}>
                          <FormControl fullWidth size="small">
                            <InputLabel>Tipo de Recorrência</InputLabel>
                            <Select
                              value={formData.recurrence_type}
                              onChange={(e) => setFormData(prev => ({ ...prev, recurrence_type: e.target.value as any }))}
                              label="Tipo de Recorrência"
                            >
                              <MenuItem value="semanal">Semanalmente</MenuItem>
                              <MenuItem value="mensal">Mensalmente</MenuItem>
                              <MenuItem value="anual">Anualmente</MenuItem>
                              <MenuItem value="personalizada">A cada X dias</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                        
                        {/* Dia da Semana para Recorrência Semanal */}
                        {formData.recurrence_type === 'semanal' && (
                          <Grid item xs={12} sm={4}>
                            <FormControl fullWidth size="small">
                              <InputLabel>Dia da Semana</InputLabel>
                              <Select
                                value={formData.recurrence_weekday}
                                onChange={(e) => setFormData(prev => ({ ...prev, recurrence_weekday: parseInt(e.target.value as string) }))}
                                label="Dia da Semana"
                              >
                                <MenuItem value={1}>Segunda-feira</MenuItem>
                                <MenuItem value={2}>Terça-feira</MenuItem>
                                <MenuItem value={3}>Quarta-feira</MenuItem>
                                <MenuItem value={4}>Quinta-feira</MenuItem>
                                <MenuItem value={5}>Sexta-feira</MenuItem>
                                <MenuItem value={6}>Sábado</MenuItem>
                                <MenuItem value={0}>Domingo</MenuItem>
                              </Select>
                            </FormControl>
                          </Grid>
                        )}
                        
                        {/* Intervalo para Recorrência Personalizada */}
                        {formData.recurrence_type === 'personalizada' && (
                          <Grid item xs={12} sm={4}>
                            <TextField
                              label="A cada quantos dias"
                              type="number"
                              value={formData.recurrence_interval || 1}
                              onChange={(e) => {
                                const value = parseInt(e.target.value) || 1;
                                setFormData(prev => ({ ...prev, recurrence_interval: Math.max(1, Math.min(365, value)) }));
                              }}
                              onBlur={(e) => {
                                // Garantir que nunca fique vazio ou zero
                                if (!e.target.value || parseInt(e.target.value) < 1) {
                                  setFormData(prev => ({ ...prev, recurrence_interval: 1 }));
                                }
                              }}
                              fullWidth
                              size="small"
                              inputProps={{ min: 1, max: 365 }}
                            />
                          </Grid>
                        )}
                        
                        {/* Quantidade de Vezes sempre visível */}
                        <Grid item xs={12} sm={4}>
                          <TextField
                            label="Quantidade de Vezes"
                            type="number"
                            value={formData.recurrence_count}
                            onChange={(e) => {
                              const value = e.target.value;
                              // Permitir campo vazio ou valores numéricos
                              if (value === '' || (!isNaN(parseInt(value)) && parseInt(value) >= 0)) {
                                setFormData(prev => ({ ...prev, recurrence_count: value === '' ? '' : parseInt(value) }));
                              }
                            }}
                            onBlur={(e) => {
                              // Quando sair do campo, se estiver vazio ou inválido, definir como 2
                              const value = e.target.value;
                              if (!value || parseInt(value) < 1) {
                                setFormData(prev => ({ ...prev, recurrence_count: 2 }));
                              }
                            }}
                            fullWidth
                            size="small"
                            inputProps={{ min: 1, max: 60 }}
                          />
                        </Grid>
                      </Grid>
                    </Grid>
                  </>
                )}
              </Grid>

              {/* Preview de recorrências */}
              {formData.is_recurring && recurrencePreview.length > 0 && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold', color: '#1a365d' }}>
                    Recorrências previstas
                  </Typography>
                  <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>Data de criação</TableCell>
                          <TableCell>Data de vencimento</TableCell>
                          <TableCell>Lançamento</TableCell>
                          <TableCell align="right">Valor (R$)</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {recurrencePreview.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell>{new Date(item.creation_date + 'T12:00:00').toLocaleDateString('pt-BR')}</TableCell>
                            <TableCell>{new Date(item.due_date + 'T12:00:00').toLocaleDateString('pt-BR')}</TableCell>
                            <TableCell>{item.description}</TableCell>
                            <TableCell align="right">
                              {item.amount.toLocaleString('pt-BR', { 
                                minimumFractionDigits: 2, 
                                maximumFractionDigits: 2 
                              })}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              )}
            </DialogContent>

            <DialogActions sx={{ p: 3 }}>
              <Button onClick={handleCloseTransactionDialog} variant="outlined">
                Cancelar
              </Button>
              <Button 
                type="submit" 
                variant="contained" 
                disabled={loading}
              >
                {editingTransaction ? 'Atualizar' : 'Criar'} Transação
              </Button>
            </DialogActions>
          </form>
        </Dialog>

        {/* Snackbar para notificações */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={7000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          <Alert 
            onClose={() => setSnackbar({ ...snackbar, open: false })} 
            severity={snackbar.severity}
            variant="filled"
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </LocalizationProvider>
  );
}
