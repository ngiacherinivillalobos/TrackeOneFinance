import { useState } from 'react';
import { Grid, Paper, Typography, Tabs, Tab, Box } from '@mui/material';
import { Categories } from '../components/Categories';
import Subcategories from './Subcategories';
import CategoryTypes from './CategoryTypes';
import PaymentStatuses from './PaymentStatuses';
import BankAccounts from './BankAccounts';
import Cards from './Cards';
import Contacts from './Contacts';
import CostCenters from './CostCenters';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`settings-tabpanel-${index}`}
      aria-labelledby={`settings-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState(0);
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  return (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Typography variant="h4" gutterBottom>
          Cadastros
        </Typography>
      </Grid>

      <Grid item xs={12}>
        <Paper>
          <Tabs value={activeTab} onChange={handleTabChange} variant="scrollable">
            <Tab label="Categorias" />
            <Tab label="Subcategorias" />
            <Tab label="Tipos de Registro" />
            <Tab label="Status de Pagamento" />
            <Tab label="Contas Bancárias" />
            <Tab label="Cartões" />
            <Tab label="Contatos" />
            <Tab label="Centro de Custo" />
          </Tabs>

          <TabPanel value={activeTab} index={0}>
            <Categories />
          </TabPanel>
          <TabPanel value={activeTab} index={1}>
            <Subcategories />
          </TabPanel>
          <TabPanel value={activeTab} index={2}>
            <CategoryTypes />
          </TabPanel>
          <TabPanel value={activeTab} index={3}>
            <PaymentStatuses />
          </TabPanel>
          <TabPanel value={activeTab} index={4}>
            <BankAccounts />
          </TabPanel>
          <TabPanel value={activeTab} index={5}>
            <Cards />
          </TabPanel>
          <TabPanel value={activeTab} index={6}>
            <Contacts />
          </TabPanel>
          <TabPanel value={activeTab} index={7}>
            <CostCenters />
          </TabPanel>
        </Paper>
      </Grid>
    </Grid>
  );
}
