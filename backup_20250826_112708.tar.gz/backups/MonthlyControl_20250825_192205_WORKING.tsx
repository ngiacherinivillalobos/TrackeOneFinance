import React, { useState, useEffect } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Checkbox,
  IconButton,
  Menu,
  MenuItem,
  Box,
  Autocomplete,
  TextField,
  Chip,
  FormControl,
  InputLabel,
  Select,
  Fab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  ListItemIcon,
  ListItemText,
  Divider,
  FormControlLabel,
  Switch,
  Snackbar,
  Alert,
} from '@mui/material';
import {
  Add as AddIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  FileCopy as DuplicateIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  CalendarToday as CalendarIcon,
  Download as DownloadIcon,
  Paid as PaidIcon,
  Remove as RemoveIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as ExpenseIcon,
  TrendingUp as IncomeIcon,
  ShowChart as InvestmentIcon,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { ptBR } from 'date-fns/locale';
import { format, addMonths, subMonths } from 'date-fns';
import api from '../services/api';

interface Transaction {
  id: number;
  description: string;
  amount: number;
  transaction_date: string;
  transaction_type: 'Despesa' | 'Receita' | 'Investimento';
  is_paid: boolean;
  contact?: {
    id: number;
    name: string;
  };
  category?: {
    id: number;
    name: string;
  };
  subcategory?: {
    id: number;
    name: string;
  };
  cost_center?: {
    id: number;
    name: string;
  };
}

interface Category {
  id: number;
  name: string;
  source_type: string;
}

interface Subcategory {
  id: number;
  name: string;
  category_id: number;
}

interface Contact {
  id: number;
  name: string;
}

interface CostCenter {
  id: number;
  name: string;
}

interface PaymentStatus {
  id: number;
  name: string;
}

interface Filters {
  transaction_type: string;
  payment_status_id: string;
  category_id: string;
  subcategory_id: string;
  contact_id: string;
}

export default function MonthlyControl() {
  // Estados
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  
  // Estados para filtros avançados de data
  const [dateFilterType, setDateFilterType] = useState<'month' | 'year' | 'custom'>('month');
  const [customStartDate, setCustomStartDate] = useState<Date | null>(null);
  const [customEndDate, setCustomEndDate] = useState<Date | null>(null);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  
  // Estados para filtros
  const [filters, setFilters] = useState<Filters>({
    transaction_type: '',
    payment_status_id: '',
    category_id: '',
    subcategory_id: '',
    contact_id: ''
  });
  
  // Estados para dados dos filtros
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [paymentStatuses, setPaymentStatuses] = useState<PaymentStatus[]>([]);
  
  // Estados para seleção e ações
  const [selectedTransactions, setSelectedTransactions] = useState<number[]>([]);
  const [actionMenuAnchorEl, setActionMenuAnchorEl] = useState<HTMLElement | null>(null);
  const [selectedTransactionId, setSelectedTransactionId] = useState<number | null>(null);
  const [newTransactionMenuAnchor, setNewTransactionMenuAnchor] = useState<HTMLElement | null>(null);

  // Estados para modal de criação/edição de transação
  const [transactionDialogOpen, setTransactionDialogOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    transaction_date: new Date().toISOString().split('T')[0],
    category_id: '',
    subcategory_id: '',
    payment_status_id: '',
    contact_id: '',
    cost_center_id: '',
    transaction_type: 'Despesa' as 'Despesa' | 'Receita' | 'Investimento',
    is_recurring: false,
    recurrence_type: 'mensal' as 'unica' | 'diaria' | 'semanal' | 'mensal' | 'anual' | 'personalizada',
    recurrence_count: 1,
    recurrence_interval: 1,
    recurrence_weekday: 1,
    is_paid: false
  });

  // Estado para preview de recorrências
  const [recurrencePreview, setRecurrencePreview] = useState<Array<{
    creation_date: string;
    due_date: string;
    description: string;
    amount: number;
  }>>([]);

  // Estados de notificação
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error' | 'warning' | 'info'
  });

  // Cálculo dos totais
  const totalReceitas = transactions
    .filter(t => t.transaction_type === 'Receita')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const totalDespesas = transactions
    .filter(t => t.transaction_type === 'Despesa')
    .reduce((sum, t) => sum + t.amount, 0);

  // Carregar dados iniciais
  useEffect(() => {
    loadTransactions();
    loadFilterData();
  }, [currentDate, filters, dateFilterType, customStartDate, customEndDate, selectedYear]);

  // Atualizar preview de recorrências quando dados do formulário mudam
  useEffect(() => {
    if (formData.is_recurring && formData.transaction_date && formData.amount) {
      generateRecurrencePreview();
    } else {
      setRecurrencePreview([]);
    }
  }, [formData.is_recurring, formData.recurrence_type, formData.recurrence_count, formData.recurrence_interval, formData.recurrence_weekday, formData.transaction_date, formData.amount, formData.description]);

  // Função para gerar preview de recorrências
  const generateRecurrencePreview = () => {
    if (!formData.transaction_date || !formData.amount || formData.recurrence_count < 1) {
      setRecurrencePreview([]);
      return;
    }

    const previews: Array<{
      creation_date: string;
      due_date: string;
      description: string;
      amount: number;
    }> = [];
    
    // Usar diretamente a data do formulário sem conversões problemáticas
    const [year, month, day] = formData.transaction_date.split('-').map(Number);
    const baseDate = new Date(year, month - 1, day); // month - 1 porque Date usa 0-11 para meses
    const amount = parseFloat(formData.amount.toString().replace(/\./g, '').replace(',', '.')) || parseFloat(formData.amount);

    for (let i = 0; i < formData.recurrence_count; i++) {
      let currentDate = new Date(baseDate);
      
      switch (formData.recurrence_type) {
        case 'semanal':
          if (i === 0) {
            // Primeira ocorrência: usar a data exata do formulário
            currentDate = new Date(baseDate);
          } else {
            // Próximas ocorrências: a cada 7 dias
            currentDate.setDate(baseDate.getDate() + (i * 7));
          }
          break;
        case 'mensal':
          currentDate.setMonth(baseDate.getMonth() + i);
          break;
        case 'anual':
          currentDate.setFullYear(baseDate.getFullYear() + i);
          break;
        case 'personalizada':
          currentDate.setDate(baseDate.getDate() + (i * (formData.recurrence_interval || 1)));
          break;
        default:
          if (i > 0) return; // Para outros tipos, só uma ocorrência
      }

      // Formatar data corretamente (YYYY-MM-DD)
      const formattedDate = currentDate.getFullYear() + '-' + 
                           String(currentDate.getMonth() + 1).padStart(2, '0') + '-' + 
                           String(currentDate.getDate()).padStart(2, '0');

      previews.push({
        creation_date: formattedDate,
        due_date: formattedDate,
        description: formData.description || 'Nova transação',
        amount: amount
      });
    }

    setRecurrencePreview(previews);
  };

  const loadTransactions = async () => {
    try {
      setLoading(true);
      
      let startDate: string;
      let endDate: string;
      
      if (dateFilterType === 'month') {
        startDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth(), 1), 'yyyy-MM-dd');
        endDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0), 'yyyy-MM-dd');
      } else if (dateFilterType === 'year') {
        startDate = `${selectedYear}-01-01`;
        endDate = `${selectedYear}-12-31`;
      } else if (dateFilterType === 'custom' && customStartDate && customEndDate) {
        startDate = format(customStartDate, 'yyyy-MM-dd');
        endDate = format(customEndDate, 'yyyy-MM-dd');
      } else {
        // Fallback para mês atual
        startDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth(), 1), 'yyyy-MM-dd');
        endDate = format(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0), 'yyyy-MM-dd');
      }
      
      const params = new URLSearchParams({
        start_date: startDate,
        end_date: endDate,
        ...Object.fromEntries(Object.entries(filters).filter(([_, value]) => value !== ''))
      });
      
      console.log('Loading transactions with URL:', `/transactions?${params}`);
      console.log('Filters:', filters);
      
      const response = await api.get(`/transactions?${params}`);
      setTransactions(response.data);
    } catch (error) {
      console.error('Erro ao carregar transações:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadFilterData = async () => {
    try {
      const [categoriesRes, subcategoriesRes, contactsRes, costCentersRes, paymentStatusesRes] = await Promise.all([
        api.get('/categories'),
        api.get('/subcategories'),
        api.get('/contacts'),
        api.get('/cost-centers'),
        api.get('/payment-statuses')
      ]);
      
      setCategories(categoriesRes.data);
      setSubcategories(subcategoriesRes.data);
      setContacts(contactsRes.data);
      setCostCenters(costCentersRes.data);
      setPaymentStatuses(paymentStatusesRes.data);
    } catch (error) {
      console.error('Erro ao carregar dados dos filtros:', error);
    }
  };

  // Seleção de transações
  const handleSelectTransaction = (transactionId: number) => {
    setSelectedTransactions(prev => 
      prev.includes(transactionId) 
        ? prev.filter(id => id !== transactionId)
        : [...prev, transactionId]
    );
  };

  const handleSelectAllTransactions = () => {
    setSelectedTransactions(
      selectedTransactions.length === transactions.length 
        ? [] 
        : transactions.map(t => t.id)
    );
  };

  // Menu de ações
  const handleActionMenuOpen = (event: React.MouseEvent<HTMLElement>, transactionId: number) => {
    setActionMenuAnchorEl(event.currentTarget);
    setSelectedTransactionId(transactionId);
  };

  const handleActionMenuClose = () => {
    setActionMenuAnchorEl(null);
    setSelectedTransactionId(null);
  };

  // Ações de transação
  const handleDuplicateTransaction = (id: number) => {
    console.log('Duplicar transação:', id);
    handleActionMenuClose();
  };

  const handleDeleteTransaction = async (id: number) => {
    if (window.confirm('Tem certeza que deseja excluir esta transação?')) {
      try {
        await api.delete(`/transactions/${id}`);
        loadTransactions();
      } catch (error) {
        console.error('Erro ao excluir transação:', error);
      }
    }
    handleActionMenuClose();
  };

  const handleMarkAsPaid = async (id: number) => {
    try {
      await api.patch(`/transactions/${id}`, { is_paid: true });
      loadTransactions();
    } catch (error) {
      console.error('Erro ao marcar como pago:', error);
    }
    handleActionMenuClose();
  };

  // Funções para modal de transação
  const showSnackbar = (message: string, severity: 'success' | 'error' | 'warning' | 'info' = 'success') => {
    setSnackbar({
      open: true,
      message,
      severity
    });
  };

  const handleNewTransaction = (type: 'Despesa' | 'Receita' | 'Investimento') => {
    setFormData({
      description: '',
      amount: '',
      transaction_date: new Date().toISOString().split('T')[0],
      category_id: '',
      subcategory_id: '',
      payment_status_id: '',
      contact_id: '',
      cost_center_id: '',
      transaction_type: type,
      is_recurring: false,
      recurrence_type: 'mensal',
      recurrence_count: 1,
      recurrence_interval: 1,
      recurrence_weekday: 1,
      is_paid: false
    });
    setEditingTransaction(null);
    setRecurrencePreview([]);
    setTransactionDialogOpen(true);
    setNewTransactionMenuAnchor(null);
  };

  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setFormData({
      description: transaction.description,
      amount: transaction.amount.toString(),
      transaction_date: transaction.transaction_date.split('T')[0],
      category_id: transaction.category?.id?.toString() || '',
      subcategory_id: transaction.subcategory?.id?.toString() || '',
      payment_status_id: '', // Não disponível na interface atual
      contact_id: transaction.contact?.id?.toString() || '',
      cost_center_id: transaction.cost_center?.id?.toString() || '',
      transaction_type: transaction.transaction_type,
      is_recurring: false, // Default para edição
      recurrence_type: 'mensal',
      recurrence_count: 1,
      recurrence_interval: 1,
      recurrence_weekday: 1,
      is_paid: transaction.is_paid || false
    });
    setRecurrencePreview([]);
    setTransactionDialogOpen(true);
    handleActionMenuClose();
  };

  const handleCloseTransactionDialog = () => {
    setTransactionDialogOpen(false);
    setEditingTransaction(null);
  };

  const handleTransactionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const transactionData = {
        description: formData.description,
        amount: typeof formData.amount === 'string' 
          ? parseFloat(formData.amount.replace(/\./g, '').replace(',', '.')) 
          : parseFloat(formData.amount),
        transaction_type: formData.transaction_type,
        transaction_date: formData.transaction_date,
        category_id: formData.category_id ? parseInt(formData.category_id) : null,
        subcategory_id: formData.subcategory_id ? parseInt(formData.subcategory_id) : null,
        payment_status_id: formData.payment_status_id ? parseInt(formData.payment_status_id) : null,
        contact_id: formData.contact_id ? parseInt(formData.contact_id) : null,
        cost_center_id: formData.cost_center_id ? parseInt(formData.cost_center_id) : null,
        is_recurring: formData.is_recurring,
        recurrence_type: formData.is_recurring ? formData.recurrence_type : null,
        recurrence_count: formData.is_recurring ? formData.recurrence_count : null,
        recurrence_interval: formData.is_recurring && formData.recurrence_type === 'personalizada' ? formData.recurrence_interval : null,
        recurrence_weekday: formData.is_recurring && formData.recurrence_type === 'semanal' ? formData.recurrence_weekday : null,
        is_paid: formData.is_paid
      };

      if (editingTransaction) {
        await api.put(`/transactions/${editingTransaction.id}`, transactionData);
        showSnackbar('Transação atualizada com sucesso!');
      } else {
        await api.post('/transactions', transactionData);
        showSnackbar('Transação criada com sucesso!');
      }

      handleCloseTransactionDialog();
      loadTransactions();
    } catch (error) {
      console.error('Erro ao salvar transação:', error);
      showSnackbar('Erro ao salvar transação', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Formatação de valor
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Cor do tipo de transação
  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'Receita': return '#4caf50';
      case 'Despesa': return '#f44336';
      case 'Investimento': return '#2196f3';
      default: return '#757575';
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={ptBR}>
      <Box sx={{ p: 3, minHeight: '100vh', bgcolor: '#f5f5f5' }}>
        {/* Header com navegação e filtros */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          {/* Navegação de Data */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <FormControl size="small" sx={{ minWidth: 120 }}>
              <InputLabel>Filtro</InputLabel>
              <Select
                value={dateFilterType}
                label="Filtro"
                onChange={(e) => setDateFilterType(e.target.value as 'month' | 'year' | 'custom')}
              >
                <MenuItem value="month">Mensal</MenuItem>
                <MenuItem value="year">Anual</MenuItem>
                <MenuItem value="custom">Personalizado</MenuItem>
              </Select>
            </FormControl>

            {dateFilterType === 'month' && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <IconButton 
                  onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))}
                  size="small"
                >
                  <ChevronLeftIcon />
                </IconButton>
                <Typography variant="h6" sx={{ minWidth: 120, textAlign: 'center' }}>
                  {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
                </Typography>
                <IconButton 
                  onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))}
                  size="small"
                >
                  <ChevronRightIcon />
                </IconButton>
              </Box>
            )}

            {dateFilterType === 'year' && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <IconButton 
                  onClick={() => setSelectedYear(selectedYear - 1)}
                  size="small"
                >
                  <ChevronLeftIcon />
                </IconButton>
                <Typography variant="h6" sx={{ minWidth: 80, textAlign: 'center' }}>
                  {selectedYear}
                </Typography>
                <IconButton 
                  onClick={() => setSelectedYear(selectedYear + 1)}
                  size="small"
                >
                  <ChevronRightIcon />
                </IconButton>
              </Box>
            )}

            {dateFilterType === 'custom' && (
              <Box sx={{ display: 'flex', gap: 2 }}>
                <DatePicker
                  label="Data Início"
                  value={customStartDate}
                  onChange={(newDate) => setCustomStartDate(newDate)}
                  format="dd/MM/yyyy"
                  slotProps={{ textField: { size: 'small' } }}
                />
                <DatePicker
                  label="Data Fim"
                  value={customEndDate}
                  onChange={(newDate) => setCustomEndDate(newDate)}
                  format="dd/MM/yyyy"
                  slotProps={{ textField: { size: 'small' } }}
                />
              </Box>
            )}
          </Box>

          {/* Estatísticas */}
          <Paper elevation={1} sx={{ p: 2, backgroundColor: '#f5f5f5' }}>
            <Typography variant="body2" color="text.secondary">
              Total: {transactions.length} registros | 
              Receitas: R$ {totalReceitas.toFixed(2)} | 
              Despesas: R$ {totalDespesas.toFixed(2)} | 
              Saldo: R$ {(totalReceitas - totalDespesas).toFixed(2)}
            </Typography>
          </Paper>
        </Box>

        {/* Filtros */}
        <Paper sx={{ p: 3, mb: 3, borderRadius: 3, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Filtros</Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={2}>
              <FormControl fullWidth size="small">
                <InputLabel>Tipo de Registro</InputLabel>
                <Select
                  value={filters.transaction_type}
                  label="Tipo de Registro"
                  onChange={(e) => setFilters(prev => ({ ...prev, transaction_type: e.target.value }))}
                >
                  <MenuItem value="">Todos</MenuItem>
                  <MenuItem value="Despesa">Despesa</MenuItem>
                  <MenuItem value="Receita">Receita</MenuItem>
                  <MenuItem value="Investimento">Investimento</MenuItem>
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Autocomplete
                size="small"
                options={paymentStatuses}
                getOptionLabel={(option) => option.name}
                value={paymentStatuses.find(ps => ps.id.toString() === filters.payment_status_id) || null}
                onChange={(_, newValue) => setFilters(prev => ({ ...prev, payment_status_id: newValue ? newValue.id.toString() : '' }))}
                renderInput={(params) => <TextField {...params} label="Status" />}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Autocomplete
                size="small"
                options={categories.filter(cat => !filters.transaction_type || cat.source_type === filters.transaction_type)}
                getOptionLabel={(option) => option.name}
                value={categories.find(cat => cat.id.toString() === filters.category_id) || null}
                onChange={(_, newValue) => setFilters(prev => ({ 
                  ...prev, 
                  category_id: newValue ? newValue.id.toString() : '',
                  subcategory_id: '' // Reset subcategoria quando mudar categoria
                }))}
                renderInput={(params) => <TextField {...params} label="Categoria" />}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Autocomplete
                size="small"
                options={subcategories.filter(sub => !filters.category_id || sub.category_id.toString() === filters.category_id)}
                getOptionLabel={(option) => option.name}
                value={subcategories.find(sub => sub.id.toString() === filters.subcategory_id) || null}
                onChange={(_, newValue) => setFilters(prev => ({ ...prev, subcategory_id: newValue ? newValue.id.toString() : '' }))}
                renderInput={(params) => <TextField {...params} label="Subcategoria" />}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Autocomplete
                size="small"
                options={contacts}
                getOptionLabel={(option) => option.name}
                value={contacts.find(contact => contact.id.toString() === filters.contact_id) || null}
                onChange={(_, newValue) => setFilters(prev => ({ ...prev, contact_id: newValue ? newValue.id.toString() : '' }))}
                renderInput={(params) => <TextField {...params} label="Contato" />}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={2}>
              <Button
                variant="outlined"
                fullWidth
                size="small"
                sx={{ height: 40 }}
                onClick={() => setFilters({
                  transaction_type: '',
                  payment_status_id: '',
                  category_id: '',
                  subcategory_id: '',
                  contact_id: ''
                })}
              >
                Limpar Filtros
              </Button>
            </Grid>
          </Grid>
        </Paper>

        {/* Ações em massa */}
        {selectedTransactions.length > 0 && (
          <Paper sx={{ p: 2, mb: 3, borderRadius: 3, bgcolor: '#e3f2fd' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                {selectedTransactions.length} transação(ões) selecionada(s)
              </Typography>
              <Button size="small" startIcon={<PaidIcon />}>
                Marcar como Pago
              </Button>
              <Button size="small" startIcon={<DeleteIcon />} color="error">
                Excluir Selecionadas
              </Button>
              <Button size="small" startIcon={<DownloadIcon />}>
                Exportar
              </Button>
            </Box>
          </Paper>
        )}

        {/* Tabela */}
        <Paper sx={{ borderRadius: 3, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
          <TableContainer>
            <Table>
              <TableHead sx={{ bgcolor: '#f8f9fa' }}>
                <TableRow>
                  <TableCell padding="checkbox">
                    <Checkbox
                      checked={selectedTransactions.length === transactions.length && transactions.length > 0}
                      indeterminate={selectedTransactions.length > 0 && selectedTransactions.length < transactions.length}
                      onChange={handleSelectAllTransactions}
                    />
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Venc.</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Descrição</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }} align="right">Total (R$)</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Situação</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Ações</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow 
                    key={transaction.id}
                    sx={{ 
                      '&:hover': { bgcolor: '#f5f5f5' },
                      bgcolor: selectedTransactions.includes(transaction.id) ? '#e3f2fd' : 'inherit'
                    }}
                  >
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedTransactions.includes(transaction.id)}
                        onChange={() => handleSelectTransaction(transaction.id)}
                      />
                    </TableCell>
                    
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                        {format(new Date(transaction.transaction_date + 'T00:00:00'), 'dd/MM/yyyy')}
                      </Typography>
                    </TableCell>
                    
                    <TableCell>
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 'bold', mb: 0.5 }}>
                          {transaction.description}
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                          {transaction.contact && (
                            <Chip 
                              label={transaction.contact.name} 
                              size="small" 
                              variant="outlined"
                              sx={{ fontSize: '0.7rem', height: 20 }}
                            />
                          )}
                          {transaction.category && (
                            <Chip 
                              label={`${transaction.category.name}${transaction.subcategory ? ` > ${transaction.subcategory.name}` : ''}`} 
                              size="small" 
                              variant="outlined"
                              sx={{ fontSize: '0.7rem', height: 20 }}
                            />
                          )}
                          {transaction.cost_center && (
                            <Chip 
                              label={transaction.cost_center.name} 
                              size="small" 
                              variant="outlined"
                              sx={{ fontSize: '0.7rem', height: 20 }}
                            />
                          )}
                        </Box>
                      </Box>
                    </TableCell>
                    
                    <TableCell align="right">
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          fontWeight: 'bold',
                          color: getTransactionTypeColor(transaction.transaction_type)
                        }}
                      >
                        {formatCurrency(transaction.amount)}
                      </Typography>
                    </TableCell>
                    
                    <TableCell>
                      <Chip
                        label={transaction.is_paid ? 'Pago' : 'Em aberto'}
                        size="small"
                        color={transaction.is_paid ? 'success' : 'warning'}
                        sx={{ fontSize: '0.7rem' }}
                      />
                    </TableCell>
                    
                    <TableCell>
                      <IconButton
                        size="small"
                        onClick={(e) => handleActionMenuOpen(e, transaction.id)}
                      >
                        <MoreVertIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                
                {transactions.length === 0 && !loading && (
                  <TableRow>
                    <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                      <Typography variant="body2" color="text.secondary">
                        Nenhuma transação encontrada para este período
                      </Typography>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>

        {/* Menu de ações */}
        <Menu
          anchorEl={actionMenuAnchorEl}
          open={Boolean(actionMenuAnchorEl)}
          onClose={handleActionMenuClose}
        >
          <MenuItem onClick={() => {
            if (selectedTransactionId) {
              const transaction = transactions.find(t => t.id === selectedTransactionId);
              if (transaction) {
                handleEditTransaction(transaction);
              }
            }
          }}>
            <ListItemIcon>
              <EditIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Editar</ListItemText>
          </MenuItem>
          
          <MenuItem onClick={() => selectedTransactionId && handleDuplicateTransaction(selectedTransactionId)}>
            <ListItemIcon>
              <DuplicateIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Duplicar</ListItemText>
          </MenuItem>
          
          <MenuItem onClick={() => selectedTransactionId && handleMarkAsPaid(selectedTransactionId)}>
            <ListItemIcon>
              <PaidIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Marcar como Pago</ListItemText>
          </MenuItem>
          
          <MenuItem 
            onClick={() => selectedTransactionId && handleDeleteTransaction(selectedTransactionId)}
            sx={{ color: 'error.main' }}
          >
            <ListItemIcon>
              <DeleteIcon fontSize="small" color="error" />
            </ListItemIcon>
            <ListItemText>Excluir</ListItemText>
          </MenuItem>
        </Menu>

        {/* Date Picker Dialog */}
        <Dialog open={datePickerOpen} onClose={() => setDatePickerOpen(false)}>
          <DialogTitle>Selecionar Mês</DialogTitle>
          <DialogContent>
            <DatePicker
              views={['year', 'month']}
              value={currentDate}
              onChange={(newValue) => {
                if (newValue) {
                  setCurrentDate(newValue);
                  setDatePickerOpen(false);
                }
              }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDatePickerOpen(false)}>Cancelar</Button>
          </DialogActions>
        </Dialog>

        {/* FAB para nova transação */}
        <Fab
          color="primary"
          aria-label="add"
          sx={{ position: 'fixed', bottom: 16, right: 16 }}
          onClick={(e) => setNewTransactionMenuAnchor(e.currentTarget)}
        >
          <AddIcon />
        </Fab>

        {/* Menu de nova transação */}
        <Menu
          anchorEl={newTransactionMenuAnchor}
          open={Boolean(newTransactionMenuAnchor)}
          onClose={() => setNewTransactionMenuAnchor(null)}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'left',
          }}
          transformOrigin={{
            vertical: 'bottom',
            horizontal: 'right',
          }}
        >
          <MenuItem disabled sx={{ fontWeight: 'bold', color: 'primary.main' }}>
            + Novo Registro
          </MenuItem>
          <Divider />
          <MenuItem 
            onClick={() => handleNewTransaction('Despesa')}
          >
            <ListItemIcon>
              <RemoveIcon color="error" />
            </ListItemIcon>
            <ListItemText>Despesa</ListItemText>
          </MenuItem>
          <MenuItem 
            onClick={() => handleNewTransaction('Receita')}
          >
            <ListItemIcon>
              <AddIcon color="success" />
            </ListItemIcon>
            <ListItemText>Receita</ListItemText>
          </MenuItem>
          <MenuItem 
            onClick={() => handleNewTransaction('Investimento')}
          >
            <ListItemIcon>
              <TrendingUpIcon color="primary" />
            </ListItemIcon>
            <ListItemText>Investimento</ListItemText>
          </MenuItem>
        </Menu>

        {/* Dialog para criar/editar transação */}
        <Dialog 
          open={transactionDialogOpen} 
          onClose={handleCloseTransactionDialog} 
          maxWidth="lg" 
          fullWidth
          PaperProps={{
            sx: { borderRadius: 3 }
          }}
        >
          <form onSubmit={handleTransactionSubmit}>
            <DialogTitle sx={{ bgcolor: '#f8fafc', fontWeight: 'bold', color: '#1a365d' }}>
              {editingTransaction ? 'Editar Transação' : 'Nova Transação'}
            </DialogTitle>
            <DialogContent sx={{ p: 3 }}>
              <Grid container spacing={2} sx={{ mt: 0.5 }}>
                {/* Primeira linha - 3 colunas */}
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth required size="small">
                    <InputLabel>Tipo de Registro</InputLabel>
                    <Select
                      value={formData.transaction_type}
                      onChange={(e) => setFormData(prev => ({ ...prev, transaction_type: e.target.value as any }))}
                      label="Tipo de Registro"
                    >
                      <MenuItem value="Despesa">
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <ExpenseIcon sx={{ color: '#f44336', mr: 1 }} />
                          Despesa
                        </Box>
                      </MenuItem>
                      <MenuItem value="Receita">
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <IncomeIcon sx={{ color: '#4caf50', mr: 1 }} />
                          Receita
                        </Box>
                      </MenuItem>
                      <MenuItem value="Investimento">
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <InvestmentIcon sx={{ color: '#2196f3', mr: 1 }} />
                          Investimento
                        </Box>
                      </MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="Data do Registro"
                    type="date"
                    value={formData.transaction_date}
                    onChange={(e) => setFormData(prev => ({ ...prev, transaction_date: e.target.value }))}
                    fullWidth
                    required
                    size="small"
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="Valor"
                    type="text"
                    value={formData.amount}
                    onChange={(e) => {
                      const value = e.target.value.replace(/[^0-9.,]/g, '');
                      setFormData(prev => ({ ...prev, amount: value }));
                    }}
                    onBlur={(e) => {
                      const value = e.target.value.replace(/[^0-9.,]/g, '');
                      if (value) {
                        const numericValue = parseFloat(value.replace(',', '.'));
                        if (!isNaN(numericValue)) {
                          const formattedValue = numericValue.toLocaleString('pt-BR', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          });
                          setFormData(prev => ({ ...prev, amount: formattedValue }));
                        }
                      }
                    }}
                    onFocus={(e) => {
                      const value = e.target.value.replace(/\./g, '').replace(',', '.');
                      const numericValue = parseFloat(value);
                      if (!isNaN(numericValue)) {
                        setFormData(prev => ({ ...prev, amount: numericValue.toString() }));
                      }
                    }}
                    fullWidth
                    required
                    size="small"
                    InputProps={{
                      startAdornment: <Box sx={{ mr: 1 }}>R$</Box>
                    }}
                  />
                </Grid>

                {/* Segunda linha - Descrição */}
                <Grid item xs={12}>
                  <TextField
                    label="Descrição da Transação"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    fullWidth
                    required
                    size="small"
                    multiline
                    rows={2}
                  />
                </Grid>

                {/* Terceira linha - Filtros adicionais */}
                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    options={categories.filter(cat => cat.source_type === formData.transaction_type)}
                    getOptionLabel={(option) => option.name}
                    value={categories.find(cat => cat.id.toString() === formData.category_id) || null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({
                        ...prev,
                        category_id: newValue?.id.toString() || '',
                        subcategory_id: '' // Reset subcategory when category changes
                      }));
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Categoria"
                        size="small"
                      />
                    )}
                  />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    options={subcategories.filter(sub => 
                      formData.category_id ? 
                      sub.category_id.toString() === formData.category_id : 
                      false
                    )}
                    getOptionLabel={(option) => option.name}
                    value={subcategories.find(sub => sub.id.toString() === formData.subcategory_id) || null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({
                        ...prev,
                        subcategory_id: newValue?.id.toString() || ''
                      }));
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Subcategoria"
                        size="small"
                      />
                    )}
                    disabled={!formData.category_id}
                  />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    options={contacts}
                    getOptionLabel={(option) => option.name}
                    value={contacts.find(contact => contact.id.toString() === formData.contact_id) || null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({
                        ...prev,
                        contact_id: newValue?.id.toString() || ''
                      }));
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Contato"
                        size="small"
                      />
                    )}
                  />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    options={costCenters}
                    getOptionLabel={(option) => option.name}
                    value={costCenters.find(cc => cc.id.toString() === formData.cost_center_id) || null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({
                        ...prev,
                        cost_center_id: newValue?.id.toString() || ''
                      }));
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Centro de Custo"
                        size="small"
                      />
                    )}
                  />
                </Grid>

                {/* Quinta linha - Switches lado a lado */}
                <Grid item xs={12}>
                  <Box sx={{ display: 'flex', gap: 4, mt: 1 }}>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={formData.is_recurring}
                          onChange={(e) => setFormData(prev => ({ ...prev, is_recurring: e.target.checked }))}
                          color="primary"
                        />
                      }
                      label="Transação Recorrente"
                    />
                    <FormControlLabel
                      control={
                        <Switch
                          checked={formData.is_paid}
                          onChange={(e) => setFormData(prev => ({ ...prev, is_paid: e.target.checked }))}
                          color="success"
                        />
                      }
                      label="Já foi pago/recebido?"
                    />
                  </Box>
                </Grid>

                {/* Campos de recorrência */}
                {formData.is_recurring && (
                  <>
                    {/* Todos os campos de recorrência na mesma linha */}
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={4}>
                          <FormControl fullWidth size="small">
                            <InputLabel>Tipo de Recorrência</InputLabel>
                            <Select
                              value={formData.recurrence_type}
                              onChange={(e) => setFormData(prev => ({ ...prev, recurrence_type: e.target.value as any }))}
                              label="Tipo de Recorrência"
                            >
                              <MenuItem value="semanal">Semanalmente</MenuItem>
                              <MenuItem value="mensal">Mensalmente</MenuItem>
                              <MenuItem value="anual">Anualmente</MenuItem>
                              <MenuItem value="personalizada">A cada X dias</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                        
                        {/* Dia da Semana para Recorrência Semanal */}
                        {formData.recurrence_type === 'semanal' && (
                          <Grid item xs={12} sm={4}>
                            <FormControl fullWidth size="small">
                              <InputLabel>Dia da Semana</InputLabel>
                              <Select
                                value={formData.recurrence_weekday}
                                onChange={(e) => setFormData(prev => ({ ...prev, recurrence_weekday: parseInt(e.target.value as string) }))}
                                label="Dia da Semana"
                              >
                                <MenuItem value={1}>Segunda-feira</MenuItem>
                                <MenuItem value={2}>Terça-feira</MenuItem>
                                <MenuItem value={3}>Quarta-feira</MenuItem>
                                <MenuItem value={4}>Quinta-feira</MenuItem>
                                <MenuItem value={5}>Sexta-feira</MenuItem>
                                <MenuItem value={6}>Sábado</MenuItem>
                                <MenuItem value={0}>Domingo</MenuItem>
                              </Select>
                            </FormControl>
                          </Grid>
                        )}
                        
                        {/* Intervalo para Recorrência Personalizada */}
                        {formData.recurrence_type === 'personalizada' && (
                          <Grid item xs={12} sm={4}>
                            <TextField
                              label="A cada quantos dias"
                              type="number"
                              value={formData.recurrence_interval || 1}
                              onChange={(e) => {
                                const value = parseInt(e.target.value) || 1;
                                setFormData(prev => ({ ...prev, recurrence_interval: Math.max(1, Math.min(365, value)) }));
                              }}
                              onBlur={(e) => {
                                // Garantir que nunca fique vazio ou zero
                                if (!e.target.value || parseInt(e.target.value) < 1) {
                                  setFormData(prev => ({ ...prev, recurrence_interval: 1 }));
                                }
                              }}
                              fullWidth
                              size="small"
                              inputProps={{ min: 1, max: 365 }}
                            />
                          </Grid>
                        )}
                        
                        {/* Quantidade de Vezes sempre visível */}
                        <Grid item xs={12} sm={4}>
                          <TextField
                            label="Quantidade de Vezes"
                            type="number"
                            value={formData.recurrence_count}
                            onChange={(e) => {
                              const value = parseInt(e.target.value) || 1;
                              setFormData(prev => ({ ...prev, recurrence_count: Math.max(1, Math.min(60, value)) }));
                            }}
                            onBlur={(e) => {
                              // Garantir que nunca fique vazio ou zero
                              if (!e.target.value || parseInt(e.target.value) < 1) {
                                setFormData(prev => ({ ...prev, recurrence_count: 1 }));
                              }
                            }}
                            fullWidth
                            size="small"
                            inputProps={{ min: 1, max: 60 }}
                          />
                        </Grid>
                      </Grid>
                    </Grid>
                  </>
                )}
              </Grid>

              {/* Preview de recorrências */}
              {formData.is_recurring && recurrencePreview.length > 0 && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold', color: '#1a365d' }}>
                    Recorrências previstas
                  </Typography>
                  <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>Data de criação</TableCell>
                          <TableCell>Data de vencimento</TableCell>
                          <TableCell>Lançamento</TableCell>
                          <TableCell align="right">Valor (R$)</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {recurrencePreview.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell>{new Date(item.creation_date).toLocaleDateString('pt-BR')}</TableCell>
                            <TableCell>{new Date(item.due_date).toLocaleDateString('pt-BR')}</TableCell>
                            <TableCell>{item.description}</TableCell>
                            <TableCell align="right">
                              {item.amount.toLocaleString('pt-BR', { 
                                minimumFractionDigits: 2, 
                                maximumFractionDigits: 2 
                              })}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              )}
            </DialogContent>

            <DialogActions sx={{ p: 3 }}>
              <Button onClick={handleCloseTransactionDialog} variant="outlined">
                Cancelar
              </Button>
              <Button 
                type="submit" 
                variant="contained" 
                disabled={loading}
              >
                {editingTransaction ? 'Atualizar' : 'Criar'} Transação
              </Button>
            </DialogActions>
          </form>
        </Dialog>

        {/* Snackbar para notificações */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          <Alert 
            onClose={() => setSnackbar({ ...snackbar, open: false })} 
            severity={snackbar.severity}
            variant="filled"
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </LocalizationProvider>
  );
}
