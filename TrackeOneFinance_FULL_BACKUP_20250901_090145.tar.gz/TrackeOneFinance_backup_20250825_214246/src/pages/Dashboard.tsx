import { useEffect, useState } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';

interface WeeklyBalance {
  startDate: string;
  endDate: string;
  balance: number;
  spent: number;
  remaining: number;
}

interface MonthSummary {
  income: number;
  expenses: number;
  savings: number;
  expectedBalance: number;
  received: number;
  paid: number;
  toPay: number;
  toReceive: number;
}

export default function Dashboard() {
  const [weeklyBalances, setWeeklyBalances] = useState<WeeklyBalance[]>([]);
  const [monthSummary, setMonthSummary] = useState<MonthSummary>({
    income: 0,
    expenses: 0,
    savings: 0,
    expectedBalance: 0,
    received: 0,
    paid: 0,
    toPay: 0,
    toReceive: 0,
  });

  useEffect(() => {
    // TODO: Fetch data from API
    // For now, using dummy data
    setWeeklyBalances([
      {
        startDate: '2025-08-15',
        endDate: '2025-08-18',
        balance: 1000,
        spent: 200,
        remaining: 800,
      },
      // Add more weeks...
    ]);
  }, []);

  return (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Typography variant="h4" gutterBottom>
          Visão Geral
        </Typography>
      </Grid>

      {/* Monthly Summary */}
      <Grid item xs={12} md={6}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>
            Resumo do Mês
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Typography variant="subtitle2">Receitas:</Typography>
              <Typography>R$ {monthSummary.income.toFixed(2)}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="subtitle2">Despesas:</Typography>
              <Typography>R$ {monthSummary.expenses.toFixed(2)}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="subtitle2">Economias:</Typography>
              <Typography>R$ {monthSummary.savings.toFixed(2)}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="subtitle2">Saldo Previsto:</Typography>
              <Typography>R$ {monthSummary.expectedBalance.toFixed(2)}</Typography>
            </Grid>
          </Grid>
        </Paper>
      </Grid>

      {/* Weekly Table */}
      <Grid item xs={12}>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Período</TableCell>
                <TableCell align="right">Saldo</TableCell>
                <TableCell align="right">Gasto</TableCell>
                <TableCell align="right">Restante</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {weeklyBalances.map((week) => (
                <TableRow key={week.startDate}>
                  <TableCell>
                    {new Date(week.startDate).toLocaleDateString()} -{' '}
                    {new Date(week.endDate).toLocaleDateString()}
                  </TableCell>
                  <TableCell align="right">R$ {week.balance.toFixed(2)}</TableCell>
                  <TableCell align="right">R$ {week.spent.toFixed(2)}</TableCell>
                  <TableCell align="right">R$ {week.remaining.toFixed(2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>
    </Grid>
  );
}
