import { Request, Response } from 'express';
import { getDatabase } from '../database/connection';

// Interface para o Cash Flow
interface CashFlow {
  id?: number;
  date: string;
  description: string;
  amount: number;
  record_type: 'Despesa' | 'Receita';
  category_id?: number;
  subcategory_id?: number;
  cost_center_id?: number;
  category_name?: string;
  subcategory_name?: string;
  cost_center_name?: string;
  cost_center_number?: string;
  created_at?: string;
  updated_at?: string;
}

export const CashFlowController = {
  // Listar todos os registros de cash flow
  getAll: async (req: Request, res: Response) => {
    try {
      const { db, all } = getDatabase();
      const { month, year } = req.query;
      const userCostCenterId = (req as any).user?.cost_center_id;

      let query = `
        SELECT 
          cf.id,
          cf.date,
          cf.description,
          cf.amount,
          cf.record_type,
          cf.category_id,
          cf.subcategory_id,
          cf.cost_center_id,
          c.name as category_name,
          sc.name as subcategory_name,
          cc.name as cost_center_name,
          cc.number as cost_center_number,
          cf.created_at,
          cf.updated_at
        FROM cash_flow cf
        LEFT JOIN categories c ON cf.category_id = c.id
        LEFT JOIN subcategories sc ON cf.subcategory_id = sc.id
        LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
      `;

      const params: any[] = [];
      const whereConditions: string[] = [];

      // Filtro por mês/ano se fornecido
      if (month && year) {
        whereConditions.push("strftime('%m', cf.date) = ? AND strftime('%Y', cf.date) = ?");
        params.push(month.toString().padStart(2, '0'), year.toString());
      }

      // Filtro por centro de custo do usuário
      if (req.query.cost_center_id) {
        console.log('======= FILTRO DE CENTRO DE CUSTO (CashFlow) =======');
        console.log('Tipo do cost_center_id:', typeof req.query.cost_center_id);
        console.log('Valor do cost_center_id:', req.query.cost_center_id);
        
        // Se o valor for 'all', não aplicar filtro de centro de custo
        if (req.query.cost_center_id === 'all') {
          console.log('Mostrando todos os centros de custo no CashFlow');
        } else {
          // Verificar se tem vírgula, indicando múltiplos valores
          if (req.query.cost_center_id.toString().includes(',')) {
            // Múltiplos centros de custo separados por vírgula
            const costCenterIds = req.query.cost_center_id.toString().split(',').map(id => id.trim());
            
            // Converter IDs para números e filtrar valores inválidos
            const numericIds = costCenterIds
              .map(id => parseInt(id, 10))
              .filter(id => !isNaN(id));
            
            console.log('IDs originais (CashFlow):', costCenterIds);
            console.log('IDs numéricos (CashFlow):', numericIds);
            
            if (numericIds.length > 0) {
              // Construir cláusula IN diretamente na condição
              whereConditions.push(`cf.cost_center_id IN (${numericIds.join(',')})`);
              
              // Não adiciona parâmetros já que os IDs estão diretamente na cláusula SQL
              console.log('Cláusula SQL para múltiplos centros (CashFlow):', `cf.cost_center_id IN (${numericIds.join(',')})`);
            }
          } else {
            // Único centro de custo
            const costCenterId = parseInt(req.query.cost_center_id.toString(), 10);
            if (!isNaN(costCenterId)) {
              whereConditions.push("cf.cost_center_id = ?");
              params.push(costCenterId);
              console.log('Cláusula SQL para centro único (CashFlow):', 'cf.cost_center_id = ?', costCenterId);
            }
          }
        }
      } else if (userCostCenterId && req.query.show_all_centers !== 'true') {
        whereConditions.push("cf.cost_center_id = ?");
        params.push(userCostCenterId);
      }

      // Adicionar cláusula WHERE se houver condições
      if (whereConditions.length > 0) {
        query += ` WHERE ${whereConditions.join(' AND ')}`;
      }

      query += ` ORDER BY cf.date DESC, cf.created_at DESC`;

      console.log('SQL query antes de executar (CashFlow):', query);
      console.log('SQL params antes de executar (CashFlow):', params);
      
      // Imprimir a consulta com parâmetros substituídos para depuração
      let debugSql = query;
      for (const param of params) {
        if (typeof param === 'string') {
          debugSql = debugSql.replace('?', `'${param}'`);
        } else if (param === null) {
          debugSql = debugSql.replace('?', 'NULL');
        } else {
          debugSql = debugSql.replace('?', param);
        }
      }
      
      console.log('SQL COMPLETA COM PARÂMETROS (CashFlow):', debugSql);

      const rows = await all(db, query, params);
      res.json(rows);
    } catch (error) {
      console.error('Error in getAll cash flow:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  },
  
// Obter um registro específico
  getById: async (req: Request, res: Response) => {
    try {
      const { db, get } = getDatabase();
      const { id } = req.params;

      const query = `
        SELECT
          cf.id,
          cf.date,
          cf.description,
          cf.amount,
          cf.record_type,
          cf.category_id,
          cf.subcategory_id,
          cf.cost_center_id,
          c.name as category_name,
          sc.name as subcategory_name,
          cc.name as cost_center_name,
          cc.number as cost_center_number,
          cf.created_at,
          cf.updated_at
        FROM cash_flow cf
        LEFT JOIN categories c ON cf.category_id = c.id
        LEFT JOIN subcategories sc ON cf.subcategory_id = sc.id
        LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
        WHERE cf.id = ?
      `;

      const row = await get(db, query, [id]);
      if (!row) {
        return res.status(404).json({ error: 'Cash flow record not found' });
      }
      res.json(row);
    } catch (error) {
      console.error('Error in getById cash flow:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  },

  // Criar novo registro
  create: async (req: Request, res: Response) => {
    try {
      const { db, run, get } = getDatabase();
      const { date, description, amount, record_type, category_id, subcategory_id, cost_center_id }: CashFlow = req.body;
      const userCostCenterId = (req as any).user?.cost_center_id;

      // Validações básicas
      if (!date || !description || !amount || !record_type) {
        return res.status(400).json({ error: 'Required fields: date, description, amount, record_type' });
      }

      if (!['Despesa', 'Receita'].includes(record_type)) {
        return res.status(400).json({ error: 'record_type must be "Despesa" or "Receita"' });
      }

      // Garantir que sempre haja um centro de custo (do usuário se não for especificado)
      let effectiveCostCenterId = userCostCenterId;
      if (cost_center_id !== undefined && cost_center_id !== null && String(cost_center_id) !== '') {
        effectiveCostCenterId = Number(cost_center_id);
      }

      // Validar se o centro de custo é obrigatório
      if (!effectiveCostCenterId) {
        return res.status(400).json({ error: 'Centro de custo é obrigatório' });
      }

      const query = `
        INSERT INTO cash_flow (date, description, amount, record_type, category_id, subcategory_id, cost_center_id, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `;

      const params = [
        date,
        description,
        amount,
        record_type,
        category_id || null,
        subcategory_id || null,
        effectiveCostCenterId
      ];

      const result: any = await run(db, query, params);
      
      // Retornar o registro criado
      const selectQuery = `
        SELECT
          cf.id,
          cf.date,
          cf.description,
          cf.amount,
          cf.record_type,
          cf.category_id,
          cf.subcategory_id,
          cf.cost_center_id,
          c.name as category_name,
          sc.name as subcategory_name,
          cc.name as cost_center_name,
          cc.number as cost_center_number,
          cf.created_at,
          cf.updated_at
        FROM cash_flow cf
        LEFT JOIN categories c ON cf.category_id = c.id
        LEFT JOIN subcategories sc ON cf.subcategory_id = sc.id
        LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
        WHERE cf.id = ?
      `;
      
      const createdRecord = await get(db, selectQuery, [result.lastID]);
      res.status(201).json(createdRecord);
    } catch (error) {
      console.error('Error creating cash flow record:', error);
      res.status(500).json({ error: 'Failed to create cash flow record' });
    }
  },

  // Atualizar registro
  update: async (req: Request, res: Response) => {
    try {
      const { db, get, run } = getDatabase();
      const { id } = req.params;
      const { date, description, amount, record_type, category_id, subcategory_id, cost_center_id }: Partial<CashFlow> = req.body;

      // Verificar se o registro existe
      const existingRecord = await get(db, 'SELECT id FROM cash_flow WHERE id = ?', [id]);
      if (!existingRecord) {
        return res.status(404).json({ error: 'Cash flow record not found' });
      }

      // Construir query de atualização dinamicamente
      const fields: string[] = [];
      const params: any[] = [];

      if (date !== undefined) {
        fields.push('date = ?');
        params.push(date);
      }
      if (description !== undefined) {
        fields.push('description = ?');
        params.push(description);
      }
      if (amount !== undefined) {
        fields.push('amount = ?');
        params.push(amount);
      }
      if (record_type !== undefined) {
        if (!['Despesa', 'Receita'].includes(record_type)) {
          return res.status(400).json({ error: 'record_type must be "Despesa" or "Receita"' });
        }
        fields.push('record_type = ?');
        params.push(record_type);
      }
      if (category_id !== undefined) {
        fields.push('category_id = ?');
        params.push(category_id || null);
      }
      if (subcategory_id !== undefined) {
        fields.push('subcategory_id = ?');
        params.push(subcategory_id || null);
      }
      if (cost_center_id !== undefined) {
        fields.push('cost_center_id = ?');
        params.push(cost_center_id || null);
      }

      // Sempre atualizar o campo updated_at
      fields.push('updated_at = CURRENT_TIMESTAMP');

      if (fields.length === 1) { // Apenas updated_at
        return res.status(400).json({ error: 'No fields to update' });
      }

      const query = `UPDATE cash_flow SET ${fields.join(', ')} WHERE id = ?`;
      params.push(id);

      await run(db, query, params);

      // Retornar o registro atualizado
      const selectQuery = `
        SELECT
          cf.id,
          cf.date,
          cf.description,
          cf.amount,
          cf.record_type,
          cf.category_id,
          cf.subcategory_id,
          cf.cost_center_id,
          c.name as category_name,
          sc.name as subcategory_name,
          cc.name as cost_center_name,
          cc.number as cost_center_number,
          cf.created_at,
          cf.updated_at
        FROM cash_flow cf
        LEFT JOIN categories c ON cf.category_id = c.id
        LEFT JOIN subcategories sc ON cf.subcategory_id = sc.id
        LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
        WHERE cf.id = ?
      `;

      const updatedRecord = await get(db, selectQuery, [id]);
      res.json(updatedRecord);
    } catch (error) {
      console.error('Error updating cash flow record:', error);
      res.status(500).json({ error: 'Failed to update cash flow record' });
    }
  },

  // Deletar registro
  delete: async (req: Request, res: Response) => {
    try {
      const { db, get, run } = getDatabase();
      const { id } = req.params;

      // Verificar se o registro existe
      const existingRecord = await get(db, 'SELECT id FROM cash_flow WHERE id = ?', [id]);
      if (!existingRecord) {
        return res.status(404).json({ error: 'Cash flow record not found' });
      }

      await run(db, 'DELETE FROM cash_flow WHERE id = ?', [id]);
      res.status(204).send();
    } catch (error) {
      console.error('Error deleting cash flow record:', error);
      res.status(500).json({ error: 'Failed to delete cash flow record' });
    }
  }
};