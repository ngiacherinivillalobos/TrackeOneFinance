const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

// Tabelas que precisam de sequências configuradas
const tablesNeedingSequences = [
  'bank_accounts',
  'cards',
  'categories',
  'contacts',
  'cost_centers',
  'savings_goals',
  'subcategories',
  'users'
];

async function fixAllSequences() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Processar cada tabela que precisa de sequência
    for (const tableName of tablesNeedingSequences) {
      console.log(`\n=== Processando tabela: ${tableName} ===`);
      
      // Verificar se a tabela existe
      const tableExists = await pgClient.query(`
        SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_name = $1
        )
      `, [tableName]);
      
      if (!tableExists.rows[0].exists) {
        console.log(`Tabela ${tableName} não encontrada, pulando...`);
        continue;
      }
      
      // Verificar se já tem sequência
      const sequenceCheck = await pgClient.query(`
        SELECT pg_get_serial_sequence($1, 'id') as sequence_name
      `, [tableName]);
      
      if (sequenceCheck.rows[0].sequence_name) {
        console.log(`Tabela ${tableName} já tem sequência configurada: ${sequenceCheck.rows[0].sequence_name}`);
        continue;
      }
      
      // Criar sequência para a tabela
      const sequenceName = `${tableName}_id_seq`;
      console.log(`Criando sequência ${sequenceName}...`);
      await pgClient.query(`
        CREATE SEQUENCE IF NOT EXISTS ${sequenceName}
        START WITH 1
        INCREMENT BY 1
        NO MINVALUE
        NO MAXVALUE
        CACHE 1
      `);
      
      // Configurar a coluna id para usar a sequência
      console.log(`Configurando coluna id para usar a sequência...`);
      await pgClient.query(`
        ALTER TABLE ${tableName} 
        ALTER COLUMN id SET DEFAULT nextval('${sequenceName}')
      `);
      
      // Configurar a sequência como "owned by" da tabela
      console.log(`Configurando sequência como "owned by" da tabela...`);
      await pgClient.query(`
        ALTER SEQUENCE ${sequenceName} OWNED BY ${tableName}.id
      `);
      
      // Verificar o próximo valor da sequência
      console.log(`Verificando próximo valor da sequência...`);
      const nextValResult = await pgClient.query(`
        SELECT nextval('${sequenceName}') as next_id
      `);
      
      console.log(`Próximo ID disponível: ${nextValResult.rows[0].next_id}`);
      
      // Resetar a sequência para o próximo valor correto
      console.log(`Verificando o maior ID existente...`);
      const maxIdResult = await pgClient.query(`
        SELECT COALESCE(MAX(id), 0) as max_id FROM ${tableName}
      `);
      
      const maxId = maxIdResult.rows[0].max_id;
      console.log(`Maior ID existente: ${maxId}`);
      
      if (maxId > 0) {
        console.log(`Resetando sequência para o próximo valor correto...`);
        await pgClient.query(`
          SELECT setval('${sequenceName}', $1)
        `, [maxId]);
        
        // Verificar novamente o próximo valor da sequência
        console.log(`Verificando próximo valor da sequência após reset...`);
        const nextValResult2 = await pgClient.query(`
          SELECT nextval('${sequenceName}') as next_id
        `);
        
        console.log(`Próximo ID disponível após reset: ${nextValResult2.rows[0].next_id}`);
      } else {
        console.log(`Nenhum registro existente, mantendo sequência no valor inicial`);
      }
      
      console.log(`Sequência para ${tableName} configurada com sucesso!`);
    }
    
    console.log('\n=== Resumo ===');
    console.log('Todas as sequências necessárias foram configuradas!');
    
  } catch (error) {
    console.error('Erro ao configurar sequências:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

fixAllSequences();