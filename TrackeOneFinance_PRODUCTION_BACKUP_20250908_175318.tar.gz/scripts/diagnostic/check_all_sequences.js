const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkAllSequences() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar todas as tabelas e suas colunas id
    console.log('Verificando todas as tabelas com coluna id...');
    const tablesResult = await pgClient.query(`
      SELECT 
        table_name,
        column_name,
        data_type,
        is_nullable,
        column_default
      FROM information_schema.columns 
      WHERE column_name = 'id' AND table_schema = 'public'
      ORDER BY table_name
    `);
    
    console.log('Tabelas com coluna id:');
    for (const row of tablesResult.rows) {
      console.log(`\nTabela: ${row.table_name}`);
      console.log(`  Coluna: ${row.column_name}`);
      console.log(`  Tipo: ${row.data_type}`);
      console.log(`  Nullable: ${row.is_nullable}`);
      console.log(`  Default: ${row.column_default || 'NENHUM'}`);
      
      // Verificar se há sequência para esta coluna
      const sequenceResult = await pgClient.query(`
        SELECT pg_get_serial_sequence($1, 'id') as sequence_name
      `, [row.table_name]);
      
      if (sequenceResult.rows[0].sequence_name) {
        console.log(`  Sequência: ${sequenceResult.rows[0].sequence_name}`);
      } else {
        console.log(`  Sequência: NENHUMA`);
      }
    }
    
  } catch (error) {
    console.error('Erro ao verificar estrutura das tabelas:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

checkAllSequences();