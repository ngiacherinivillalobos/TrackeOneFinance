const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function fixTableSequences() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!\n');
    
    // Verificar se as tabelas já têm as colunas corretas
    console.log('Verificando estrutura atual das tabelas...\n');
    
    // Verificar category_types
    const categoryTypesCheck = await pgClient.query(`
      SELECT column_name, data_type, is_nullable, column_default
      FROM information_schema.columns 
      WHERE table_name = 'category_types' AND column_name = 'id'
    `);
    
    console.log('category_types.id:', categoryTypesCheck.rows[0]);
    
    // Verificar payment_status
    const paymentStatusCheck = await pgClient.query(`
      SELECT column_name, data_type, is_nullable, column_default
      FROM information_schema.columns 
      WHERE table_name = 'payment_status' AND column_name = 'id'
    `);
    
    console.log('payment_status.id:', paymentStatusCheck.rows[0]);
    
    // Verificar se as colunas id são auto-incremento
    console.log('\nVerificando se as colunas id são auto-incremento...');
    const categorySerialCheck = await pgClient.query(`
      SELECT pg_get_serial_sequence('category_types', 'id') as sequence_name
    `);
    
    const paymentSerialCheck = await pgClient.query(`
      SELECT pg_get_serial_sequence('payment_status', 'id') as sequence_name
    `);
    
    console.log('category_types sequence:', categorySerialCheck.rows[0].sequence_name);
    console.log('payment_status sequence:', paymentSerialCheck.rows[0].sequence_name);
    
    // Se as tabelas não têm sequências, precisamos corrigi-las
    if (!categorySerialCheck.rows[0].sequence_name) {
      console.log('\nCorrigindo tabela category_types...');
      
      // Criar uma nova tabela com a estrutura correta
      await pgClient.query(`
        CREATE TABLE category_types_new (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL UNIQUE,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
      
      // Copiar os dados existentes
      await pgClient.query(`
        INSERT INTO category_types_new (id, name, created_at)
        SELECT id, name, created_at FROM category_types
      `);
      
      // Remover a tabela antiga
      await pgClient.query('DROP TABLE category_types');
      
      // Renomear a nova tabela
      await pgClient.query('ALTER TABLE category_types_new RENAME TO category_types');
      
      console.log('Tabela category_types corrigida com sucesso!');
    } else {
      console.log('\nTabela category_types já está correta.');
    }
    
    if (!paymentSerialCheck.rows[0].sequence_name) {
      console.log('\nCorrigindo tabela payment_status...');
      
      // Criar uma nova tabela com a estrutura correta
      await pgClient.query(`
        CREATE TABLE payment_status_new (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL UNIQUE,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
      
      // Copiar os dados existentes
      await pgClient.query(`
        INSERT INTO payment_status_new (id, name, created_at)
        SELECT id, name, created_at FROM payment_status
      `);
      
      // Remover a tabela antiga
      await pgClient.query('DROP TABLE payment_status');
      
      // Renomear a nova tabela
      await pgClient.query('ALTER TABLE payment_status_new RENAME TO payment_status');
      
      console.log('Tabela payment_status corrigida com sucesso!');
    } else {
      console.log('\nTabela payment_status já está correta.');
    }
    
    // Verificar novamente a estrutura
    console.log('\n=== VERIFICAÇÃO FINAL ===');
    const finalCategoryCheck = await pgClient.query(`
      SELECT pg_get_serial_sequence('category_types', 'id') as sequence_name
    `);
    
    const finalPaymentCheck = await pgClient.query(`
      SELECT pg_get_serial_sequence('payment_status', 'id') as sequence_name
    `);
    
    console.log('category_types sequence (final):', finalCategoryCheck.rows[0].sequence_name || 'NENHUMA');
    console.log('payment_status sequence (final):', finalPaymentCheck.rows[0].sequence_name || 'NENHUMA');
    
    if (finalCategoryCheck.rows[0].sequence_name && finalPaymentCheck.rows[0].sequence_name) {
      console.log('\n✅ Todas as tabelas foram corrigidas com sucesso!');
    } else {
      console.log('\n⚠️  Algumas tabelas ainda precisam de correção.');
    }
    
  } catch (error) {
    console.error('Erro ao corrigir sequências das tabelas:', error);
  } finally {
    await pgClient.end();
    console.log('\nConexão encerrada.');
  }
}

fixTableSequences();