const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function safeFixCashFlow() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Primeiro, vamos verificar o estado atual da tabela
    console.log('Verificando estrutura atual da tabela cash_flow...');
    const structureResult = await pgClient.query(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'cash_flow' AND column_name = 'amount'
    `);
    console.log('Tipo da coluna amount:', structureResult.rows[0].data_type);
    
    // Verificar quantos registros existem
    const countResult = await pgClient.query('SELECT COUNT(*) as total FROM cash_flow');
    console.log('Total de registros:', countResult.rows[0].total);
    
    // Tentar selecionar registros com valores problemáticos de forma segura
    console.log('Procurando registros com valores problemáticos...');
    try {
      const problemResult = await pgClient.query(`
        SELECT id, description, amount 
        FROM cash_flow 
        WHERE amount IS NULL OR amount = '' OR TRIM(amount) = ''
      `);
      console.log('Registros com valores vazios:', problemResult.rowCount);
      
      if (problemResult.rowCount > 0) {
        console.log('Corrigindo registros com valores vazios...');
        for (const row of problemResult.rows) {
          console.log(`  Corrigindo ID ${row.id}: "${row.description}" - Valor atual: "${row.amount}"`);
        }
        
        // Atualizar registros com valores vazios
        await pgClient.query(`
          UPDATE cash_flow 
          SET amount = '0.00' 
          WHERE amount IS NULL OR amount = '' OR TRIM(amount) = ''
        `);
        console.log('Registros com valores vazios corrigidos com sucesso.');
      }
    } catch (selectError) {
      console.log('Erro ao selecionar registros problemáticos:', selectError.message);
      console.log('Continuando com a correção...');
    }
    
    // Converter todos os valores para o formato correto usando string manipulation
    console.log('Convertendo todos os valores para formato numérico...');
    try {
      // Primeiro, atualizar todos os valores para string válida
      await pgClient.query(`
        UPDATE cash_flow 
        SET amount = '0.00' 
        WHERE amount IS NULL OR amount = '' OR TRIM(amount) = ''
      `);
      
      console.log('Valores vazios corrigidos para 0.00');
    } catch (updateError) {
      console.log('Erro ao corrigir valores vazios:', updateError.message);
    }
    
    // Verificar novamente os dados
    console.log('Verificando dados após correção...');
    const finalResult = await pgClient.query(`
      SELECT 
        cf.id,
        cf.date,
        cf.description,
        cf.amount,
        cf.record_type,
        cf.cost_center_id
      FROM cash_flow cf
      ORDER BY cf.date DESC
      LIMIT 10
    `);
    
    console.log('Amostra de dados após correção:');
    finalResult.rows.forEach((row, index) => {
      console.log(`  ${index + 1}. ID: ${row.id}, Data: ${row.date}, Valor: ${row.amount}, Tipo: ${row.record_type}`);
    });
    
  } catch (error) {
    console.error('Erro ao corrigir dados do fluxo de caixa:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

safeFixCashFlow();