const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function testCashFlowEndpoint() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Testar a consulta que estava falhando
    console.log('Testando consulta do endpoint /api/cash-flow?month=09&year=2025&cost_center_id=1...');
    
    const query = `
      SELECT 
        cf.id,
        cf.date,
        cf.description,
        cf.amount,
        cf.record_type,
        cf.category_id,
        cf.subcategory_id,
        cf.cost_center_id,
        c.name as category_name,
        sc.name as subcategory_name,
        cc.name as cost_center_name,
        cc.number as cost_center_number,
        cf.created_at,
        cf.updated_at
      FROM cash_flow cf
      LEFT JOIN categories c ON cf.category_id = c.id
      LEFT JOIN subcategories sc ON cf.subcategory_id = sc.id
      LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
      WHERE EXTRACT(MONTH FROM cf.date) = $1 AND EXTRACT(YEAR FROM cf.date) = $2 AND cf.cost_center_id = $3
      ORDER BY cf.date DESC, cf.created_at DESC
    `;
    
    const params = [9, 2025, 1];
    
    console.log('Executando query:', query);
    console.log('Parâmetros:', params);
    
    const result = await pgClient.query(query, params);
    console.log('Consulta bem-sucedida!');
    console.log('Número de registros encontrados:', result.rowCount);
    
    // Mostrar os primeiros registros (se houver)
    if (result.rows.length > 0) {
      console.log('Primeiros 3 registros:');
      result.rows.slice(0, 3).forEach((row, index) => {
        console.log(`  Registro ${index + 1}:`, {
          id: row.id,
          date: row.date,
          description: row.description,
          amount: row.amount,
          record_type: row.record_type
        });
      });
    } else {
      console.log('Nenhum registro encontrado para os filtros especificados.');
    }
    
  } catch (error) {
    console.error('Erro ao testar endpoint do fluxo de caixa:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

testCashFlowEndpoint();