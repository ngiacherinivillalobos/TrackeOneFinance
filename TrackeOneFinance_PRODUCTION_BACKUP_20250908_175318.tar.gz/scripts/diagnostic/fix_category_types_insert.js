const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function fixCategoryTypesInsert() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar se há dados na tabela category_types
    console.log('Verificando dados na tabela category_types...');
    const countResult = await pgClient.query('SELECT COUNT(*) as total FROM category_types');
    console.log('Total de registros na tabela category_types:', countResult.rows[0].total);
    
    // Se não houver dados, inserir os valores corretos
    if (countResult.rows[0].total === '0') {
      console.log('Inserindo dados na tabela category_types...');
      await pgClient.query(`
        INSERT INTO category_types (id, name) VALUES 
        (1, 'Despesa'),
        (2, 'Receita'),
        (3, 'Transferência'),
        (4, 'Investimento')
        ON CONFLICT (id) DO NOTHING
      `);
      console.log('Dados inseridos com sucesso na tabela category_types');
    } else {
      console.log('A tabela category_types já contém dados');
    }
    
    // Verificar se há dados na tabela payment_status
    console.log('Verificando dados na tabela payment_status...');
    const paymentCountResult = await pgClient.query('SELECT COUNT(*) as total FROM payment_status');
    console.log('Total de registros na tabela payment_status:', paymentCountResult.rows[0].total);
    
    // Se não houver dados, inserir os valores corretos
    if (paymentCountResult.rows[0].total === '0') {
      console.log('Inserindo dados na tabela payment_status...');
      await pgClient.query(`
        INSERT INTO payment_status (id, name) VALUES 
        (1, 'Pago'),
        (2, 'Pendente')
        ON CONFLICT (id) DO NOTHING
      `);
      console.log('Dados inseridos com sucesso na tabela payment_status');
    } else {
      console.log('A tabela payment_status já contém dados');
    }
    
    // Verificar os dados inseridos
    console.log('Verificando dados inseridos...');
    const categoryTypesResult = await pgClient.query('SELECT * FROM category_types ORDER BY id');
    console.log('Dados da tabela category_types:');
    categoryTypesResult.rows.forEach(row => {
      console.log(`  ID: ${row.id}, Nome: ${row.name}`);
    });
    
    const paymentStatusResult = await pgClient.query('SELECT * FROM payment_status ORDER BY id');
    console.log('Dados da tabela payment_status:');
    paymentStatusResult.rows.forEach(row => {
      console.log(`  ID: ${row.id}, Nome: ${row.name}`);
    });
    
  } catch (error) {
    console.error('Erro ao corrigir inserção de dados:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

fixCategoryTypesInsert();