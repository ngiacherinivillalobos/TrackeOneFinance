const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkPaymentDetails() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar se a tabela payment_details existe
    console.log('Verificando se a tabela payment_details existe...');
    const result = await pgClient.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'payment_details'
      )
    `);
    
    const tableExists = result.rows[0].exists;
    console.log('Tabela payment_details existe:', tableExists);
    
    if (tableExists) {
      // Verificar a estrutura da tabela
      console.log('Verificando estrutura da tabela payment_details...');
      const structure = await pgClient.query(`
        SELECT column_name, data_type, is_nullable 
        FROM information_schema.columns 
        WHERE table_name = 'payment_details'
        ORDER BY ordinal_position
      `);
      
      console.log('Estrutura da tabela payment_details:');
      structure.rows.forEach(row => {
        console.log(`  ${row.column_name}: ${row.data_type} (${row.is_nullable})`);
      });
      
      // Verificar quantos registros existem
      console.log('Verificando número de registros na tabela payment_details...');
      const countResult = await pgClient.query('SELECT COUNT(*) as total FROM payment_details');
      console.log('Total de registros na tabela payment_details:', countResult.rows[0].total);
    } else {
      console.log('A tabela payment_details não existe no banco de dados.');
    }
    
  } catch (error) {
    console.error('Erro ao verificar tabela payment_details:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

checkPaymentDetails();