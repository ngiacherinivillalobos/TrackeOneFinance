const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkCashFlowData() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar quantos registros existem na tabela cash_flow
    console.log('Verificando número total de registros na tabela cash_flow...');
    const countResult = await pgClient.query('SELECT COUNT(*) as total FROM cash_flow');
    console.log('Total de registros na tabela cash_flow:', countResult.rows[0].total);
    
    // Verificar se há registros com datas válidas
    console.log('Verificando registros com datas válidas...');
    const validDatesResult = await pgClient.query('SELECT COUNT(*) as total FROM cash_flow WHERE date IS NOT NULL');
    console.log('Registros com datas válidas:', validDatesResult.rows[0].total);
    
    // Verificar se há registros com valores numéricos válidos
    console.log('Verificando registros com valores numéricos válidos...');
    const validAmountsResult = await pgClient.query('SELECT COUNT(*) as total FROM cash_flow WHERE amount IS NOT NULL AND amount != \'\'');
    console.log('Registros com valores numéricos válidos:', validAmountsResult.rows[0].total);
    
    // Mostrar alguns registros de exemplo
    console.log('Mostrando 5 registros de exemplo...');
    const sampleResult = await pgClient.query(`
      SELECT 
        cf.id,
        cf.date,
        cf.description,
        cf.amount,
        cf.record_type,
        cf.cost_center_id,
        cc.name as cost_center_name
      FROM cash_flow cf
      LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
      ORDER BY cf.date DESC
      LIMIT 5
    `);
    
    if (sampleResult.rows.length > 0) {
      sampleResult.rows.forEach((row, index) => {
        console.log(`  Registro ${index + 1}:`, {
          id: row.id,
          date: row.date,
          description: row.description,
          amount: row.amount,
          record_type: row.record_type,
          cost_center_id: row.cost_center_id,
          cost_center_name: row.cost_center_name
        });
      });
    } else {
      console.log('Nenhum registro encontrado na tabela cash_flow.');
    }
    
    // Verificar os centros de custo disponíveis
    console.log('Verificando centros de custo disponíveis...');
    const costCentersResult = await pgClient.query('SELECT id, name, number FROM cost_centers ORDER BY id');
    console.log('Centros de custo disponíveis:');
    costCentersResult.rows.forEach(cc => {
      console.log(`  ID: ${cc.id}, Nome: ${cc.name}, Número: ${cc.number}`);
    });
    
  } catch (error) {
    console.error('Erro ao verificar dados do fluxo de caixa:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

checkCashFlowData();