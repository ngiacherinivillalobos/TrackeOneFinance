const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function testConnection() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Testar se a tabela cash_flow existe
    console.log('Verificando se a tabela cash_flow existe...');
    const result = await pgClient.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'cash_flow'
      )
    `);
    
    const tableExists = result.rows[0].exists;
    console.log('Tabela cash_flow existe:', tableExists);
    
    if (tableExists) {
      // Verificar a estrutura da tabela
      console.log('Verificando estrutura da tabela cash_flow...');
      const structure = await pgClient.query(`
        SELECT column_name, data_type, is_nullable 
        FROM information_schema.columns 
        WHERE table_name = 'cash_flow'
        ORDER BY ordinal_position
      `);
      
      console.log('Estrutura da tabela cash_flow:');
      structure.rows.forEach(row => {
        console.log(`  ${row.column_name}: ${row.data_type} (${row.is_nullable})`);
      });
    } else {
      console.log('A tabela cash_flow não existe no banco de dados.');
    }
    
    // Testar uma consulta simples
    console.log('Testando consulta simples...');
    const testQuery = await pgClient.query('SELECT NOW() as current_time');
    console.log('Consulta bem-sucedida:', testQuery.rows[0]);
    
  } catch (error) {
    console.error('Erro ao testar conexão com PostgreSQL:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

testConnection();