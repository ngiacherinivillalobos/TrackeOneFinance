const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function fixCashFlowAmounts() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Primeiro, converter todos os valores para texto e depois para numérico
    console.log('Convertendo valores do campo amount...');
    
    // Atualizar registros com valores vazios ou inválidos para 0.00
    console.log('Corrigindo registros com valores vazios ou inválidos...');
    const updateEmptyResult = await pgClient.query(`
      UPDATE cash_flow 
      SET amount = '0.00' 
      WHERE amount IS NULL OR amount = '' OR TRIM(amount) = '' OR amount = 'null'
    `);
    console.log('Registros com valores vazios corrigidos:', updateEmptyResult.rowCount);
    
    // Converter todos os valores para o formato correto (mantendo apenas números, ponto e sinal)
    console.log('Convertendo valores para formato numérico...');
    const convertResult = await pgClient.query(`
      UPDATE cash_flow 
      SET amount = 
        CASE 
          WHEN amount ~ '^-?[0-9]+\.?[0-9]*$' THEN amount::numeric(10,2)::text
          ELSE '0.00'
        END
      WHERE amount IS NOT NULL AND amount != ''
    `);
    console.log('Registros convertidos:', convertResult.rowCount);
    
    // Verificar novamente os dados
    console.log('Verificando registros com valores numéricos válidos...');
    const validAmountsResult = await pgClient.query(`
      SELECT COUNT(*) as total 
      FROM cash_flow 
      WHERE amount IS NOT NULL 
      AND amount != '' 
      AND amount ~ '^-?[0-9]+\.?[0-9]*$'
    `);
    console.log('Registros com valores numéricos válidos:', validAmountsResult.rows[0].total);
    
    // Mostrar alguns registros de exemplo após a correção
    console.log('Mostrando 5 registros de exemplo após correção...');
    const sampleResult = await pgClient.query(`
      SELECT 
        cf.id,
        cf.date,
        cf.description,
        cf.amount,
        cf.record_type,
        cf.cost_center_id,
        cc.name as cost_center_name
      FROM cash_flow cf
      LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
      ORDER BY cf.date DESC
      LIMIT 5
    `);
    
    if (sampleResult.rows.length > 0) {
      sampleResult.rows.forEach((row, index) => {
        console.log(`  Registro ${index + 1}:`, {
          id: row.id,
          date: row.date,
          description: row.description,
          amount: row.amount,
          record_type: row.record_type,
          cost_center_id: row.cost_center_id,
          cost_center_name: row.cost_center_name
        });
      });
    } else {
      console.log('Nenhum registro encontrado na tabela cash_flow.');
    }
    
  } catch (error) {
    console.error('Erro ao corrigir valores do fluxo de caixa:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

fixCashFlowAmounts();