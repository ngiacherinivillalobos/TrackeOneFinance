const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function fixSchema() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar a estrutura atual da tabela
    console.log('Verificando estrutura atual da tabela cash_flow...');
    const currentStructure = await pgClient.query(`
      SELECT column_name, data_type, is_nullable 
      FROM information_schema.columns 
      WHERE table_name = 'cash_flow'
      ORDER BY ordinal_position
    `);
    
    console.log('Estrutura atual da tabela cash_flow:');
    currentStructure.rows.forEach(row => {
      console.log(`  ${row.column_name}: ${row.data_type} (${row.is_nullable})`);
    });
    
    // Corrigir a estrutura da tabela cash_flow
    console.log('Corrigindo estrutura da tabela cash_flow...');
    
    // Alterar o tipo da coluna date para DATE
    try {
      await pgClient.query('ALTER TABLE cash_flow ALTER COLUMN date TYPE DATE USING date::DATE');
      console.log('Coluna date corrigida para tipo DATE');
    } catch (error) {
      console.log('Coluna date já está correta ou erro ao corrigir:', error.message);
    }
    
    // Alterar o tipo da coluna amount para NUMERIC(10,2)
    try {
      await pgClient.query('ALTER TABLE cash_flow ALTER COLUMN amount TYPE NUMERIC(10,2) USING amount::NUMERIC(10,2)');
      console.log('Coluna amount corrigida para tipo NUMERIC(10,2)');
    } catch (error) {
      console.log('Coluna amount já está correta ou erro ao corrigir:', error.message);
    }
    
    // Verificar a nova estrutura da tabela
    console.log('Verificando nova estrutura da tabela cash_flow...');
    const newStructure = await pgClient.query(`
      SELECT column_name, data_type, is_nullable 
      FROM information_schema.columns 
      WHERE table_name = 'cash_flow'
      ORDER BY ordinal_position
    `);
    
    console.log('Nova estrutura da tabela cash_flow:');
    newStructure.rows.forEach(row => {
      console.log(`  ${row.column_name}: ${row.data_type} (${row.is_nullable})`);
    });
    
    // Testar uma consulta com filtro por mês/ano
    console.log('Testando consulta com filtro por mês/ano...');
    try {
      const testQuery = await pgClient.query(
        'SELECT * FROM cash_flow WHERE EXTRACT(MONTH FROM date) = $1 AND EXTRACT(YEAR FROM date) = $2 LIMIT 1',
        [9, 2025]
      );
      console.log('Consulta com filtro por mês/ano bem-sucedida!');
      console.log('Registros encontrados:', testQuery.rowCount);
    } catch (error) {
      console.error('Erro ao testar consulta com filtro por mês/ano:', error);
    }
    
  } catch (error) {
    console.error('Erro ao corrigir schema do PostgreSQL:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

fixSchema();