const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function insertTestData() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar se há centros de custo
    console.log('Verificando centros de custo...');
    const costCenterResult = await pgClient.query(`
      SELECT id, name FROM cost_centers LIMIT 1
    `);
    
    let costCenterId = 1;
    if (costCenterResult.rows.length > 0) {
      costCenterId = costCenterResult.rows[0].id;
      console.log('Usando centro de custo existente:', costCenterResult.rows[0].name);
    } else {
      // Criar um centro de custo de teste
      console.log('Criando centro de custo de teste...');
      const newCostCenter = await pgClient.query(`
        INSERT INTO cost_centers (name, number) 
        VALUES ('Centro de Custo Teste', '1001') 
        RETURNING id
      `);
      costCenterId = newCostCenter.rows[0].id;
      console.log('Centro de custo criado com ID:', costCenterId);
    }
    
    // Inserir registros de teste para setembro de 2025
    console.log('Inserindo registros de teste para setembro de 2025...');
    const testRecords = [
      {
        date: '2025-09-03',
        description: 'Teste de Deploy - Despesa 1',
        amount: 100.50,
        record_type: 'Despesa',
        category_id: null,
        subcategory_id: null
      },
      {
        date: '2025-09-03',
        description: 'Teste de Deploy - Receita 1',
        amount: 250.75,
        record_type: 'Receita',
        category_id: null,
        subcategory_id: null
      },
      {
        date: '2025-09-15',
        description: 'Teste de Deploy - Despesa 2',
        amount: 75.25,
        record_type: 'Despesa',
        category_id: null,
        subcategory_id: null
      }
    ];
    
    for (const record of testRecords) {
      const result = await pgClient.query(`
        INSERT INTO cash_flow (date, description, amount, record_type, category_id, subcategory_id, cost_center_id)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING id
      `, [
        record.date,
        record.description,
        record.amount,
        record.record_type,
        record.category_id,
        record.subcategory_id,
        costCenterId
      ]);
      
      console.log('Registro inserido com ID:', result.rows[0].id);
    }
    
    // Verificar os registros inseridos
    console.log('\nVerificando registros inseridos...');
    const checkResult = await pgClient.query(`
      SELECT 
        cf.id,
        cf.date,
        cf.description,
        cf.amount,
        cf.record_type,
        cf.cost_center_id,
        cc.name as cost_center_name
      FROM cash_flow cf
      LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
      WHERE EXTRACT(MONTH FROM cf.date) = 9 AND EXTRACT(YEAR FROM cf.date) = 2025
      ORDER BY cf.date DESC
    `);
    
    console.log('Registros encontrados para setembro de 2025:', checkResult.rowCount);
    
    if (checkResult.rows.length > 0) {
      checkResult.rows.forEach((row, index) => {
        console.log(`  ${index + 1}. ID: ${row.id}, Data: ${row.date}, Descrição: ${row.description}, Valor: ${row.amount}, Tipo: ${row.record_type}, Centro de Custo: ${row.cost_center_name || row.cost_center_id}`);
      });
    }
    
  } catch (error) {
    console.error('Erro ao inserir dados de teste:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

insertTestData();