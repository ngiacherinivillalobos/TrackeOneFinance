const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function fixSequences() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!\n');
    
    // Ajustar a sequência da tabela category_types
    console.log('Ajustando sequência da tabela category_types...');
    const maxCategoryIdResult = await pgClient.query('SELECT MAX(id) as max_id FROM category_types');
    const maxCategoryId = maxCategoryIdResult.rows[0].max_id || 0;
    console.log('Maior ID em category_types:', maxCategoryId);
    
    await pgClient.query(
      `SELECT setval('category_types_new_id_seq', $1, true)`,
      [maxCategoryId]
    );
    console.log('Sequência de category_types ajustada para:', maxCategoryId);
    
    // Ajustar a sequência da tabela payment_status
    console.log('\nAjustando sequência da tabela payment_status...');
    const maxPaymentIdResult = await pgClient.query('SELECT MAX(id) as max_id FROM payment_status');
    const maxPaymentId = maxPaymentIdResult.rows[0].max_id || 0;
    console.log('Maior ID em payment_status:', maxPaymentId);
    
    await pgClient.query(
      `SELECT setval('payment_status_new_id_seq', $1, true)`,
      [maxPaymentId]
    );
    console.log('Sequência de payment_status ajustada para:', maxPaymentId);
    
    // Testar inserção novamente
    console.log('\nTestando inserção após ajuste de sequências...');
    const testInsert1 = await pgClient.query(
      'INSERT INTO category_types (name) VALUES ($1) RETURNING id, name',
      ['Teste Sequência']
    );
    console.log('Inserção bem-sucedida (category_types):', testInsert1.rows[0]);
    
    const testInsert2 = await pgClient.query(
      'INSERT INTO payment_status (name) VALUES ($1) RETURNING id, name',
      ['Teste Sequência']
    );
    console.log('Inserção bem-sucedida (payment_status):', testInsert2.rows[0]);
    
    // Remover os dados de teste
    console.log('\nRemovendo dados de teste...');
    await pgClient.query(
      'DELETE FROM category_types WHERE name = $1',
      ['Teste Sequência']
    );
    await pgClient.query(
      'DELETE FROM payment_status WHERE name = $1',
      ['Teste Sequência']
    );
    console.log('Dados de teste removidos com sucesso!');
    
    console.log('\n✅ Sequências ajustadas com sucesso!');
    
  } catch (error) {
    console.error('Erro ao ajustar sequências:', error);
  } finally {
    await pgClient.end();
    console.log('\nConexão encerrada.');
  }
}

fixSequences();