const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkSeptemberData() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar registros para setembro de 2025
    console.log('Verificando registros para setembro de 2025...');
    const septemberResult = await pgClient.query(`
      SELECT 
        cf.id,
        cf.date,
        cf.description,
        cf.amount,
        cf.record_type,
        cf.cost_center_id,
        cc.name as cost_center_name
      FROM cash_flow cf
      LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
      WHERE EXTRACT(MONTH FROM cf.date) = 9 AND EXTRACT(YEAR FROM cf.date) = 2025
      ORDER BY cf.date DESC
    `);
    
    console.log('Registros encontrados para setembro de 2025:', septemberResult.rowCount);
    
    if (septemberResult.rows.length > 0) {
      septemberResult.rows.forEach((row, index) => {
        console.log(`  ${index + 1}. ID: ${row.id}, Data: ${row.date}, Descrição: ${row.description}, Valor: ${row.amount}, Tipo: ${row.record_type}, Centro de Custo: ${row.cost_center_name || row.cost_center_id}`);
      });
    }
    
    // Verificar registros para qualquer mês de 2025
    console.log('\nVerificando registros para 2025...');
    const yearResult = await pgClient.query(`
      SELECT 
        cf.id,
        cf.date,
        cf.description,
        cf.amount,
        cf.record_type,
        cf.cost_center_id,
        cc.name as cost_center_name,
        EXTRACT(MONTH FROM cf.date) as month
      FROM cash_flow cf
      LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
      WHERE EXTRACT(YEAR FROM cf.date) = 2025
      ORDER BY cf.date DESC
    `);
    
    console.log('Registros encontrados para 2025:', yearResult.rowCount);
    
    if (yearResult.rows.length > 0) {
      console.log('Registros por mês:');
      const monthlyData = {};
      yearResult.rows.forEach(row => {
        const month = row.month;
        if (!monthlyData[month]) {
          monthlyData[month] = 0;
        }
        monthlyData[month]++;
      });
      
      Object.keys(monthlyData).sort().forEach(month => {
        console.log(`  Mês ${month}: ${monthlyData[month]} registros`);
      });
    }
    
  } catch (error) {
    console.error('Erro ao verificar dados de setembro:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

checkSeptemberData();