#!/usr/bin/env node

// Script para deploy automatizado para produção
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('=== DEPLOY AUTOMATIZADO PARA PRODUÇÃO ===\n');

// Função para executar comandos
function runCommand(command, options = {}) {
  console.log(`Executando: ${command}`);
  try {
    const result = execSync(command, { 
      stdio: 'inherit', 
      cwd: process.cwd(),
      ...options
    });
    return result;
  } catch (error) {
    console.error(`Erro ao executar comando: ${command}`);
    console.error(error.message);
    if (!options.ignoreErrors) {
      process.exit(1);
    }
  }
}

// Verificar se estamos no diretório correto
const currentDir = process.cwd();
const projectName = path.basename(currentDir);
console.log(`Diretório atual: ${currentDir}`);
console.log(`Nome do projeto: ${projectName}\n`);

// Verificar se temos os arquivos necessários
const requiredFiles = [
  'server/package.json',
  'server/src/server.ts',
  'database/initial_postgres.sql',
  'database/migrations/add_cash_flow_table_postgres.sql',
  'database/migrations/add_cost_center_to_cash_flow_postgres.sql'
];

console.log('Verificando arquivos necessários...');
for (const file of requiredFiles) {
  const fullPath = path.join(currentDir, file);
  if (!fs.existsSync(fullPath)) {
    console.error(`❌ Arquivo necessário não encontrado: ${file}`);
    process.exit(1);
  }
  console.log(`✅ ${file}`);
}

console.log('\n');

// Compilar o projeto do servidor
console.log('=== COMPILANDO O PROJETO DO SERVIDOR ===');
runCommand('cd server && npm run build');

// Verificar se a compilação foi bem-sucedida
const distPath = path.join(currentDir, 'server', 'dist');
if (!fs.existsSync(distPath)) {
  console.error('❌ Diretório dist não foi criado após a compilação');
  process.exit(1);
}

console.log('✅ Compilação concluída com sucesso\n');

// Verificar se os arquivos de migração estão presentes
console.log('=== VERIFICANDO ARQUIVOS DE MIGRAÇÃO ===');
const migrationsDir = path.join(currentDir, 'database', 'migrations');
if (fs.existsSync(migrationsDir)) {
  const migrationFiles = fs.readdirSync(migrationsDir).filter(f => f.includes('_postgres.sql'));
  console.log(`Encontradas ${migrationFiles.length} migrações específicas do PostgreSQL:`);
  migrationFiles.forEach(file => console.log(`  - ${file}`));
} else {
  console.log('❌ Diretório de migrações não encontrado');
}

console.log('\n');

// Verificar o arquivo render.yaml
console.log('=== VERIFICANDO CONFIGURAÇÃO DO RENDER ===');
const renderYamlPath = path.join(currentDir, 'render.yaml');
if (fs.existsSync(renderYamlPath)) {
  console.log('✅ Arquivo render.yaml encontrado');
  const renderYaml = fs.readFileSync(renderYamlPath, 'utf8');
  console.log('Conteúdo do render.yaml:');
  console.log(renderYaml);
} else {
  console.log('❌ Arquivo render.yaml não encontrado');
}

console.log('\n');

// Verificar o arquivo package.json do servidor
console.log('=== VERIFICANDO PACKAGE.JSON DO SERVIDOR ===');
const serverPackagePath = path.join(currentDir, 'server', 'package.json');
if (fs.existsSync(serverPackagePath)) {
  const packageJson = JSON.parse(fs.readFileSync(serverPackagePath, 'utf8'));
  console.log('✅ package.json do servidor encontrado');
  console.log(`Nome: ${packageJson.name}`);
  console.log(`Versão: ${packageJson.version}`);
  console.log('Scripts disponíveis:');
  Object.keys(packageJson.scripts).forEach(script => {
    console.log(`  ${script}: ${packageJson.scripts[script]}`);
  });
} else {
  console.log('❌ package.json do servidor não encontrado');
}

console.log('\n');

// Verificar o arquivo inicial_postgres.sql
console.log('=== VERIFICANDO SCHEMA DO POSTGRESQL ===');
const postgresSchemaPath = path.join(currentDir, 'database', 'initial_postgres.sql');
if (fs.existsSync(postgresSchemaPath)) {
  console.log('✅ Arquivo initial_postgres.sql encontrado');
  const schemaContent = fs.readFileSync(postgresSchemaPath, 'utf8');
  
  // Verificar se as tabelas principais estão presentes
  const requiredTables = ['cash_flow', 'payment_details', 'categories', 'cost_centers'];
  console.log('Verificando tabelas essenciais no schema:');
  requiredTables.forEach(table => {
    if (schemaContent.includes(`CREATE TABLE IF NOT EXISTS ${table}`)) {
      console.log(`  ✅ ${table}`);
    } else {
      console.log(`  ❌ ${table}`);
    }
  });
} else {
  console.log('❌ Arquivo initial_postgres.sql não encontrado');
}

console.log('\n');

// Verificar se o start.js existe e está correto
console.log('=== VERIFICANDO SCRIPT DE INICIALIZAÇÃO ===');
const startJsPath = path.join(currentDir, 'server', 'start.js');
if (fs.existsSync(startJsPath)) {
  console.log('✅ Arquivo start.js encontrado');
  const startJsContent = fs.readFileSync(startJsPath, 'utf8');
  if (startJsContent.includes('npm run build')) {
    console.log('✅ Script de inicialização configura build automático');
  } else {
    console.log('⚠️  Verificar se o script de inicialização faz build automático');
  }
} else {
  console.log('❌ Arquivo start.js não encontrado');
}

console.log('\n');

console.log('=== RESUMO DO DEPLOY ===');
console.log('✅ Todos os arquivos necessários estão presentes');
console.log('✅ Projeto compilado com sucesso');
console.log('✅ Arquivos de migração específicos do PostgreSQL encontrados');
console.log('✅ Configuração do Render verificada');
console.log('✅ Schema do PostgreSQL contém tabelas essenciais');

console.log('\n=== PRÓXIMOS PASSOS ===');
console.log('1. Faça commit e push das alterações para o repositório GitHub');
console.log('2. O Render fará o deploy automático');
console.log('3. Verifique os logs do deploy no painel do Render');
console.log('4. Teste a API em produção');

console.log('\n=== COMANDOS PARA DEPLOY MANUAL (se necessário) ===');
console.log('git add .');
console.log('git commit -m "Deploy para produção com correções do fluxo de caixa e payment_details"');
console.log('git push origin main');

console.log('\n✅ DEPLOY PREPARADO COM SUCESSO!');