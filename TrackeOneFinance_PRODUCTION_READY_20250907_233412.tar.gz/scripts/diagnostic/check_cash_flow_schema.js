const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkCashFlowSchema() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar a estrutura da tabela cash_flow
    console.log('Verificando estrutura da tabela cash_flow...');
    const schemaResult = await pgClient.query(`
      SELECT 
        column_name, 
        data_type, 
        is_nullable,
        column_default
      FROM information_schema.columns 
      WHERE table_name = 'cash_flow'
      ORDER BY ordinal_position
    `);
    
    console.log('Estrutura da tabela cash_flow:');
    schemaResult.rows.forEach(row => {
      console.log(`  ${row.column_name}: ${row.data_type} (${row.is_nullable}) ${row.column_default ? 'DEFAULT: ' + row.column_default : ''}`);
    });
    
    // Verificar se há sequência para a coluna id
    console.log('\nVerificando sequência para a coluna id...');
    const sequenceResult = await pgClient.query(`
      SELECT 
        pg_get_serial_sequence('cash_flow', 'id') as sequence_name,
        column_default
      FROM information_schema.columns 
      WHERE table_name = 'cash_flow' AND column_name = 'id'
    `);
    
    if (sequenceResult.rows.length > 0) {
      console.log('Sequência para id:', sequenceResult.rows[0].sequence_name);
      console.log('Default para id:', sequenceResult.rows[0].column_default);
    } else {
      console.log('Nenhuma sequência encontrada para a coluna id');
    }
    
  } catch (error) {
    console.error('Erro ao verificar estrutura da tabela:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

checkCashFlowSchema();