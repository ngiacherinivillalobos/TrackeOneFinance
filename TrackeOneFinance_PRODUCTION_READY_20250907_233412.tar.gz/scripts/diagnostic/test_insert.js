const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function testInsert() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!\n');
    
    // Testar inserção sem especificar o ID (deve usar auto-incremento)
    console.log('Testando inserção na tabela category_types...');
    const result1 = await pgClient.query(
      'INSERT INTO category_types (name) VALUES ($1) RETURNING id, name',
      ['Teste Categoria']
    );
    console.log('Inserção bem-sucedida:', result1.rows[0]);
    
    // Testar inserção na tabela payment_status
    console.log('\nTestando inserção na tabela payment_status...');
    const result2 = await pgClient.query(
      'INSERT INTO payment_status (name) VALUES ($1) RETURNING id, name',
      ['Teste Status']
    );
    console.log('Inserção bem-sucedida:', result2.rows[0]);
    
    // Verificar os dados inseridos
    console.log('\nVerificando dados inseridos...');
    const categoryData = await pgClient.query(
      'SELECT * FROM category_types WHERE name = $1',
      ['Teste Categoria']
    );
    console.log('Categoria inserida:', categoryData.rows[0]);
    
    const paymentData = await pgClient.query(
      'SELECT * FROM payment_status WHERE name = $1',
      ['Teste Status']
    );
    console.log('Status inserido:', paymentData.rows[0]);
    
    // Remover os dados de teste
    console.log('\nRemovendo dados de teste...');
    await pgClient.query(
      'DELETE FROM category_types WHERE name = $1',
      ['Teste Categoria']
    );
    await pgClient.query(
      'DELETE FROM payment_status WHERE name = $1',
      ['Teste Status']
    );
    console.log('Dados de teste removidos com sucesso!');
    
  } catch (error) {
    console.error('Erro ao testar inserção:', error);
  } finally {
    await pgClient.end();
    console.log('\nConexão encerrada.');
  }
}

testInsert();