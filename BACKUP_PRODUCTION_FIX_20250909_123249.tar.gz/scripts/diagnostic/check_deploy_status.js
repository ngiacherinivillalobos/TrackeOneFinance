#!/usr/bin/env node

// Script para verificar o status do deploy no Render
const { execSync } = require('child_process');

console.log('=== VERIFICAÇÃO DO STATUS DO DEPLOY NO RENDER ===\n');

// Função para executar comandos
function runCommand(command) {
  try {
    const result = execSync(command, { stdio: 'pipe' });
    return result.toString().trim();
  } catch (error) {
    return null;
  }
}

// Verificar o último commit
console.log('=== ÚLTIMO COMMIT ===');
const lastCommit = runCommand('git log -1 --oneline');
if (lastCommit) {
  console.log(`Último commit: ${lastCommit}`);
} else {
  console.log('Não foi possível obter informações do último commit');
}

console.log('\n');

// Verificar o status do repositório
console.log('=== STATUS DO REPOSITÓRIO ===');
const gitStatus = runCommand('git status --porcelain');
if (gitStatus && gitStatus.length > 0) {
  console.log('Há alterações não enviadas:');
  console.log(gitStatus);
} else {
  console.log('✅ Todos os commits foram enviados para o repositório remoto');
}

console.log('\n');

// Instruções para verificar o deploy no Render
console.log('=== INSTRUÇÕES PARA VERIFICAR O DEPLOY NO RENDER ===');
console.log('1. Acesse o painel do Render: https://dashboard.render.com');
console.log('2. Navegue até o serviço "trackeone-finance-api"');
console.log('3. Verifique o status do deploy na aba "Events"');
console.log('4. Os logs do deploy podem ser vistos na aba "Logs"');

console.log('\n');

// Instruções para testar a API após o deploy
console.log('=== INSTRUÇÕES PARA TESTAR A API APÓS O DEPLOY ===');
console.log('Após o deploy ser concluído, teste os seguintes endpoints:');
console.log('1. Teste básico: GET https://trackeone-finance-api.onrender.com/api/test');
console.log('2. Autenticação: POST https://trackeone-finance-api.onrender.com/api/auth/login');
console.log('3. Fluxo de caixa: GET https://trackeone-finance-api.onrender.com/api/cash-flow?month=08&year=2025&cost_center_id=1');
console.log('4. Detalhes de pagamento: Verifique se a tabela payment_details está acessível');

console.log('\n');

// Instruções para verificar o banco de dados
console.log('=== INSTRUÇÕES PARA VERIFICAR O BANCO DE DADOS ===');
console.log('Após o deploy, verifique se as tabelas foram criadas corretamente:');
console.log('1. A tabela "cash_flow" deve existir com os campos corretos');
console.log('2. A tabela "payment_details" deve existir com os campos corretos');
console.log('3. Os tipos de dados devem ser compatíveis com PostgreSQL');

console.log('\n');

console.log('✅ DEPLOY EM ANDAMENTO!');
console.log('O deploy automático foi iniciado no Render.');
console.log('Verifique o status no painel do Render.');