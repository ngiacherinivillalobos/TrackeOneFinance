const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function fixCashFlowSequence() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Criar sequência para a tabela cash_flow
    console.log('Criando sequência para a tabela cash_flow...');
    await pgClient.query(`
      CREATE SEQUENCE IF NOT EXISTS cash_flow_id_seq
      START WITH 1
      INCREMENT BY 1
      NO MINVALUE
      NO MAXVALUE
      CACHE 1
    `);
    
    // Configurar a coluna id para usar a sequência
    console.log('Configurando coluna id para usar a sequência...');
    await pgClient.query(`
      ALTER TABLE cash_flow 
      ALTER COLUMN id SET DEFAULT nextval('cash_flow_id_seq')
    `);
    
    // Configurar a sequência como "owned by" da tabela
    console.log('Configurando sequência como "owned by" da tabela...');
    await pgClient.query(`
      ALTER SEQUENCE cash_flow_id_seq OWNED BY cash_flow.id
    `);
    
    // Verificar o próximo valor da sequência
    console.log('Verificando próximo valor da sequência...');
    const nextValResult = await pgClient.query(`
      SELECT nextval('cash_flow_id_seq') as next_id
    `);
    
    console.log('Próximo ID disponível:', nextValResult.rows[0].next_id);
    
    // Resetar a sequência para o próximo valor correto
    console.log('Verificando o maior ID existente...');
    const maxIdResult = await pgClient.query(`
      SELECT COALESCE(MAX(id), 0) as max_id FROM cash_flow
    `);
    
    const maxId = maxIdResult.rows[0].max_id;
    console.log('Maior ID existente:', maxId);
    
    if (maxId > 0) {
      console.log('Resetando sequência para o próximo valor correto...');
      await pgClient.query(`
        SELECT setval('cash_flow_id_seq', $1)
      `, [maxId]);
      
      // Verificar novamente o próximo valor da sequência
      console.log('Verificando próximo valor da sequência após reset...');
      const nextValResult2 = await pgClient.query(`
        SELECT nextval('cash_flow_id_seq') as next_id
      `);
      
      console.log('Próximo ID disponível após reset:', nextValResult2.rows[0].next_id);
    } else {
      console.log('Nenhum registro existente, mantendo sequência no valor inicial');
    }
    
    console.log('\nSequência configurada com sucesso!');
    
  } catch (error) {
    console.error('Erro ao configurar sequência:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

fixCashFlowSequence();