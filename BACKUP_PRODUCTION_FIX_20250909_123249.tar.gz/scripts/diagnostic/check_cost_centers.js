const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkCostCenters() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Verificar centros de custo disponíveis
    console.log('Verificando centros de custo disponíveis...');
    const costCentersResult = await pgClient.query(`
      SELECT id, name, number 
      FROM cost_centers 
      ORDER BY id
    `);
    
    console.log('Centros de custo disponíveis:');
    costCentersResult.rows.forEach(cc => {
      console.log(`  ID: ${cc.id}, Nome: ${cc.name}, Número: ${cc.number}`);
    });
    
    // Verificar registros de fluxo de caixa com seus centros de custo
    console.log('\nVerificando registros de fluxo de caixa com centros de custo...');
    const cashFlowResult = await pgClient.query(`
      SELECT 
        cf.id,
        cf.date,
        cf.description,
        cf.amount,
        cf.record_type,
        cf.cost_center_id,
        cc.name as cost_center_name
      FROM cash_flow cf
      LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
      ORDER BY cf.date DESC
      LIMIT 15
    `);
    
    console.log('Registros de fluxo de caixa:');
    cashFlowResult.rows.forEach((row, index) => {
      console.log(`  ${index + 1}. ID: ${row.id}, Data: ${row.date}, Valor: ${row.amount}, Centro de Custo ID: ${row.cost_center_id}, Nome: ${row.cost_center_name || 'N/A'}`);
    });
    
  } catch (error) {
    console.error('Erro ao verificar centros de custo:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

checkCostCenters();