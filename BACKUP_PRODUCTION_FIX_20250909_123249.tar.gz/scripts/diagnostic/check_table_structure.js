const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkTableStructure() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!\n');
    
    // Verificar a estrutura da tabela category_types
    console.log('=== ESTRUTURA DA TABELA category_types ===');
    const categoryTypesStructure = await pgClient.query(`
      SELECT column_name, data_type, is_nullable, column_default
      FROM information_schema.columns 
      WHERE table_name = 'category_types'
      ORDER BY ordinal_position
    `);
    
    console.log('Colunas:');
    categoryTypesStructure.rows.forEach(row => {
      console.log(`  ${row.column_name}: ${row.data_type} (Nullable: ${row.is_nullable})${row.column_default ? ` Default: ${row.column_default}` : ''}`);
    });
    
    // Verificar se a coluna id é auto-incremento
    console.log('\nVerificando se a coluna id é auto-incremento...');
    const serialCheck = await pgClient.query(`
      SELECT pg_get_serial_sequence('category_types', 'id') as sequence_name
    `);
    
    if (serialCheck.rows[0].sequence_name) {
      console.log(`  A coluna id usa a sequência: ${serialCheck.rows[0].sequence_name}`);
    } else {
      console.log('  A coluna id NÃO é auto-incremento');
    }
    
    // Verificar a estrutura da tabela payment_status
    console.log('\n=== ESTRUTURA DA TABELA payment_status ===');
    const paymentStatusStructure = await pgClient.query(`
      SELECT column_name, data_type, is_nullable, column_default
      FROM information_schema.columns 
      WHERE table_name = 'payment_status'
      ORDER BY ordinal_position
    `);
    
    console.log('Colunas:');
    paymentStatusStructure.rows.forEach(row => {
      console.log(`  ${row.column_name}: ${row.data_type} (Nullable: ${row.is_nullable})${row.column_default ? ` Default: ${row.column_default}` : ''}`);
    });
    
    // Verificar se a coluna id é auto-incremento
    console.log('\nVerificando se a coluna id é auto-incremento...');
    const paymentSerialCheck = await pgClient.query(`
      SELECT pg_get_serial_sequence('payment_status', 'id') as sequence_name
    `);
    
    if (paymentSerialCheck.rows[0].sequence_name) {
      console.log(`  A coluna id usa a sequência: ${paymentSerialCheck.rows[0].sequence_name}`);
    } else {
      console.log('  A coluna id NÃO é auto-incremento');
    }
    
    // Verificar os dados existentes
    console.log('\n=== DADOS EXISTENTES ===');
    const categoryData = await pgClient.query('SELECT * FROM category_types ORDER BY id');
    console.log('Dados em category_types:');
    categoryData.rows.forEach(row => {
      console.log(`  ID: ${row.id}, Nome: ${row.name}`);
    });
    
    const paymentData = await pgClient.query('SELECT * FROM payment_status ORDER BY id');
    console.log('\nDados em payment_status:');
    paymentData.rows.forEach(row => {
      console.log(`  ID: ${row.id}, Nome: ${row.name}`);
    });
    
  } catch (error) {
    console.error('Erro ao verificar estrutura das tabelas:', error);
  } finally {
    await pgClient.end();
    console.log('\nConexão encerrada.');
  }
}

checkTableStructure();