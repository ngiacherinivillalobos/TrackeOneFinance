const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function finalVerification() {
  try {
    console.log('=== VERIFICAÇÃO FINAL DO BANCO DE DADOS ===');
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!\n');
    
    // 1. Verificar estrutura da tabela cash_flow
    console.log('1. Verificando estrutura da tabela cash_flow...');
    const cashFlowStructure = await pgClient.query(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'cash_flow' AND column_name IN ('date', 'amount')
      ORDER BY column_name
    `);
    
    console.log('Estrutura da tabela cash_flow (campos críticos):');
    cashFlowStructure.rows.forEach(row => {
      console.log(`  ${row.column_name}: ${row.data_type}`);
    });
    
    // 2. Verificar se a tabela payment_details existe
    console.log('\n2. Verificando existência da tabela payment_details...');
    const paymentDetailsExists = await pgClient.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'payment_details'
      )
    `);
    
    console.log('Tabela payment_details existe:', paymentDetailsExists.rows[0].exists);
    
    if (paymentDetailsExists.rows[0].exists) {
      // Verificar estrutura da tabela payment_details
      console.log('\n3. Verificando estrutura da tabela payment_details...');
      const paymentDetailsStructure = await pgClient.query(`
        SELECT column_name, data_type 
        FROM information_schema.columns 
        WHERE table_name = 'payment_details'
        ORDER BY ordinal_position
      `);
      
      console.log('Estrutura da tabela payment_details:');
      paymentDetailsStructure.rows.forEach(row => {
        console.log(`  ${row.column_name}: ${row.data_type}`);
      });
    }
    
    // 4. Testar consulta do endpoint problemático
    console.log('\n4. Testando consulta do endpoint problemático...');
    try {
      const testQuery = await pgClient.query(`
        SELECT 
          cf.id,
          cf.date,
          cf.description,
          cf.amount,
          cf.record_type,
          cf.category_id,
          cf.subcategory_id,
          cf.cost_center_id,
          c.name as category_name,
          sc.name as subcategory_name,
          cc.name as cost_center_name,
          cc.number as cost_center_number,
          cf.created_at,
          cf.updated_at
        FROM cash_flow cf
        LEFT JOIN categories c ON cf.category_id = c.id
        LEFT JOIN subcategories sc ON cf.subcategory_id = sc.id
        LEFT JOIN cost_centers cc ON cf.cost_center_id = cc.id
        WHERE EXTRACT(MONTH FROM cf.date) = $1 AND EXTRACT(YEAR FROM cf.date) = $2 AND cf.cost_center_id = $3
        ORDER BY cf.date DESC, cf.created_at DESC
      `, [9, 2025, 1]);
      
      console.log('Consulta bem-sucedida!');
      console.log('Número de registros encontrados:', testQuery.rowCount);
    } catch (error) {
      console.error('Erro na consulta:', error.message);
    }
    
    // 5. Verificar dados da tabela cash_flow
    console.log('\n5. Verificando dados da tabela cash_flow...');
    const cashFlowCount = await pgClient.query('SELECT COUNT(*) as total FROM cash_flow');
    console.log('Total de registros na tabela cash_flow:', cashFlowCount.rows[0].total);
    
    const validAmounts = await pgClient.query(`
      SELECT COUNT(*) as total 
      FROM cash_flow 
      WHERE amount IS NOT NULL 
      AND amount::text ~ '^-?[0-9]+\.?[0-9]*$'
    `);
    console.log('Registros com valores válidos:', validAmounts.rows[0].total);
    
    console.log('\n=== VERIFICAÇÃO CONCLUÍDA COM SUCESSO ===');
    
  } catch (error) {
    console.error('Erro na verificação final:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

finalVerification();