const { Client } = require('pg');

// Substitua essas informações pelas suas credenciais do PostgreSQL no Render
const pgClient = new Client({
  connectionString: 'postgres://db_trackeonefinance_user:MX7Xn8tctrx7mduv3jqlJRRzyTBjO04l@dpg-d2p440vdiees73bhqqo0-a.oregon-postgres.render.com:5432/db_trackeonefinance',
  ssl: {
    rejectUnauthorized: false
  }
});

async function createPaymentDetailsTable() {
  try {
    console.log('Tentando conectar ao PostgreSQL...');
    await pgClient.connect();
    console.log('Conectado com sucesso ao PostgreSQL!');
    
    // Criar a tabela payment_details
    console.log('Criando tabela payment_details...');
    await pgClient.query(`
      CREATE TABLE IF NOT EXISTS payment_details (
        id SERIAL PRIMARY KEY,
        transaction_id INTEGER NOT NULL,
        payment_date DATE NOT NULL,
        paid_amount NUMERIC(10,2) NOT NULL,
        original_amount NUMERIC(10,2) NOT NULL,
        payment_type TEXT NOT NULL CHECK (payment_type IN ('bank_account', 'credit_card')),
        bank_account_id INTEGER,
        card_id INTEGER,
        discount_amount NUMERIC(10,2) DEFAULT 0,
        interest_amount NUMERIC(10,2) DEFAULT 0,
        observations TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        
        FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE,
        FOREIGN KEY (bank_account_id) REFERENCES bank_accounts(id),
        FOREIGN KEY (card_id) REFERENCES cards(id)
      )
    `);
    
    console.log('Tabela payment_details criada com sucesso!');
    
    // Criar índices para melhor performance
    console.log('Criando índices para a tabela payment_details...');
    await pgClient.query(`
      CREATE INDEX IF NOT EXISTS idx_payment_details_transaction_id ON payment_details(transaction_id)
    `);
    
    await pgClient.query(`
      CREATE INDEX IF NOT EXISTS idx_payment_details_payment_date ON payment_details(payment_date)
    `);
    
    console.log('Índices criados com sucesso!');
    
    // Verificar se a tabela foi criada corretamente
    console.log('Verificando estrutura da tabela payment_details...');
    const structure = await pgClient.query(`
      SELECT column_name, data_type, is_nullable 
      FROM information_schema.columns 
      WHERE table_name = 'payment_details'
      ORDER BY ordinal_position
    `);
    
    console.log('Estrutura da tabela payment_details:');
    structure.rows.forEach(row => {
      console.log(`  ${row.column_name}: ${row.data_type} (${row.is_nullable})`);
    });
    
  } catch (error) {
    console.error('Erro ao criar tabela payment_details:', error);
  } finally {
    await pgClient.end();
    console.log('Conexão encerrada.');
  }
}

createPaymentDetailsTable();