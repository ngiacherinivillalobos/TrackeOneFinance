-- Migração placeholder para valores booleanos (PostgreSQL)
-- Esta migração foi simplificada para evitar conflitos

-- Comentário de migração aplicada
SELECT 1 as migration_placeholder
