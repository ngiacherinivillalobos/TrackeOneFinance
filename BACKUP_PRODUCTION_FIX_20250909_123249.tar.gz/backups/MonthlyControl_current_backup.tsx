import React from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Checkbox,
  IconButton,
  Menu,
  MenuItem,
  Autocomplete,
  TextField,
  Chip,
  FormControl,
  InputLabel,
  Select,
  Fab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  ListItemIcon,
  ListItemText,
  Divider,
  FormControlLabel,
  Switch,
  Snackbar,
  Alert,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import {
  Add as AddIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  FileCopy as DuplicateIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  CalendarToday as CalendarIcon,
  Download as DownloadIcon,
  Paid as PaidIcon,
  Undo as UndoIcon,
  Remove as RemoveIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as ExpenseIcon,
  TrendingUp as IncomeIcon,
  TrendingDown,
  TrendingUp,
  ShowChart as InvestmentIcon,
  ShowChart,
  FilterList as FilterListIcon,
  AutoFixHigh as ClearIcon,
  AccountBalance as AccountBalanceIcon,
  CreditCard as CreditCardIcon,
  Receipt as ReceiptIcon,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { ptBR } from 'date-fns/locale';
import { format, addMonths, subMonths } from 'date-fns';
import { ModernHeader, ModernCard, ModernStatsCard } from '../components/modern/ModernComponents';
import { colors, gradients, shadows } from '../theme/modernTheme';
import useMonthlyControl from '../hooks/useMonthlyControl';
import PaymentDialog from '../components/PaymentDialog';

export default function MonthlyControl() {
  const {
    transactions,
    loading,
    currentDate,
    setCurrentDate,
    dateFilterType,
    setDateFilterType,
    customStartDate,
    setCustomStartDate,
    customEndDate,
    setCustomEndDate,
    selectedYear,
    setSelectedYear,
    filters,
    setFilters,
    orderBy,
    order,
    categories,
    subcategories,
    contacts,
    costCenters,
    selectedTransactions,
    actionMenuAnchorEl,
    newTransactionMenuAnchor,
    moreFiltersOpen,
    setMoreFiltersOpen,
    batchActionsAnchor,
    transactionDialogOpen,
    editingTransaction,
    formData,
    setFormData,
    recurrencePreview,
    snackbar,
    setSnackbar,
    paymentDialogOpen,
    selectedTransactionForPayment,
    isBatchMode,
    batchEditDialogOpen,
    batchEditData,
    setBatchEditData,
    totalReceitas,
    totalDespesas,
    totalInvestimentos,
    saldoPeriodo,
    vencidos,
    vencemHoje,
    aVencer,
    totalVencidos,
    totalVencemHoje,
    totalAVencer,
    handleSelectTransaction,
    handleSelectAllTransactions,
    handleActionMenuOpen,
    handleActionMenuClose,
    handleDuplicateTransaction,
    handleDeleteTransaction,
    handleMarkAsPaid,
    handleBatchMarkAsPaid,
    handleBatchDelete,
    handleBatchEdit,
    handleConfirmBatchEdit,
    handleConfirmPayment,
    handleClosePaymentDialog,
    handleReversePayment,
    handleBatchReversePayment,
    showSnackbar,
    handleNewTransaction,
    handleEditTransaction,
    handleCloseTransactionDialog,
    handleTransactionSubmit,
    handleSort,
    sortedTransactions,
    formatCurrency,
    getTransactionTypeColor,
    getTransactionStatus,
    getStatusColor,
    setNewTransactionMenuAnchor,
    setBatchActionsAnchor,
    setBatchEditDialogOpen,
    selectedTransactionId,
  } = useMonthlyControl();

  const theme = useTheme();
  const isMediumScreen = useMediaQuery(theme.breakpoints.up('md'));

  const SortableTableCell = ({ children, sortKey, align = 'left', ...props }: {
    children: React.ReactNode;
    sortKey: string;
    align?: 'left' | 'right' | 'center';
    [key: string]: any;
  }) => {
    const isActive = orderBy === sortKey;
    const isAsc = isActive && order === 'asc';

    return (
      <TableCell
        {...props}
        align={align}
        sx={{
          fontWeight: 600,
          color: colors.gray[700],
          bgcolor: colors.gray[50],
          borderBottom: `2px solid ${colors.gray[200]}`,
          cursor: 'pointer',
          userSelect: 'none',
          '&:hover': {
            bgcolor: colors.gray[100]
          },
          ...props.sx
        }}
        onClick={() => handleSort(sortKey)}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          {children}
          <Box sx={{ display: 'flex', flexDirection: 'column', ml: 0.5 }}>
            <Box
              sx={{
                width: 0,
                height: 0,
                borderLeft: '4px solid transparent',
                borderRight: '4px solid transparent',
                borderBottom: `4px solid ${
                  isActive && !isAsc ? colors.primary[600] : colors.gray[400]
                }`,
                mb: 0.2
              }}
            />
            <Box
              sx={{
                width: 0,
                height: 0,
                borderLeft: '4px solid transparent',
                borderRight: '4px solid transparent',
                borderTop: `4px solid ${
                  isActive && isAsc ? colors.primary[600] : colors.gray[400]
                }`
              }}
            />
          </Box>
        </Box>
      </TableCell>
    );
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={ptBR}>
      <Box sx={{ minHeight: '100vh', bgcolor: colors.gray[50] }}>
        <Box sx={{ p: { xs: 2, sm: 3 }, maxWidth: { xs: '100%', md: '1400px' }, mx: 'auto' }}>
          <ModernHeader
            title="Controle Mensal"
            subtitle="Gerencie suas transações financeiras mensais"
            breadcrumbs={[
              { label: 'TrackeOne Finance' },
              { label: 'Controle Mensal' }
            ]}
            actions={(
              <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                <Button
                  variant="outlined"
                  startIcon={<DownloadIcon />}
                  sx={{
                    borderRadius: 1.5,
                    borderColor: colors.gray[300],
                    color: colors.gray[700],
                    '&:hover': {
                      borderColor: colors.primary[400],
                      bgcolor: colors.primary[50]
                    }
                  }}
                >
                  Exportar
                </Button>
                <Button
                  variant="contained"
                  startIcon={<AddIcon />}
                  onClick={(e) => setNewTransactionMenuAnchor(e.currentTarget)}
                  sx={{
                    background: gradients.primary,
                    borderRadius: 1.5,
                    boxShadow: shadows.md,
                    '&:hover': {
                      background: 'linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%)',
                      boxShadow: shadows.lg
                    }
                  }}
                >
                  Nova Transação
                </Button>
              </Box>
            )}
          />

          <Box sx={{
            bgcolor: 'white',
            borderRadius: 2,
            p: { xs: 2, sm: 3 },
            mb: 3,
            border: `1px solid ${colors.gray[200]}`,
            boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
            transition: 'all 0.3s ease'
          }}>
            <Box sx={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: { xs: 1, sm: 1.5, md: 2 },
              alignItems: 'center',
              mb: moreFiltersOpen ? 2 : 0
            }}>
              <FormControl size="small" sx={{ minWidth: 120, flex: '0 0 auto' }}>
                <InputLabel sx={{ fontSize: '0.875rem' }}>Período</InputLabel>
                <Select
                  value={dateFilterType}
                  label="Período"
                  onChange={(e) => setDateFilterType(e.target.value as 'month' | 'year' | 'custom' | 'all')}
                  sx={{ 
                    bgcolor: '#FFFFFF',
                    borderRadius: 1.5,
                    fontSize: '0.875rem',
                    boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent',
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[300],
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[500],
                      borderWidth: 1
                    }
                  }}
                >
                  <MenuItem value="month">Mês</MenuItem>
                  <MenuItem value="year">Ano</MenuItem>
                  <MenuItem value="custom">Personalizado</MenuItem>
                  <MenuItem value="all">Todo o período</MenuItem>
                </Select>
              </FormControl>

              {dateFilterType === 'month' && (
                <Box sx={{ minWidth: 180, flex: '0 0 auto' }}>
                  <DatePicker
                    views={['month', 'year']}
                    label="Mês e Ano"
                    value={currentDate}
                    onChange={(newValue) => newValue && setCurrentDate(newValue)}
                    slotProps={{
                      textField: { 
                        size: 'small',
                        fullWidth: true,
                        sx: { 
                          '& .MuiOutlinedInput-root': {
                            bgcolor: '#FFFFFF',
                            borderRadius: 1.5,
                            fontSize: '0.875rem',
                            boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                            '& .MuiOutlinedInput-notchedOutline': {
                              borderColor: 'transparent'
                            },
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                              borderColor: colors.primary[300]
                            },
                            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                              borderColor: colors.primary[500],
                              borderWidth: 1
                            }
                          },
                          '& .MuiInputLabel-root': {
                            fontSize: '0.875rem'
                          }
                        }
                      }
                    }}
                  />
                </Box>
              )}

              {dateFilterType === 'year' && (
                <Box sx={{ minWidth: 120, flex: '0 0 auto' }}>
                  <DatePicker
                    views={['year']}
                    label="Ano"
                    value={new Date(selectedYear, 0, 1)}
                    onChange={(newValue) => newValue && setSelectedYear(newValue.getFullYear())}
                    slotProps={{
                      textField: { 
                        size: 'small',
                        fullWidth: true,
                        sx: { 
                          '& .MuiOutlinedInput-root': {
                            bgcolor: '#FFFFFF',
                            borderRadius: 1.5,
                            fontSize: '0.875rem',
                            boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                            '& .MuiOutlinedInput-notchedOutline': {
                              borderColor: 'transparent'
                            },
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                              borderColor: colors.primary[300]
                            },
                            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                              borderColor: colors.primary[500],
                              borderWidth: 1
                            }
                          },
                          '& .MuiInputLabel-root': {
                            fontSize: '0.875rem'
                          }
                        }
                      }
                    }}
                  />
                </Box>
              )}

              {dateFilterType === 'custom' && (
                <>
                  <Box sx={{ minWidth: 140, flex: '0 0 auto' }}>
                    <DatePicker
                      label="Data inicial"
                      value={customStartDate}
                      onChange={(newValue) => setCustomStartDate(newValue)}
                      slotProps={{
                        textField: { 
                          size: 'small',
                          fullWidth: true,
                          sx: { 
                            '& .MuiOutlinedInput-root': {
                              bgcolor: '#FFFFFF',
                              borderRadius: 1.5,
                              fontSize: '0.875rem',
                              boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'transparent'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: colors.primary[300]
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: colors.primary[500],
                                borderWidth: 1
                              }
                            },
                            '& .MuiInputLabel-root': {
                              fontSize: '0.875rem'
                            }
                          }
                        }
                      }}
                    />
                  </Box>
                  <Box sx={{ minWidth: 140, flex: '0 0 auto' }}>
                    <DatePicker
                      label="Data final"
                      value={customEndDate}
                      onChange={(newValue) => setCustomEndDate(newValue)}
                      slotProps={{
                        textField: { 
                          size: 'small',
                          fullWidth: true,
                          sx: { 
                            '& .MuiOutlinedInput-root': {
                              bgcolor: '#FFFFFF',
                              borderRadius: 1.5,
                              fontSize: '0.875rem',
                              boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'transparent'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: colors.primary[300]
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: colors.primary[500],
                                borderWidth: 1
                              }
                            },
                            '& .MuiInputLabel-root': {
                              fontSize: '0.875rem'
                            }
                          }
                        }
                      }}
                    />
                  </Box>
                </>
              )}

              <FormControl size="small" sx={{ minWidth: 100, flex: '0 0 auto', position: 'relative' }}>
                <InputLabel sx={{ fontSize: '0.875rem' }}>Tipo</InputLabel>
                <Select
                  multiple
                  value={filters.transaction_type}
                  label="Tipo"
                  onChange={(e) => setFilters((prev: any) => ({ ...prev, transaction_type: e.target.value as string[] }))}
                  renderValue={(selected) => {
                    if (selected.length === 0) return 'Todos';
                    if (selected.length === 1) return selected[0];
                    return `${selected.length} selecionados`;
                  }}
                  sx={{ 
                    bgcolor: '#FFFFFF',
                    borderRadius: 1.5,
                    fontSize: '0.875rem',
                    boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent',
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[300],
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[500],
                      borderWidth: 1
                    }
                  }}
                >
                  <MenuItem value="Despesa">
                    <Checkbox 
                      checked={filters.transaction_type.includes('Despesa')} 
                      size="small"
                      sx={{ mr: 1, p: 0 }}
                    />
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <ExpenseIcon sx={{ fontSize: 16, color: colors.error[600] }} />
                      Despesa
                    </Box>
                  </MenuItem>
                  <MenuItem value="Receita">
                    <Checkbox 
                      checked={filters.transaction_type.includes('Receita')} 
                      size="small"
                      sx={{ mr: 1, p: 0 }}
                    />
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <IncomeIcon sx={{ fontSize: 16, color: colors.success[600] }} />
                      Receita
                    </Box>
                  </MenuItem>
                  <MenuItem value="Investimento">
                    <Checkbox 
                      checked={filters.transaction_type.includes('Investimento')} 
                      size="small"
                      sx={{ mr: 1, p: 0 }}
                    />
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <InvestmentIcon sx={{ fontSize: 16, color: colors.primary[600] }} />
                      Investimento
                    </Box>
                  </MenuItem>
                </Select>
                {filters.transaction_type.length > 0 && (
                  <Chip 
                    label={filters.transaction_type.length}
                    size="small"
                    sx={{
                      position: 'absolute',
                      top: -8,
                      right: -8,
                      height: 18,
                      minWidth: 18,
                      bgcolor: colors.primary[500],
                      color: 'white',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      zIndex: 1,
                      '& .MuiChip-label': {
                        px: 0.5
                      }
                    }}
                  />
                )}
              </FormControl>

              <FormControl size="small" sx={{ minWidth: 100, flex: '0 0 auto', position: 'relative' }}>
                <InputLabel sx={{ fontSize: '0.875rem' }}>Situação</InputLabel>
                <Select
                  multiple
                  value={filters.payment_status_id}
                  label="Situação"
                  onChange={(e) => setFilters((prev: any) => ({ ...prev, payment_status_id: e.target.value as string[] }))}
                  renderValue={(selected) => {
                    if (selected.length === 0) return 'Todos';
                    if (selected.length === 1) {
                      const statusMap: {[key: string]: string} = {
                        'paid': 'Pagos',
                        'unpaid': 'Em Aberto', 
                        'overdue': 'Vencidos',
                        'cancelled': 'Cancelados'
                      };
                      return statusMap[selected[0]] || selected[0];
                    }
                    return `${selected.length} selecionados`;
                  }}
                  sx={{ 
                    bgcolor: '#FFFFFF',
                    borderRadius: 1.5,
                    fontSize: '0.875rem',
                    boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent',
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[300],
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[500],
                      borderWidth: 1
                    }
                  }}
                >
                  <MenuItem value="paid">
                    <Checkbox 
                      checked={filters.payment_status_id.includes('paid')} 
                      size="small"
                      sx={{ mr: 1, p: 0 }}
                    />
                    Pagos
                  </MenuItem>
                  <MenuItem value="unpaid">
                    <Checkbox 
                      checked={filters.payment_status_id.includes('unpaid')} 
                      size="small"
                      sx={{ mr: 1, p: 0 }}
                    />
                    Em Aberto
                  </MenuItem>
                  <MenuItem value="overdue">
                    <Checkbox 
                      checked={filters.payment_status_id.includes('overdue')} 
                      size="small"
                      sx={{ mr: 1, p: 0 }}
                    />
                    Vencidos
                  </MenuItem>
                  <MenuItem value="cancelled">
                    <Checkbox 
                      checked={filters.payment_status_id.includes('cancelled')} 
                      size="small"
                      sx={{ mr: 1, p: 0 }}
                    />
                    Cancelados
                  </MenuItem>
                </Select>
                {filters.payment_status_id.length > 0 && (
                  <Chip 
                    label={filters.payment_status_id.length}
                    size="small"
                    sx={{
                      position: 'absolute',
                      top: -8,
                      right: -8,
                      height: 18,
                      minWidth: 18,
                      bgcolor: colors.primary[500],
                      color: 'white',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      zIndex: 1,
                      '& .MuiChip-label': {
                        px: 0.5
                      }
                    }}
                  />
                )}
              </FormControl>

              <FormControl size="small" sx={{ minWidth: 150, flex: '0 0 auto', position: 'relative' }}>
                <InputLabel sx={{ fontSize: '0.875rem' }}>Centro de Custo</InputLabel>
                <Select
                  multiple
                  value={filters.cost_center_id}
                  label="Centro de Custo"
                  onChange={(e) => setFilters((prev: any) => ({ ...prev, cost_center_id: e.target.value as string[] }))}
                  renderValue={(selected) => {
                    if (selected.length === 0) return 'Todos';
                    if (selected.length === 1) {
                      const costCenter = costCenters.find((cc: any) => cc.id.toString() === selected[0]);
                      if (costCenter) {
                        return costCenter.number ? `${costCenter.number} - ${costCenter.name}` : costCenter.name;
                      }
                      return selected[0];
                    }
                    return `${selected.length} selecionados`;
                  }}
                  sx={{ 
                    bgcolor: '#FFFFFF',
                    borderRadius: 1.5,
                    fontSize: '0.875rem',
                    boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent',
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[300],
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[500],
                      borderWidth: 1
                    }
                  }}
                >
                  {costCenters.map((costCenter: any) => (
                    <MenuItem key={costCenter.id} value={costCenter.id.toString()}>
                      <Checkbox 
                        checked={filters.cost_center_id.includes(costCenter.id.toString())} 
                        size="small"
                        sx={{ mr: 1, p: 0 }}
                      />
                      {costCenter.number ? `${costCenter.number} - ${costCenter.name}` : costCenter.name}
                    </MenuItem>
                  ))}
                </Select>
                {filters.cost_center_id.length > 0 && (
                  <Chip 
                    label={filters.cost_center_id.length}
                    size="small"
                    sx={{
                      position: 'absolute',
                      top: -8,
                      right: -8,
                      height: 18,
                      minWidth: 18,
                      bgcolor: colors.primary[500],
                      color: 'white',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      zIndex: 1,
                      '& .MuiChip-label': {
                        px: 0.5
                      }
                    }}
                  />
                )}
              </FormControl>

              <FormControl size="small" sx={{ minWidth: 150, flex: '0 0 auto', position: 'relative' }}>
                <InputLabel sx={{ fontSize: '0.875rem' }}>Contato</InputLabel>
                <Select
                  multiple
                  value={filters.contact_id}
                  label="Contato"
                  onChange={(e) => setFilters((prev: any) => ({ ...prev, contact_id: e.target.value as string[] }))}
                  renderValue={(selected) => {
                    if (selected.length === 0) return 'Todos';
                    if (selected.length === 1) {
                      const contact = contacts.find((c: any) => c.id.toString() === selected[0]);
                      return contact ? contact.name : selected[0];
                    }
                    return `${selected.length} selecionados`;
                  }}
                  sx={{ 
                    bgcolor: '#FFFFFF',
                    borderRadius: 1.5,
                    fontSize: '0.875rem',
                    boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent',
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[300],
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: colors.primary[500],
                      borderWidth: 1
                    }
                  }}
                >
                  {contacts.map((contact: any) => (
                    <MenuItem key={contact.id} value={contact.id.toString()}>
                      <Checkbox 
                        checked={filters.contact_id.includes(contact.id.toString())} 
                        size="small"
                        sx={{ mr: 1, p: 0 }}
                      />
                      {contact.name}
                    </MenuItem>
                  ))}
                </Select>
                {filters.contact_id.length > 0 && (
                  <Chip 
                    label={filters.contact_id.length}
                    size="small"
                    sx={{
                      position: 'absolute',
                      top: -8,
                      right: -8,
                      height: 18,
                      minWidth: 18,
                      bgcolor: colors.primary[500],
                      color: 'white',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      zIndex: 1,
                      '& .MuiChip-label': {
                        px: 0.5
                      }
                    }}
                  />
                )}
              </FormControl>

              <Button
                startIcon={<FilterListIcon />}
                onClick={() => setMoreFiltersOpen(!moreFiltersOpen)}
                size="small"
                sx={{
                  color: colors.gray[600],
                  bgcolor: colors.gray[100],
                  '&:hover': { bgcolor: colors.gray[200] },
                  borderRadius: 1.5,
                  textTransform: 'none',
                  height: '40px',
                  px: 1.5
                }}
              >
                Mais Filtros
              </Button>

              <Button
                startIcon={<ClearIcon />}
                onClick={() => {
                  setFilters((prev: any) => ({
                    ...prev,
                    transaction_type: [],
                    payment_status_id: ['unpaid', 'overdue'],
                    category_id: [],
                    subcategory_id: '',
                    contact_id: [],
                    cost_center_id: []
                  }));
                }}
                size="small"
                sx={{
                  color: colors.gray[600],
                  bgcolor: 'transparent',
                  '&:hover': { bgcolor: colors.gray[100] },
                  borderRadius: 1.5,
                  textTransform: 'none',
                  height: '40px',
                  px: 1.5
                }}
              >
                Limpar
              </Button>
            </Box>

            {moreFiltersOpen && (
              <Box sx={{
                display: 'grid',
                gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' },
                gap: 2,
                mt: 2,
                pt: 2,
                borderTop: `1px solid ${colors.gray[200]}`
              }}>
                <Autocomplete
                  multiple
                  options={categories}
                  getOptionLabel={(option) => option.name}
                  value={categories.filter((c: any) => filters.category_id.includes(c.id.toString()))}
                  onChange={(event, newValue) => {
                    setFilters((prev: any) => ({
                      ...prev,
                      category_id: newValue.map((v: any) => v.id.toString())
                    }));
                  }}
                  renderInput={(params) => (
                    <TextField {...params} label="Categorias" size="small" />
                  )}
                  renderTags={(value, getTagProps) =>
                    value.map((option, index) => (
                      <Chip
                        variant="outlined"
                        label={option.name}
                        size="small"
                        {...getTagProps({ index })}
                      />
                    ))
                  }
                />
                <Autocomplete
                  options={subcategories.filter((sc: any) => filters.category_id.includes(sc.category_id.toString()))}
                  getOptionLabel={(option) => option.name}
                  value={subcategories.find((sc: any) => sc.id.toString() === filters.subcategory_id) || null}
                  onChange={(event, newValue) => {
                    setFilters((prev: any) => ({
                      ...prev,
                      subcategory_id: newValue ? newValue.id.toString() : ''
                    }));
                  }}
                  renderInput={(params) => (
                    <TextField {...params} label="Subcategoria" size="small" />
                  )}
                  disabled={filters.category_id.length === 0}
                />
              </Box>
            )}
          </Box>

          <Grid container spacing={3} sx={{ mb: 3 }}>
            <Grid {...({item: true, xs: 12, sm: 6, md: 3} as any)}>
              <ModernStatsCard
                title="Receitas"
                value={formatCurrency(totalReceitas)}
                icon={<TrendingUp sx={{ color: colors.success[500] }} />}
              />
            </Grid>
            <Grid {...({item: true, xs: 12, sm: 6, md: 3} as any)}>
              <ModernStatsCard
                title="Despesas"
                value={formatCurrency(totalDespesas)}
                icon={<TrendingDown sx={{ color: colors.error[500] }} />}
              />
            </Grid>
            <Grid {...({item: true, xs: 12, sm: 6, md: 3} as any)}>
              <ModernStatsCard
                title="Investimentos"
                value={formatCurrency(totalInvestimentos)}
                icon={<ShowChart sx={{ color: colors.primary[500] }} />}
              />
            </Grid>
            <Grid {...({item: true, xs: 12, sm: 6, md: 3} as any)}>
              <ModernStatsCard
                title="Saldo do Período"
                value={formatCurrency(saldoPeriodo)}
                icon={<AccountBalanceIcon sx={{ color: saldoPeriodo >= 0 ? colors.primary[500] : colors.error[500] }} />}
              />
            </Grid>
          </Grid>

          <Paper sx={{
            borderRadius: 2,
            boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
            overflow: 'hidden'
          }}>
            <TableContainer>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox" sx={{ bgcolor: colors.gray[50] }}>
                      <Checkbox
                        indeterminate={selectedTransactions.length > 0 && selectedTransactions.length < transactions.length}
                        checked={transactions.length > 0 && selectedTransactions.length === transactions.length}
                        onChange={handleSelectAllTransactions}
                      />
                    </TableCell>
                    <SortableTableCell sortKey="status">Status</SortableTableCell>
                    <SortableTableCell sortKey="transaction_date">Vencimento</SortableTableCell>
                    <SortableTableCell sortKey="description">Descrição</SortableTableCell>
                    <SortableTableCell sortKey="amount" align="right">Valor</SortableTableCell>
                    <TableCell sx={{ fontWeight: 600, color: colors.gray[700], bgcolor: colors.gray[50] }}>Categoria</TableCell>
                    <TableCell sx={{ fontWeight: 600, color: colors.gray[700], bgcolor: colors.gray[50] }}>Centro de Custo</TableCell>
                    <TableCell sx={{ fontWeight: 600, color: colors.gray[700], bgcolor: colors.gray[50] }}>Contato</TableCell>
                    <TableCell align="center" sx={{ fontWeight: 600, color: colors.gray[700], bgcolor: colors.gray[50] }}>Ações</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={9} align="center" sx={{ py: 4 }}>
                        <Typography>Carregando transações...</Typography>
                      </TableCell>
                    </TableRow>
                  ) : sortedTransactions.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} align="center" sx={{ py: 4 }}>
                        <Typography>Nenhuma transação encontrada para os filtros selecionados.</Typography>
                      </TableCell>
                    </TableRow>
                  ) : (
                    sortedTransactions.map((transaction: any) => {
                      const isSelected = selectedTransactions.includes(transaction.id);
                      const status = getTransactionStatus(transaction);
                      const statusColors = getStatusColor(transaction);

                      return (
                        <TableRow
                          key={transaction.id}
                          hover
                          selected={isSelected}
                          sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                        >
                          <TableCell padding="checkbox">
                            <Checkbox
                              checked={isSelected}
                              onChange={() => handleSelectTransaction(transaction.id)}
                            />
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={status}
                              size="small"
                              sx={{
                                bgcolor: statusColors.bg,
                                color: statusColors.color,
                                fontWeight: 500,
                                border: `1px solid ${statusColors.border}`,
                                borderRadius: '6px'
                              }}
                            />
                          </TableCell>
                          <TableCell>{new Date(transaction.transaction_date + 'T00:00:00').toLocaleDateString('pt-BR')}</TableCell>
                          <TableCell>
                            <Typography variant="body2" fontWeight={500}>{transaction.description}</Typography>
                            {transaction.is_installment && (
                              <Typography variant="caption" color="text.secondary">
                                Parcela {transaction.installment_number}/{transaction.total_installments}
                              </Typography>
                            )}
                          </TableCell>
                          <TableCell align="right">
                            <Typography
                              variant="body2"
                              fontWeight={500}
                              color={getTransactionTypeColor(transaction.transaction_type)}
                            >
                              {formatCurrency(transaction.amount)}
                            </Typography>
                          </TableCell>
                          <TableCell>{transaction.category?.name}</TableCell>
                          <TableCell>{transaction.cost_center?.name}</TableCell>
                          <TableCell>{transaction.contact?.name}</TableCell>
                          <TableCell align="center">
                            <IconButton size="small" onClick={(e) => handleActionMenuOpen(e, transaction.id)}>
                              <MoreVertIcon />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>

          {selectedTransactions.length > 0 && (
            <Fab
              variant="extended"
              color="primary"
              sx={{
                position: 'fixed',
                bottom: 24,
                right: 24,
                boxShadow: shadows.lg,
                background: gradients.primary
              }}
              onClick={(e) => setBatchActionsAnchor(e.currentTarget)}
            >
              <Typography sx={{ mr: 1 }}>{selectedTransactions.length} selecionado(s)</Typography>
              <MoreVertIcon />
            </Fab>
          )}
        </Box>

        <Menu
          anchorEl={batchActionsAnchor}
          open={Boolean(batchActionsAnchor)}
          onClose={() => setBatchActionsAnchor(null)}
        >
          <MenuItem onClick={handleBatchMarkAsPaid}>
            <ListItemIcon><PaidIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Marcar como Pago</ListItemText>
          </MenuItem>
          <MenuItem onClick={handleBatchReversePayment}>
            <ListItemIcon><UndoIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Estornar Pagamento</ListItemText>
          </MenuItem>
          <MenuItem onClick={handleBatchEdit}>
            <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Editar em Lote</ListItemText>
          </MenuItem>
          <Divider />
          <MenuItem onClick={handleBatchDelete} sx={{ color: 'error.main' }}>
            <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
            <ListItemText>Excluir</ListItemText>
          </MenuItem>
        </Menu>

        <Menu
          anchorEl={actionMenuAnchorEl}
          open={Boolean(actionMenuAnchorEl)}
          onClose={handleActionMenuClose}
        >
          {selectedTransactionId && transactions.find((t: any) => t.id === selectedTransactionId)?.is_paid ? (
            <MenuItem onClick={() => handleReversePayment(selectedTransactionId)}>
              <ListItemIcon><UndoIcon fontSize="small" /></ListItemIcon>
              <ListItemText>Estornar Pagamento</ListItemText>
            </MenuItem>
          ) : (
            <MenuItem onClick={() => handleMarkAsPaid(selectedTransactionId!)}>
              <ListItemIcon><PaidIcon fontSize="small" /></ListItemIcon>
              <ListItemText>Marcar como Pago</ListItemText>
            </MenuItem>
          )}
          <MenuItem onClick={() => handleEditTransaction(transactions.find((t: any) => t.id === selectedTransactionId!)!)}>
            <ListItemIcon><EditIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Editar</ListItemText>
          </MenuItem>
          <MenuItem onClick={() => handleDuplicateTransaction(selectedTransactionId!)}>
            <ListItemIcon><DuplicateIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Duplicar</ListItemText>
          </MenuItem>
          <Divider />
          <MenuItem onClick={() => handleDeleteTransaction(selectedTransactionId!)} sx={{ color: 'error.main' }}>
            <ListItemIcon><DeleteIcon fontSize="small" color="error" /></ListItemIcon>
            <ListItemText>Excluir</ListItemText>
          </MenuItem>
        </Menu>

        <Menu
          anchorEl={newTransactionMenuAnchor}
          open={Boolean(newTransactionMenuAnchor)}
          onClose={() => setNewTransactionMenuAnchor(null)}
        >
          <MenuItem onClick={() => handleNewTransaction('Despesa')}>
            <ListItemIcon><ExpenseIcon sx={{ color: colors.error[600] }} /></ListItemIcon>
            <ListItemText>Nova Despesa</ListItemText>
          </MenuItem>
          <MenuItem onClick={() => handleNewTransaction('Receita')}>
            <ListItemIcon><IncomeIcon sx={{ color: colors.success[600] }} /></ListItemIcon>
            <ListItemText>Nova Receita</ListItemText>
          </MenuItem>
          <MenuItem onClick={() => handleNewTransaction('Investimento')}>
            <ListItemIcon><InvestmentIcon sx={{ color: colors.primary[600] }} /></ListItemIcon>
            <ListItemText>Novo Investimento</ListItemText>
          </MenuItem>
        </Menu>

        <Dialog open={transactionDialogOpen} onClose={handleCloseTransactionDialog} maxWidth="sm" fullWidth>
          <DialogTitle>{editingTransaction ? 'Editar' : 'Nova'} Transação</DialogTitle>
          <DialogContent>
            <form onSubmit={handleTransactionSubmit}>
              <Grid container spacing={2} sx={{ pt: 1 }}>
                <Grid {...({item: true, xs: 12} as any)}>
                  <TextField
                    label="Descrição"
                    fullWidth
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                  />
                </Grid>
                <Grid {...({item: true, xs: 6} as any)}>
                  <TextField
                    label="Valor"
                    fullWidth
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </Grid>
                <Grid {...({item: true, xs: 6} as any)}>
                  <TextField
                    label="Data"
                    type="date"
                    fullWidth
                    value={formData.transaction_date}
                    onChange={(e) => setFormData({ ...formData, transaction_date: e.target.value })}
                    InputLabelProps={{ shrink: true }}
                    required
                  />
                </Grid>
                <Grid {...({item: true, xs: 6} as any)}>
                  <FormControl fullWidth>
                    <InputLabel>Categoria</InputLabel>
                    <Select
                      value={formData.category_id}
                      label="Categoria"
                      onChange={(e) => setFormData({ ...formData, category_id: e.target.value, subcategory_id: '' })}
                      required
                    >
                      {categories.map((cat: any) => <MenuItem key={cat.id} value={cat.id}>{cat.name}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid {...({item: true, xs: 6} as any)}>
                  <FormControl fullWidth>
                    <InputLabel>Subcategoria</InputLabel>
                    <Select
                      value={formData.subcategory_id}
                      label="Subcategoria"
                      onChange={(e) => setFormData({ ...formData, subcategory_id: e.target.value })}
                      disabled={!formData.category_id}
                    >
                      {subcategories
                        .filter((sub: any) => sub.category_id.toString() === formData.category_id)
                        .map((sub: any) => <MenuItem key={sub.id} value={sub.id}>{sub.name}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid {...({item: true, xs: 6} as any)}>
                  <FormControl fullWidth>
                    <InputLabel>Centro de Custo</InputLabel>
                    <Select
                      value={formData.cost_center_id}
                      label="Centro de Custo"
                      onChange={(e) => setFormData({ ...formData, cost_center_id: e.target.value })}
                      required
                    >
                      {costCenters.map((cc: any) => <MenuItem key={cc.id} value={cc.id}>{cc.name}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid {...({item: true, xs: 6} as any)}>
                  <FormControl fullWidth>
                    <InputLabel>Contato</InputLabel>
                    <Select
                      value={formData.contact_id}
                      label="Contato"
                      onChange={(e) => setFormData({ ...formData, contact_id: e.target.value })}
                      required
                    >
                      {contacts.map((c: any) => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid {...({item: true, xs: 12} as any)}>
                  <FormControlLabel
                    control={<Switch checked={formData.is_paid} onChange={(e) => setFormData({ ...formData, is_paid: e.target.checked })} />}
                    label="Marcar como Pago"
                  />
                </Grid>
              </Grid>
            </form>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseTransactionDialog}>Cancelar</Button>
            <Button onClick={handleTransactionSubmit} variant="contained">Salvar</Button>
          </DialogActions>
        </Dialog>

        <Dialog open={batchEditDialogOpen} onClose={() => setBatchEditDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>Editar Transações em Lote</DialogTitle>
          <DialogContent>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Preencha apenas os campos que deseja alterar para as {selectedTransactions.length} transações selecionadas.
            </Typography>
            <Grid container spacing={2} sx={{ pt: 1 }}>
              <Grid {...({item: true, xs: 6} as any)}>
                <TextField
                  label="Novo Valor"
                  fullWidth
                  value={batchEditData.amount}
                  onChange={(e) => setBatchEditData({ ...batchEditData, amount: e.target.value })}
                />
              </Grid>
              <Grid {...({item: true, xs: 6} as any)}>
                <TextField
                  label="Nova Data"
                  type="date"
                  fullWidth
                  value={batchEditData.transaction_date}
                  onChange={(e) => setBatchEditData({ ...batchEditData, transaction_date: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid {...({item: true, xs: 12} as any)}>
                <TextField
                  label="Nova Descrição"
                  fullWidth
                  value={batchEditData.description}
                  onChange={(e) => setBatchEditData({ ...batchEditData, description: e.target.value })}
                />
              </Grid>
              <Grid {...({item: true, xs: 6} as any)}>
                <FormControl fullWidth>
                  <InputLabel>Nova Categoria</InputLabel>
                  <Select
                    value={batchEditData.category_id}
                    label="Nova Categoria"
                    onChange={(e) => setBatchEditData({ ...batchEditData, category_id: e.target.value, subcategory_id: '' })}
                  >
                    {categories.map((cat: any) => <MenuItem key={cat.id} value={cat.id}>{cat.name}</MenuItem>)}
                  </Select>
                </FormControl>
              </Grid>
              <Grid {...({item: true, xs: 6} as any)}>
                <FormControl fullWidth>
                  <InputLabel>Nova Subcategoria</InputLabel>
                  <Select
                    value={batchEditData.subcategory_id}
                    label="Nova Subcategoria"
                    onChange={(e) => setBatchEditData({ ...batchEditData, subcategory_id: e.target.value })}
                    disabled={!batchEditData.category_id}
                  >
                    {subcategories
                      .filter((sub: any) => sub.category_id.toString() === batchEditData.category_id)
                      .map((sub: any) => <MenuItem key={sub.id} value={sub.id}>{sub.name}</MenuItem>)}
                  </Select>
                </FormControl>
              </Grid>
              <Grid {...({item: true, xs: 6} as any)}>
                <FormControl fullWidth>
                  <InputLabel>Novo Centro de Custo</InputLabel>
                  <Select
                    value={batchEditData.cost_center_id}
                    label="Novo Centro de Custo"
                    onChange={(e) => setBatchEditData({ ...batchEditData, cost_center_id: e.target.value })}
                  >
                    {costCenters.map((cc: any) => <MenuItem key={cc.id} value={cc.id}>{cc.name}</MenuItem>)}
                  </Select>
                </FormControl>
              </Grid>
              <Grid {...({item: true, xs: 6} as any)}>
                <FormControl fullWidth>
                  <InputLabel>Novo Contato</InputLabel>
                  <Select
                    value={batchEditData.contact_id}
                    label="Novo Contato"
                    onChange={(e) => setBatchEditData({ ...batchEditData, contact_id: e.target.value })}
                  >
                    {contacts.map((c: any) => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setBatchEditDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleConfirmBatchEdit} variant="contained">Aplicar Alterações</Button>
          </DialogActions>
        </Dialog>

        {paymentDialogOpen && (
          <PaymentDialog
            open={paymentDialogOpen}
            onClose={handleClosePaymentDialog}
            onConfirm={handleConfirmPayment}
            transaction={selectedTransactionForPayment}
            isBatchMode={isBatchMode}
          />
        )}

        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        >
          <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity} sx={{ width: '100%' }}>
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </LocalizationProvider>
  );
}
