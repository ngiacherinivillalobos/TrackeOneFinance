import React from 'react';
import { Categories as CategoriesComponent } from '../components/Categories';

const Categories: React.FC = () => {
  return <CategoriesComponent />;
};

export default Categories;