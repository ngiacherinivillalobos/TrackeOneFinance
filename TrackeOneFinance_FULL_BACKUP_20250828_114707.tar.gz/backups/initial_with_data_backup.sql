-- Schema completo para TrackOne Finance
-- Recriar todas as tabelas do zero

-- 1. Tabela de tipos de categoria (para organizar categorias)
CREATE TABLE IF NOT EXISTS category_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabela de categorias
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category_type_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_type_id) REFERENCES category_types(id)
);

-- 3. Tabela de subcategorias
CREATE TABLE IF NOT EXISTS subcategories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- 4. Tabela de status de pagamento
CREATE TABLE IF NOT EXISTS payment_status (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 5. Tabela de contas bancárias
CREATE TABLE IF NOT EXISTS bank_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT DEFAULT 'Conta Corrente',
    account_number TEXT,
    initial_balance DECIMAL(10,2) DEFAULT 0,
    current_balance DECIMAL(10,2) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 6. Tabela de cartões de crédito
CREATE TABLE IF NOT EXISTS cards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT DEFAULT 'Crédito',
    limit_amount DECIMAL(10,2),
    closing_day INTEGER,
    due_day INTEGER,
    bank_account_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bank_account_id) REFERENCES bank_accounts(id)
);

-- 7. Tabela de contatos (clientes/fornecedores)
CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    type TEXT CHECK(type IN ('Cliente', 'Fornecedor')) DEFAULT 'Cliente',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 8. Tabela de transações (relaciona com todas as outras)
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date DATE NOT NULL,
    contact_id INTEGER,
    description TEXT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    category_id INTEGER,
    subcategory_id INTEGER,
    payment_status_id INTEGER,
    bank_account_id INTEGER,
    card_id INTEGER,
    is_fixed BOOLEAN DEFAULT 0,
    cycle_start_date DATE,
    cycle_end_date DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (contact_id) REFERENCES contacts(id),
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (subcategory_id) REFERENCES subcategories(id),
    FOREIGN KEY (payment_status_id) REFERENCES payment_status(id),
    FOREIGN KEY (bank_account_id) REFERENCES bank_accounts(id),
    FOREIGN KEY (card_id) REFERENCES cards(id)
);

-- DADOS INICIAIS

-- Tipos de categoria
INSERT OR IGNORE INTO category_types (name) VALUES 
('Despesa'),
('Receita'),
('Transferência'),
('Investimento');

-- Status de pagamento
INSERT OR IGNORE INTO payment_status (name) VALUES 
('Pendente'),
('Pago'),
('Atrasado'),
('Cancelado');

-- Categorias padrão organizadas por tipo
INSERT OR IGNORE INTO categories (name, category_type_id) VALUES 
-- Despesas
('Alimentação', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Transporte', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Moradia', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Saúde', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Educação', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Lazer', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Compras', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Assinatura', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Impostos', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Seguros', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Veículo', (SELECT id FROM category_types WHERE name = 'Despesa')),
('Viagem', (SELECT id FROM category_types WHERE name = 'Despesa')),
-- Receitas
('Salário', (SELECT id FROM category_types WHERE name = 'Receita')),
('Honorários', (SELECT id FROM category_types WHERE name = 'Receita')),
('Freelance', (SELECT id FROM category_types WHERE name = 'Receita')),
('Vendas', (SELECT id FROM category_types WHERE name = 'Receita')),
('Reembolso', (SELECT id FROM category_types WHERE name = 'Receita')),
('Bonificação', (SELECT id FROM category_types WHERE name = 'Receita')),
-- Transferências
('Transferência entre Contas', (SELECT id FROM category_types WHERE name = 'Transferência')),
('Empréstimo', (SELECT id FROM category_types WHERE name = 'Transferência')),
-- Investimentos
('Poupança', (SELECT id FROM category_types WHERE name = 'Investimento')),
('Investimento CDB', (SELECT id FROM category_types WHERE name = 'Investimento')),
('Ações', (SELECT id FROM category_types WHERE name = 'Investimento'));

-- Subcategorias de exemplo
INSERT OR IGNORE INTO subcategories (category_id, name) VALUES 
-- Alimentação
((SELECT id FROM categories WHERE name = 'Alimentação'), 'Restaurante'),
((SELECT id FROM categories WHERE name = 'Alimentação'), 'Supermercado'),
((SELECT id FROM categories WHERE name = 'Alimentação'), 'Delivery'),
((SELECT id FROM categories WHERE name = 'Alimentação'), 'Lanche'),
-- Transporte
((SELECT id FROM categories WHERE name = 'Transporte'), 'Combustível'),
((SELECT id FROM categories WHERE name = 'Transporte'), 'Uber'),
((SELECT id FROM categories WHERE name = 'Transporte'), 'Transporte Público'),
((SELECT id FROM categories WHERE name = 'Transporte'), 'Estacionamento'),
-- Moradia
((SELECT id FROM categories WHERE name = 'Moradia'), 'Aluguel'),
((SELECT id FROM categories WHERE name = 'Moradia'), 'Condomínio'),
((SELECT id FROM categories WHERE name = 'Moradia'), 'Energia Elétrica'),
((SELECT id FROM categories WHERE name = 'Moradia'), 'Água'),
((SELECT id FROM categories WHERE name = 'Moradia'), 'Gás'),
((SELECT id FROM categories WHERE name = 'Moradia'), 'Internet'),
-- Saúde
((SELECT id FROM categories WHERE name = 'Saúde'), 'Médico'),
((SELECT id FROM categories WHERE name = 'Saúde'), 'Medicamentos'),
((SELECT id FROM categories WHERE name = 'Saúde'), 'Plano de Saúde'),
((SELECT id FROM categories WHERE name = 'Saúde'), 'Dentista');

-- Contas bancárias de exemplo
INSERT OR IGNORE INTO bank_accounts (name, type, account_number, initial_balance, current_balance) VALUES 
('Conta Corrente Principal', 'Conta Corrente', '12345-6', 0, 0),
('Conta Poupança', 'Conta Poupança', '98765-4', 0, 0);

-- Cartões de exemplo
INSERT OR IGNORE INTO cards (name, type, limit_amount, closing_day, due_day, bank_account_id) VALUES 
('Cartão Principal', 'Crédito', 5000.00, 15, 10, (SELECT id FROM bank_accounts WHERE name = 'Conta Corrente Principal')),
('Cartão Secundário', 'Crédito', 2000.00, 20, 15, (SELECT id FROM bank_accounts WHERE name = 'Conta Corrente Principal'));

-- Contatos de exemplo
INSERT OR IGNORE INTO contacts (name, email, phone, type) VALUES 
('Empresa XYZ', 'contato@empresa.com', '(11) 9999-9999', 'Cliente'),
('Fornecedor ABC', 'vendas@abc.com', '(11) 8888-8888', 'Fornecedor');
